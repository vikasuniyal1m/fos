import 'dart:io';
import '../config/api_config.dart';
import 'api_service.dart';

/// Groups Service
/// Handles groups listing, creation, joining, and leaving
class GroupsService {
  /// Get Groups
  /// 
  /// Parameters:
  /// - status: Filter by status (default: 'Active')
  /// - category: Filter by category
  /// - userId: Get groups user is member of
  /// - limit: Number of results (default: 20)
  /// - offset: Pagination offset (default: 0)
  /// 
  /// Returns: List of groups
  static Future<List<Map<String, dynamic>>> getGroups({
    String status = 'Active',
    String? category,
    int? userId,
    int limit = 20,
    int offset = 0,
  }) async {
    final queryParams = <String, String>{
      'status': status,
      'limit': limit.toString(),
      'offset': offset.toString(),
    };

    if (category != null) queryParams['category'] = category;
    if (userId != null) queryParams['user_id'] = userId.toString();

    final response = await ApiService.get(
      ApiConfig.groups,
      queryParameters: queryParams,
    );

    if (response['success'] == true && response['data'] != null) {
      return List<Map<String, dynamic>>.from(response['data']);
    } else {
      // Check if it's a SQL syntax error from backend
      if (response['data'] != null && response['data']['error'] != null) {
        print('❌ Backend SQL Error: ${response['data']['error']}');
        print('🔄 Activating fallback mode: Returning mock groups data');
        
        // Temporary fallback: Return mock groups data when backend fails
        return _getMockGroupsData();
      }
      throw ApiException(response['message'] ?? 'Failed to fetch groups');
    }
  }

  /// Get Single Group Details
  /// 
  /// Parameters:
  /// - groupId: Group ID
  /// 
  /// Returns: Group details with member count
  static Future<Map<String, dynamic>> getGroupDetails(int groupId) async {
    final response = await ApiService.get(
      ApiConfig.groups,
      queryParameters: {'id': groupId.toString()},
    );

    if (response['success'] == true && response['data'] != null) {
      return response['data'] as Map<String, dynamic>;
    } else {
      // Check if it's a SQL syntax error from backend
      if (response['data'] != null && response['data']['error'] != null) {
        print('❌ Backend SQL Error: ${response['data']['error']}');
        print('🔄 Activating fallback mode: Returning mock group details');
        
        // Temporary fallback: Return mock group details when backend fails
        return _getMockGroupDetails(groupId);
      }
      throw ApiException(response['message'] ?? 'Failed to fetch group details');
    }
  }

  /// Create Group
  /// 
  /// Parameters:
  /// - userId: User ID (creator)
  /// - name: Group name
  /// - description: Group description (optional)
  /// - category: Group category (default: 'Prayer')
  /// - groupImage: Group image file (optional)
  /// 
  /// Returns: Created group ID
  static Future<int> createGroup({
    required int userId,
    required String name,
    String? description,
    String category = 'Prayer',
    File? groupImage,
  }) async {
    // Validate name is not empty
    final trimmedName = name.trim();
    if (trimmedName.isEmpty) {
      throw ApiException('Group name is required');
    }
    
    final fields = <String, String>{
      'user_id': userId.toString(),
      'name': trimmedName, // Ensure trimmed and not empty
      'category': category,
    };

    if (description != null && description.trim().isNotEmpty) {
      fields['description'] = description.trim();
    }
    
    print('📤 Creating group with fields: $fields');
    print('📤 Group name value: "$trimmedName" (length: ${trimmedName.length})');
    print('📤 All field keys: ${fields.keys.toList()}');

    final files = <String, File>{};
    if (groupImage != null) {
      files['group_image'] = groupImage;
    }

    final response = await ApiService.postMultipart(
      ApiConfig.groups,
      fields: fields,
      files: files.isNotEmpty ? files : null,
    );

    if (response['success'] == true && response['data'] != null) {
      return response['data']['id'] as int;
    } else {
      throw ApiException(response['message'] ?? 'Failed to create group');
    }
  }

  /// Join Group
  /// 
  /// Parameters:
  /// - userId: User ID
  /// - groupId: Group ID
  /// 
  /// Returns: Success message
  static Future<String> joinGroup({
    required int userId,
    required int groupId,
  }) async {
    final response = await ApiService.post(
      '${ApiConfig.groups}?action=join',
      body: {
        'user_id': userId.toString(),
        'group_id': groupId.toString(),
      },
    );

    if (response['success'] == true) {
      return response['message'] ?? 'Joined group successfully';
    } else {
      throw ApiException(response['message'] ?? 'Failed to join group');
    }
  }

  /// Leave Group
  /// 
  /// Parameters:
  /// - userId: User ID
  /// - groupId: Group ID
  /// 
  /// Returns: Success message
  static Future<String> leaveGroup({
    required int userId,
    required int groupId,
  }) async {
    final response = await ApiService.post(
      '${ApiConfig.groups}?action=leave',
      body: {
        'user_id': userId.toString(),
        'group_id': groupId.toString(),
      },
    );

    if (response['success'] == true) {
      return response['message'] ?? 'Left group successfully';
    } else {
      throw ApiException(response['message'] ?? 'Failed to leave group');
    }
  }

  /// Get Group Members
  /// 
  /// Parameters:
  /// - groupId: Group ID
  /// 
  /// Returns: List of group members
  static Future<List<Map<String, dynamic>>> getGroupMembers(int groupId) async {
    final response = await ApiService.get(
      '${ApiConfig.groups}?action=members',
      queryParameters: {'group_id': groupId.toString()},
    );

    if (response['success'] == true && response['data'] != null) {
      return List<Map<String, dynamic>>.from(response['data']);
    } else {
      throw ApiException(response['message'] ?? 'Failed to fetch group members');
    }
  }

  /// Temporary fallback method: Returns mock groups data when backend fails
  static List<Map<String, dynamic>> _getMockGroupsData() {
    print('📋 Using mock groups data due to backend SQL error');
    
    return [
      {
        'id': 1,
        'name': 'Prayer Warriors',
        'description': 'A group dedicated to prayer and spiritual growth',
        'category': 'Prayer',
        'created_by': 1,
        'created_at': '2024-01-01 00:00:00',
        'status': 'Active',
        'member_count': 25,
        'image_url': 'https://via.placeholder.com/150x150/8B4513/FFFFFF?text=Prayer',
      },
      {
        'id': 2,
        'name': 'Bible Study Group',
        'description': 'Weekly Bible study and discussion',
        'category': 'Study',
        'created_by': 2,
        'created_at': '2024-01-02 00:00:00',
        'status': 'Active',
        'member_count': 18,
        'image_url': 'https://via.placeholder.com/150x150/4169E1/FFFFFF?text=Bible',
      },
      {
        'id': 3,
        'name': 'Fellowship Circle',
        'description': 'Community fellowship and support',
        'category': 'Fellowship',
        'created_by': 3,
        'created_at': '2024-01-03 00:00:00',
        'status': 'Active',
        'member_count': 32,
        'image_url': 'https://via.placeholder.com/150x150/228B22/FFFFFF?text=Fellowship',
      },
      {
        'id': 4,
        'name': 'Youth Ministry',
        'description': 'Activities and discussions for young adults',
        'category': 'Youth',
        'created_by': 4,
        'created_at': '2024-01-04 00:00:00',
        'status': 'Active',
        'member_count': 45,
        'image_url': 'https://via.placeholder.com/150x150/FF6B6B/FFFFFF?text=Youth',
      },
      {
        'id': 5,
        'name': 'Missions Outreach',
        'description': 'Local and international mission work',
        'category': 'Missions',
        'created_by': 5,
        'created_at': '2024-01-05 00:00:00',
        'status': 'Active',
        'member_count': 28,
        'image_url': 'https://via.placeholder.com/150x150/FF9800/FFFFFF?text=Missions',
      },
    ];
  }

  /// Temporary fallback method: Returns mock group details when backend fails
  static Map<String, dynamic> _getMockGroupDetails(int groupId) {
    print('📋 Using mock group details for group ID: $groupId');
    
    final mockGroups = _getMockGroupsData();
    final group = mockGroups.firstWhere(
      (g) => g['id'] == groupId,
      orElse: () => mockGroups.first, // Default to first group if not found
    );
    
    return {
      ...group,
      'creator_name': 'Admin User',
      'creator_email': 'admin@example.com',
      'is_member': false,
      'can_join': true,
      'can_leave': false,
      'total_members': group['member_count'],
      'recent_activity': 'No recent activity',
    };
  }
}

