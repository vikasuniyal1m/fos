import 'dart:async';
import 'dart:io';
import 'package:get/get.dart';
import 'package:fruitsofspirit/services/shorts_service.dart';
import 'package:fruitsofspirit/services/user_storage.dart';
import 'package:fruitsofspirit/services/hive_cache_service.dart';
import 'package:fruitsofspirit/services/api_service.dart';

/// Shorts Controller — isolated state for Shorts module
class ShortsController extends GetxController {
  var isLoading = false.obs;
  var isUploading = false.obs;
  var message = ''.obs;
  var shorts = <Map<String, dynamic>>[].obs;
  var savedShorts = <Map<String, dynamic>>[].obs;
  var comments = <Map<String, dynamic>>[].obs;
  var userId = 0.obs;
  var hasMore = true.obs;
  int? _nextCursor;
  Timer? _pollTimer;
  static const String _hiveKey = 'shorts_feed';
  static const Duration _pollInterval = Duration(seconds: 8);

  @override
  void onInit() {
    super.onInit();
    _loadUserId();
    _loadFromHive();
  }

  @override
  void onClose() {
    _pollTimer?.cancel();
    super.onClose();
  }

  Future<void> _loadUserId() async {
    userId.value = await UserStorage.getUserId() ?? 0;
  }

  void _loadFromHive() {
    final cached = HiveCacheService.getCachedList(_hiveKey);
    if (cached.isNotEmpty) {
      shorts.value = List<Map<String, dynamic>>.from(cached);
    }
  }

  void startPolling() {
    _pollTimer?.cancel();
    _pollTimer = Timer.periodic(_pollInterval, (_) => _syncCounts());
  }

  void stopPolling() {
    _pollTimer?.cancel();
  }

  Future<void> _syncCounts() async {
    if (shorts.isEmpty) return;
    try {
      final ids = shorts.map((s) => ShortsService.shortId(s)).where((id) => id > 0).toList();
      if (ids.isEmpty) return;
      final counts = await ShortsService.getCounts(ids);
      for (var i = 0; i < shorts.length; i++) {
        final id = ShortsService.shortId(shorts[i]).toString();
        if (counts.containsKey(id)) {
          final c = counts[id] as Map<String, dynamic>;
          shorts[i] = Map<String, dynamic>.from(shorts[i])
            ..['total_likes'] = c['total_likes']
            ..['total_comments'] = c['total_comments']
            ..['total_shares'] = c['total_shares']
            ..['total_saves'] = c['total_saves'];
        }
      }
      shorts.refresh();
    } catch (_) {}
  }

  Future<void> loadShorts({bool refresh = false}) async {
    if (isLoading.value && !refresh) return;
    if (refresh) {
      _nextCursor = null;
      hasMore.value = true;
    }
    if (!hasMore.value && !refresh) return;

    isLoading.value = true;
    try {
      await _loadUserId();
      final items = await ShortsService.getShorts(
        currentUserId: userId.value > 0 ? userId.value : null,
        limit: 20,
        cursor: refresh ? null : _nextCursor,
      );
      if (refresh) {
        shorts.value = items;
      } else {
        shorts.addAll(items);
      }
      if (items.isNotEmpty) {
        _nextCursor = ShortsService.shortId(items.last);
      }
      hasMore.value = items.length >= 20;
      unawaited(HiveCacheService.cacheList(_hiveKey, shorts.toList()));
    } catch (e) {
      message.value = e is ApiException ? e.message : 'Failed to load shorts';
    } finally {
      isLoading.value = false;
    }
  }

  void updateShortAt(int index, Map<String, dynamic> updates) {
    if (index < 0 || index >= shorts.length) return;
    shorts[index] = Map<String, dynamic>.from(shorts[index])..addAll(updates);
    shorts.refresh();
  }

  Future<void> toggleLike(int index) async {
    if (index < 0 || index >= shorts.length || userId.value <= 0) return;
    final short = shorts[index];
    final id = ShortsService.shortId(short);
    final wasLiked = short['is_liked'] == true;
    final currentLikes = int.tryParse(short['total_likes']?.toString() ?? '0') ?? 0;

    updateShortAt(index, {
      'is_liked': !wasLiked,
      'total_likes': wasLiked ? (currentLikes - 1).clamp(0, 999999999) : currentLikes + 1,
    });

    try {
      final result = await ShortsService.toggleLike(shortId: id, userId: userId.value);
      updateShortAt(index, {
        'is_liked': result['is_liked'] ?? !wasLiked,
        'total_likes': result['total_likes'] ?? currentLikes,
      });
    } catch (e) {
      updateShortAt(index, {
        'is_liked': wasLiked,
        'total_likes': currentLikes,
      });
    }
  }

  Future<void> toggleSave(int index) async {
    if (index < 0 || index >= shorts.length || userId.value <= 0) return;
    final short = shorts[index];
    final id = ShortsService.shortId(short);
    final wasSaved = short['is_saved'] == true;
    final currentSaves = int.tryParse(short['total_saves']?.toString() ?? '0') ?? 0;

    updateShortAt(index, {
      'is_saved': !wasSaved,
      'total_saves': wasSaved ? (currentSaves - 1).clamp(0, 999999999) : currentSaves + 1,
    });

    try {
      final result = await ShortsService.toggleSave(shortId: id, userId: userId.value);
      updateShortAt(index, {
        'is_saved': result['is_saved'] ?? !wasSaved,
        'total_saves': result['total_saves'] ?? currentSaves,
      });
    } catch (e) {
      updateShortAt(index, {
        'is_saved': wasSaved,
        'total_saves': currentSaves,
      });
    }
  }

  Future<void> trackShare(int index, {String shareType = 'native'}) async {
    if (index < 0 || index >= shorts.length) return;
    final short = shorts[index];
    final id = ShortsService.shortId(short);
    final currentShares = int.tryParse(short['total_shares']?.toString() ?? '0') ?? 0;
    updateShortAt(index, {'total_shares': currentShares + 1});
    try {
      final result = await ShortsService.trackShare(
        shortId: id,
        userId: userId.value,
        shareType: shareType,
      );
      updateShortAt(index, {'total_shares': result['total_shares'] ?? currentShares + 1});
    } catch (_) {}
  }

  Future<void> recordView(int index) async {
    if (index < 0 || index >= shorts.length || userId.value <= 0) return;
    final id = ShortsService.shortId(shorts[index]);
    unawaited(ShortsService.trackView(shortId: id, userId: userId.value));
  }

  Future<void> loadComments(int shortId) async {
    try {
      comments.value = await ShortsService.getComments(shortId);
    } catch (e) {
      message.value = 'Failed to load comments';
    }
  }

  Future<bool> addComment(int shortId, String text, int feedIndex) async {
    if (userId.value <= 0 || text.trim().isEmpty) return false;
    try {
      final result = await ShortsService.addComment(
        shortId: shortId,
        userId: userId.value,
        comment: text.trim(),
      );
      if (result['comment'] != null) {
        comments.add(Map<String, dynamic>.from(result['comment']));
      }
      if (feedIndex >= 0 && feedIndex < shorts.length) {
        updateShortAt(feedIndex, {
          'total_comments': result['total_comments'] ??
              ((int.tryParse(shorts[feedIndex]['total_comments']?.toString() ?? '0') ?? 0) + 1),
        });
      }
      return true;
    } catch (e) {
      message.value = e is ApiException ? e.message : 'Failed to post comment';
      return false;
    }
  }

  Future<bool> uploadShort({
    required File videoFile,
    File? thumbnailFile,
    String? title,
    String? description,
    int duration = 0,
  }) async {
    isUploading.value = true;
    try {
      await _loadUserId();
      if (userId.value <= 0) throw ApiException('Please log in');
      await ShortsService.uploadShort(
        userId: userId.value,
        videoFile: videoFile,
        thumbnailFile: thumbnailFile,
        title: title,
        description: description,
        duration: duration,
      );
      message.value = 'Short uploaded! Pending approval.';
      return true;
    } catch (e) {
      message.value = e is ApiException ? e.message : 'Upload failed';
      return false;
    } finally {
      isUploading.value = false;
    }
  }

  Future<void> loadSavedShorts() async {
    isLoading.value = true;
    try {
      await _loadUserId();
      savedShorts.value = await ShortsService.getSavedShorts(userId: userId.value);
    } catch (e) {
      message.value = 'Failed to load saved shorts';
    } finally {
      isLoading.value = false;
    }
  }

  Future<bool> deleteOwnShort(int shortId, int index) async {
    try {
      await ShortsService.deleteShort(shortId: shortId, userId: userId.value);
      if (index >= 0 && index < shorts.length) {
        shorts.removeAt(index);
      }
      return true;
    } catch (e) {
      message.value = e is ApiException ? e.message : 'Delete failed';
      return false;
    }
  }

  Future<void> reportShort(int shortId, String reason, {String? description}) async {
    await ShortsService.reportShort(
      shortId: shortId,
      userId: userId.value,
      reason: reason,
      description: description,
    );
  }
}
