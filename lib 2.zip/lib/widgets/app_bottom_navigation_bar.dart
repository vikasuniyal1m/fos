import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:lottie/lottie.dart';
import 'package:fruitsofspirit/routes/routes.dart';
import 'package:fruitsofspirit/utils/responsive_helper.dart';
import 'package:fruitsofspirit/utils/localization_helper.dart';
import 'package:fruitsofspirit/config/image_config.dart';
import 'package:fruitsofspirit/widgets/cached_image.dart';
import 'package:fruitsofspirit/controllers/gallery_controller.dart';

import 'package:fruitsofspirit/controllers/main_dashboard_controller.dart';

import '../utils/app_theme.dart';

/// Animated Praying Hands Icon
class AnimatedPrayingHands extends StatefulWidget {
  final double size;
  final Color color;
  final bool isActive;

  const AnimatedPrayingHands({
    Key? key,
    required this.size,
    required this.color,
    this.isActive = false,
  }) : super(key: key);

  @override
  State<AnimatedPrayingHands> createState() => _AnimatedPrayingHandsState();
}

class _AnimatedPrayingHandsState extends State<AnimatedPrayingHands>
    with SingleTickerProviderStateMixin {
  late AnimationController _controller;
  late Animation<double> _scaleAnimation;
  late Animation<double> _rotationAnimation;

  @override
  void initState() {
    super.initState();
    _controller = AnimationController(
      duration: const Duration(milliseconds: 1500),
      vsync: this,
    )..repeat(reverse: true);

    _scaleAnimation = Tween<double>(begin: 1.0, end: 1.1).animate(
      CurvedAnimation(
        parent: _controller,
        curve: Curves.easeInOut,
      ),
    );

    _rotationAnimation = Tween<double>(begin: -0.05, end: 0.05).animate(
      CurvedAnimation(
        parent: _controller,
        curve: Curves.easeInOut,
      ),
    );
  }

  @override
  void dispose() {
    _controller.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return AnimatedBuilder(
      animation: _controller,
      builder: (context, child) {
        return Transform.scale(
          scale: widget.isActive ? _scaleAnimation.value : 1.0,
          child: Transform.rotate(
            angle: widget.isActive ? _rotationAnimation.value : 0.0,
            child: Container(
              padding: EdgeInsets.all(widget.size * 0.18),
              decoration: BoxDecoration(
                color: widget.isActive 
                    ? const Color(0xFFFEECE2)
                    : const Color(0xFFFEECE2).withOpacity(0.6),
                shape: BoxShape.circle,
                border: widget.isActive
                    ? Border.all(
                        color: widget.color,
                        width: widget.size * 0.06,
                      )
                    : null,
                boxShadow: widget.isActive
                    ? [
                        BoxShadow(
                          color: widget.color.withOpacity(0.3),
                          blurRadius: widget.size * 0.2,
                          spreadRadius: widget.size * 0.05,
                        ),
                      ]
                    : null,
              ),
              child: SizedBox(
                width: widget.size * 0.75,
                height: widget.size * 0.75,
                child: Lottie.asset(
                  'assets/animations/praying_hands_advanced.json',
                  width: widget.size * 0.75,
                  height: widget.size * 0.75,
                  repeat: true,
                  fit: BoxFit.contain,
                  options: LottieOptions(
                    enableMergePaths: true,
                  ),
                ),
              ),
            ),
          ),
        );
      },
    );
  }
}

/// Reusable Bottom Navigation Bar Widget
/// Use this widget across all screens for consistent navigation
class AppBottomNavigationBar extends StatelessWidget {
  final int currentIndex;
  final ValueChanged<int>? onTap;

  const AppBottomNavigationBar({
    Key? key,
    required this.currentIndex,
    this.onTap,
  }) : super(key: key);

  @override
  Widget build(BuildContext context) {
    final iconSize = ResponsiveHelper.bottomNavIconSize(context);
    final activeIconSize = ResponsiveHelper.bottomNavActiveIconSize(context);
    final themeColor = AppTheme.primaryColor;
    final shadowBlur = ResponsiveHelper.dim(context, mobile: 10);

    return Container(
      decoration: BoxDecoration(
        color: Colors.white,
        boxShadow: [
          BoxShadow(
            color: Colors.black.withOpacity(0.1),
            spreadRadius: 0,
            blurRadius: shadowBlur,
            offset: Offset(0, -ResponsiveHelper.dim(context, mobile: 2)),
          ),
        ],
      ),
      child: SafeArea(
        top: false,
        child: BottomNavigationBar(
          type: BottomNavigationBarType.fixed,
          backgroundColor: Colors.white,
          selectedItemColor: themeColor,
          unselectedItemColor: Colors.grey[600],
          currentIndex: currentIndex,
          elevation: 0,
          iconSize: iconSize,
          showSelectedLabels: false,
          showUnselectedLabels: false,
          selectedFontSize: 0,
          unselectedFontSize: 0,
          onTap: onTap,
          items: [
            BottomNavigationBarItem(
              icon: SizedBox(
                width: iconSize,
                height: iconSize,
                child: Icon(
                  Icons.home_outlined,
                  size: iconSize,
                  color: AppTheme.primaryColor,
                ), /*Image.asset(
                  'assets/home.png',
                  width: iconSize,
                  height: iconSize,
                  fit: BoxFit.contain,
                  errorBuilder: (context, error, stackTrace) {
                    return Icon(
                      Icons.home,
                      size: iconSize,
                      color: Colors.grey[600],
                    );
                  },
                ),*/
              ),
              activeIcon: SizedBox(
                width: activeIconSize,
                height: activeIconSize,
                child: Icon(
                  Icons.home,
                  size: iconSize,
                  color: AppTheme.primaryColor,
                ), /*Image.asset(
                  'assets/home.png',
                  width: activeIconSize,
                  height: activeIconSize,
                  fit: BoxFit.contain,
                  errorBuilder: (context, error, stackTrace) {
                    return Icon(
                      Icons.home,
                      size: activeIconSize,
                      color: themeColor,
                    );
                  },
                ),*/
              ),
              label: '',
            ),
            BottomNavigationBarItem(
              icon: SizedBox(
                width: iconSize,
                height: iconSize,
                child: Image.asset(
                  'assets/orange.png',
                  width: iconSize,
                  height: iconSize,
                  fit: BoxFit.contain,
                ),
              ),
              activeIcon: SizedBox(
                width: activeIconSize,
                height: activeIconSize,
                child: Image.asset(
                  'assets/orange.png',
                  width: activeIconSize,
                  height: activeIconSize,
                  fit: BoxFit.contain,
                ),
              ),
              label: '',
            ),
            BottomNavigationBarItem(
              icon: SizedBox(
                width: iconSize,
                height: iconSize,
                child: Image.asset(
                  'assets/prayer.png',
                  width: iconSize,
                  height: iconSize,
                  fit: BoxFit.contain,
                  errorBuilder: (context, error, stackTrace) {
                    return Icon(
                      Icons.photo_size_select_actual_outlined,
                      size: iconSize,
                      color: Colors.grey[600],
                    );
                  },
                ),
              ),
              activeIcon: SizedBox(
                width: activeIconSize,
                height: activeIconSize,
                child: Image.asset(
                  'assets/prayer.png',
                  width: activeIconSize,
                  height: activeIconSize,
                  fit: BoxFit.contain,
                  errorBuilder: (context, error, stackTrace) {
                    return Icon(
                      Icons.volunteer_activism_rounded,
                      size: activeIconSize,
                      color: themeColor,
                    );
                  },
                ),
              ),
              label: '',
            ),
            BottomNavigationBarItem(
              icon: SizedBox(
                  width: iconSize,
                  height: iconSize,
                  child: Icon(
                    Icons.smart_display_outlined,
                    size: iconSize,
                    color: AppTheme.primaryColor,
                  )
              ),
              activeIcon: SizedBox(
                width: activeIconSize,
                height: activeIconSize,
                child: Icon(
                  Icons.smart_display_sharp,
                  size: activeIconSize,
                  color: AppTheme.primaryColor,
                ),
              ),
              label: '',
            ),
            BottomNavigationBarItem(
              icon: SizedBox(
                width: iconSize,
                height: iconSize,
                child: Icon(
                  Icons.photo_camera_back_outlined,
                  size: iconSize,
                  color: AppTheme.primaryColor,
                ),
              ),
              activeIcon: SizedBox(
                width: activeIconSize,
                height: activeIconSize,
                child: Icon(
                  Icons.photo,
                  size: iconSize,
                  color: AppTheme.primaryColor,
                ),
              ),
              label: '',
            ),
          ],
        ),
      ),
    );
  }
}