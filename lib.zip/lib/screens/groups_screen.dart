import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:fruitsofspirit/controllers/groups_controller.dart';
import 'package:fruitsofspirit/utils/responsive_helper.dart';
import 'package:fruitsofspirit/routes/routes.dart';
import 'package:fruitsofspirit/widgets/cached_image.dart';
import 'package:fruitsofspirit/config/image_config.dart';

/// Groups Screen
/// Displays list of groups
class GroupsScreen extends GetView<GroupsController> {
  const GroupsScreen({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    // Professional responsive design for tablets/iPads
    final isTabletDevice = ResponsiveHelper.isTablet(context);
    final double? maxContentWidthValue = isTabletDevice 
        ? (ResponsiveHelper.isLargeTablet(context) ? 1200.0 : 840.0)
        : null;
    
    return Scaffold(
      backgroundColor: Colors.white,
      appBar: PreferredSize(
        preferredSize: Size.fromHeight(
          ResponsiveHelper.safeHeight(
            context,
            mobile: 70,
            tablet: 120,
            desktop: 90,
          ),
        ),
        child: Container(
          decoration: BoxDecoration(
            color: Colors.white,
            boxShadow: [
              BoxShadow(
                color: Colors.black.withOpacity(0.05),
                blurRadius: ResponsiveHelper.isMobile(context) ? 4 : 8,
                offset: Offset(0, ResponsiveHelper.isMobile(context) ? 2 : 4),
              ),
            ],
            border: Border(
              bottom: BorderSide(
                color: Colors.grey.withOpacity(0.15),
                width: ResponsiveHelper.isMobile(context) ? 0.5 : 1,
              ),
            ),
          ),
          child: SafeArea(
            bottom: false,
            child: Padding(
              padding: ResponsiveHelper.padding(
                context,
                horizontal: ResponsiveHelper.isMobile(context)
                    ? ResponsiveHelper.spacing(context, 16)
                    : ResponsiveHelper.isTablet(context)
                        ? ResponsiveHelper.spacing(context, 24)
                        : ResponsiveHelper.spacing(context, 32),
                vertical: ResponsiveHelper.isMobile(context)
                    ? ResponsiveHelper.spacing(context, 12)
                    : ResponsiveHelper.isTablet(context)
                        ? ResponsiveHelper.spacing(context, 14)
                        : ResponsiveHelper.spacing(context, 16),
              ),
              child: Row(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                crossAxisAlignment: CrossAxisAlignment.center,
                children: [
                  // Left Side - Logo
                  Expanded(
                    flex: ResponsiveHelper.isDesktop(context) ? 4 : 3,
                    child: Align(
                      alignment: Alignment.centerLeft,
                      child: CachedImage(
                        imageUrl: ImageConfig.logo,
                        width: double.infinity,
                        height: ResponsiveHelper.isMobile(context)
                            ? 52.0
                            : ResponsiveHelper.isTablet(context)
                                ? 58.0
                                : 64.0,
                        fit: BoxFit.contain,
                        errorWidget: Container(
                          height: ResponsiveHelper.isMobile(context)
                              ? 52.0
                              : ResponsiveHelper.isTablet(context)
                                  ? 58.0
                                  : 64.0,
                          alignment: Alignment.centerLeft,
                          child: Text(
                            'Groups',
                            style: TextStyle(
                              fontSize: ResponsiveHelper.fontSize(context, mobile: 20),
                              fontWeight: FontWeight.bold,
                              color: const Color(0xFF5F4628),
                            ),
                          ),
                        ),
                      ),
                    ),
                  ),
                  SizedBox(
                    width: ResponsiveHelper.isMobile(context)
                        ? 12.0
                        : ResponsiveHelper.isTablet(context)
                            ? 16.0
                            : 20.0,
                  ),
                  // Right Side - Back Button and Add Button
                  Row(
                    mainAxisSize: MainAxisSize.min,
                    children: [
                      Material(
                        color: Colors.transparent,
                        child: InkWell(
                          onTap: () => Get.toNamed(Routes.CREATE_GROUP),
                          borderRadius: BorderRadius.circular(30),
                          child: Container(
                            width: ResponsiveHelper.isMobile(context)
                                ? 40.0
                                : ResponsiveHelper.isTablet(context)
                                    ? 44.0
                                    : 48.0,
                            height: ResponsiveHelper.isMobile(context)
                                ? 40.0
                                : ResponsiveHelper.isTablet(context)
                                    ? 44.0
                                    : 48.0,
                            decoration: BoxDecoration(
                              gradient: const LinearGradient(
                                begin: Alignment.topLeft,
                                end: Alignment.bottomRight,
                                colors: [
                                  Color(0xFF8B4513),
                                  Color(0xFF6B3410),
                                ],
                              ),
                              shape: BoxShape.circle,
                              border: Border.all(
                                color: Colors.grey.withOpacity(0.2),
                                width: 1.5,
                              ),
                              boxShadow: [
                                BoxShadow(
                                  color: const Color(0xFF8B4513).withOpacity(0.3),
                                  blurRadius: 8,
                                  offset: const Offset(0, 2),
                                ),
                              ],
                            ),
                            child: Icon(
                              Icons.add_rounded,
                              color: Colors.white,
                              size: ResponsiveHelper.isMobile(context)
                                  ? 20.0
                                  : ResponsiveHelper.isTablet(context)
                                      ? 22.0
                                      : 24.0,
                            ),
                          ),
                        ),
                      ),
                      SizedBox(
                        width: ResponsiveHelper.isMobile(context)
                            ? 10.0
                            : ResponsiveHelper.isTablet(context)
                                ? 12.0
                                : 14.0,
                      ),
                      Material(
                        color: Colors.transparent,
                        child: InkWell(
                          onTap: () => Get.back(),
                          borderRadius: BorderRadius.circular(30),
                          child: Container(
                            width: ResponsiveHelper.isMobile(context)
                                ? 40.0
                                : ResponsiveHelper.isTablet(context)
                                    ? 44.0
                                    : 48.0,
                            height: ResponsiveHelper.isMobile(context)
                                ? 40.0
                                : ResponsiveHelper.isTablet(context)
                                    ? 44.0
                                    : 48.0,
                            decoration: BoxDecoration(
                              gradient: const LinearGradient(
                                begin: Alignment.topLeft,
                                end: Alignment.bottomRight,
                                colors: [
                                  Color(0xFF8B4513),
                                  Color(0xFF6B3410),
                                ],
                              ),
                              shape: BoxShape.circle,
                              border: Border.all(
                                color: Colors.grey.withOpacity(0.2),
                                width: 1.5,
                              ),
                              boxShadow: [
                                BoxShadow(
                                  color: const Color(0xFF8B4513).withOpacity(0.3),
                                  blurRadius: 8,
                                  offset: const Offset(0, 2),
                                ),
                              ],
                            ),
                            child: Icon(
                              Icons.arrow_back_rounded,
                              color: Colors.white,
                              size: ResponsiveHelper.isMobile(context)
                                  ? 20.0
                                  : ResponsiveHelper.isTablet(context)
                                      ? 22.0
                                      : 24.0,
                            ),
                          ),
                        ),
                      ),
                    ],
                  ),
                ],
              ),
            ),
          ),
        ),
      ),
      body: Column(
        children: [
          // Category Filter
          Container(
            padding: EdgeInsets.symmetric(
              horizontal: ResponsiveHelper.spacing(context, 16),
              vertical: ResponsiveHelper.spacing(context, 8),
            ),
            child: SingleChildScrollView(
              scrollDirection: Axis.horizontal,
              child: Row(
                children: [
                  _buildFilterChip(context, 'All', '', controller),
                  SizedBox(width: ResponsiveHelper.spacing(context, 8)),
                  _buildFilterChip(context, 'Prayer', 'Prayer', controller),
                  SizedBox(width: ResponsiveHelper.spacing(context, 8)),
                  _buildFilterChip(context, 'Bible Study', 'Bible Study', controller),
                  SizedBox(width: ResponsiveHelper.spacing(context, 8)),
                  _buildFilterChip(context, 'Fellowship', 'Fellowship', controller),
                ],
              ),
            ),
          ),
          
          // Groups List
          Expanded(
            child: Obx(() {
              if (controller.isLoading.value && controller.groups.isEmpty) {
                return Center(
                  child: CircularProgressIndicator(
                    color: const Color(0xFF8B4513),
                  ),
                );
              }

              if (controller.groups.isEmpty) {
                return Center(
                  child: Column(
                    mainAxisAlignment: MainAxisAlignment.center,
                    children: [
                      Icon(
                        Icons.group_outlined,
                        size: ResponsiveHelper.iconSize(context, mobile: 64),
                        color: Colors.grey,
                      ),
                      SizedBox(height: ResponsiveHelper.spacing(context, 16)),
                      Text(
                        'No groups available',
                        style: ResponsiveHelper.textStyle(
                          context,
                          fontSize: ResponsiveHelper.fontSize(context, mobile: 16),
                          color: Colors.grey,
                        ),
                      ),
                      SizedBox(height: ResponsiveHelper.spacing(context, 24)),
                      ElevatedButton.icon(
                        onPressed: () => Get.toNamed(Routes.CREATE_GROUP),
                        icon: const Icon(Icons.add, color: Colors.white),
                        label: Text(
                          'Create Group',
                          style: ResponsiveHelper.textStyle(
                            context,
                            fontSize: ResponsiveHelper.fontSize(context, mobile: 16),
                            fontWeight: FontWeight.bold,
                            color: Colors.white,
                          ),
                        ),
                        style: ElevatedButton.styleFrom(
                          backgroundColor: const Color(0xFF8B4513),
                          padding: EdgeInsets.symmetric(
                            horizontal: ResponsiveHelper.spacing(context, 24),
                            vertical: ResponsiveHelper.spacing(context, 12),
                          ),
                          shape: RoundedRectangleBorder(
                            borderRadius: BorderRadius.circular(
                              ResponsiveHelper.borderRadius(context, mobile: 12),
                            ),
                          ),
                        ),
                      ),
                    ],
                  ),
                );
              }

              return RefreshIndicator(
                onRefresh: () => controller.refresh(),
                color: const Color(0xFF8B4513),
                child: Center(
                  child: ResponsiveHelper.constrainedContent(
                    context: context,
                    maxWidth: maxContentWidthValue,
                    child: ListView.builder(
                  padding: EdgeInsets.all(ResponsiveHelper.spacing(context, 16)),
                  itemCount: controller.groups.length,
                  itemBuilder: (context, index) {
                    final group = controller.groups[index];
                    return _buildGroupCard(context, group, controller);
                  },
                    ),
                  ),
                ),
              );
            }),
          ),
        ],
      ),
    );
  }

  Widget _buildFilterChip(BuildContext context, String label, String category, GroupsController controller) {
    final isSelected = controller.selectedCategory.value == category;
    return FilterChip(
      avatar: Icon(
        isSelected ? Icons.check_circle : Icons.circle_outlined,
        size: ResponsiveHelper.iconSize(context, mobile: 14, tablet: 16, desktop: 18),
        color: isSelected ? Colors.white : const Color(0xFF5F4628),
      ),
      label: Text(
        label,
        style: TextStyle(
          fontSize: ResponsiveHelper.fontSize(context, mobile: 13),
          fontWeight: isSelected ? FontWeight.bold : FontWeight.w500,
          color: isSelected ? Colors.white : const Color(0xFF5F4628),
        ),
      ),
      selected: isSelected,
      onSelected: (selected) {
        if (selected) {
          controller.filterByCategory(category);
        } else {
          controller.clearFilter();
        }
      },
      selectedColor: const Color(0xFF9F9467),
      checkmarkColor: Colors.white,
      backgroundColor: Colors.grey[100],
      padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 8),
      side: BorderSide(
        color: isSelected ? const Color(0xFF9F9467) : Colors.grey[300]!,
        width: isSelected ? 2 : 1,
      ),
      shape: RoundedRectangleBorder(
        borderRadius: BorderRadius.circular(20),
      ),
    );
  }

  Widget _buildGroupCard(BuildContext context, Map<String, dynamic> group, GroupsController controller) {
    final baseUrl = 'https://fruitofthespirit.templateforwebsites.com/';
    String? imageUrl;
    if (group['group_image'] != null && group['group_image'].toString().isNotEmpty) {
      final imagePath = group['group_image'].toString();
      if (!imagePath.startsWith('http')) {
        imageUrl = baseUrl + (imagePath.startsWith('/') ? imagePath.substring(1) : imagePath);
      } else {
        imageUrl = imagePath;
      }
    }
    final isMember = controller.isMember(group['id'] as int);
    final memberCount = int.tryParse((group['member_count'] ?? 0).toString()) ?? 0;
    final category = group['category'] as String? ?? 'General';
    final description = group['description'] as String? ?? '';
    
    return Container(
      margin: EdgeInsets.only(bottom: ResponsiveHelper.spacing(context, 16)),
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(12),
        boxShadow: [
          BoxShadow(
            color: Colors.black.withOpacity(0.05),
            spreadRadius: 0,
            blurRadius: 8,
            offset: const Offset(0, 1),
          ),
        ],
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          // Group Image - Compact
          if (imageUrl != null && imageUrl.isNotEmpty)
            ClipRRect(
              borderRadius: const BorderRadius.vertical(
                top: Radius.circular(12),
              ),
              child: CachedImage(
                imageUrl: imageUrl,
                width: double.infinity,
                height: ResponsiveHelper.imageHeight(context, mobile: 140, tablet: 160, desktop: 180),
                fit: BoxFit.cover,
                errorWidget: Container(
                  width: double.infinity,
                  height: ResponsiveHelper.imageHeight(context, mobile: 140, tablet: 160, desktop: 180),
                  decoration: BoxDecoration(
                    gradient: LinearGradient(
                      begin: Alignment.topLeft,
                      end: Alignment.bottomRight,
                      colors: [
                        const Color(0xFFFAF6EC),
                        const Color(0xFF9F9467).withOpacity(0.3),
                      ],
                    ),
                  ),
                  child: Icon(
                    Icons.group_rounded,
                    size: ResponsiveHelper.iconSize(context, mobile: 50, tablet: 60, desktop: 70),
                    color: const Color(0xFF9F9467),
                  ),
                ),
              ),
            ),
          
          // Group Info - Compact
          Padding(
            padding: const EdgeInsets.all(16),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                // Name and Category Row
                Row(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Expanded(
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Text(
                            group['name'] as String? ?? 'Untitled Group',
                            style: ResponsiveHelper.textStyle(
                              context,
                              fontSize: ResponsiveHelper.fontSize(context, mobile: 15, tablet: 16, desktop: 17),
                              fontWeight: FontWeight.bold,
                              color: Colors.black,
                            ),
                            maxLines: 1,
                            overflow: TextOverflow.ellipsis,
                          ),
                          SizedBox(height: ResponsiveHelper.spacing(context, ResponsiveHelper.isMobile(context) ? 5 : 6)),
                          // Category Badge
                          Container(
                            padding: ResponsiveHelper.padding(
                              context,
                              horizontal: ResponsiveHelper.isMobile(context) ? 8 : 10,
                              vertical: ResponsiveHelper.isMobile(context) ? 3 : 4,
                            ),
                            decoration: BoxDecoration(
                              gradient: LinearGradient(
                                colors: [
                                  const Color(0xFF8B4513),
                                  const Color(0xFF9F9467),
                                ],
                              ),
                              borderRadius: BorderRadius.circular(ResponsiveHelper.borderRadius(context, mobile: 12)),
                            ),
                            child: Text(
                              category,
                              style: ResponsiveHelper.textStyle(
                                context,
                                fontSize: ResponsiveHelper.fontSize(context, mobile: 10, tablet: 11, desktop: 12),
                                fontWeight: FontWeight.bold,
                                color: Colors.white,
                              ),
                            ),
                          ),
                        ],
                      ),
                    ),
                    // Member Count
                    Row(
                      mainAxisSize: MainAxisSize.min,
                      children: [
                        Icon(
                          Icons.people_outline,
                          size: ResponsiveHelper.iconSize(context, mobile: 14, tablet: 16, desktop: 18),
                          color: Colors.grey[600],
                        ),
                        SizedBox(width: ResponsiveHelper.spacing(context, 4)),
                        Text(
                          '$memberCount',
                          style: ResponsiveHelper.textStyle(
                            context,
                            fontSize: ResponsiveHelper.fontSize(context, mobile: 12, tablet: 13, desktop: 14),
                            color: Colors.grey[600],
                            fontWeight: FontWeight.w500,
                          ),
                        ),
                      ],
                    ),
                  ],
                ),
                
                // Description
                if (description.isNotEmpty) ...[
                  SizedBox(height: ResponsiveHelper.spacing(context, ResponsiveHelper.isMobile(context) ? 8 : 10)),
                  Text(
                    description,
                    style: ResponsiveHelper.textStyle(
                      context,
                      fontSize: ResponsiveHelper.fontSize(context, mobile: 12, tablet: 13, desktop: 14),
                      color: Colors.black87,
                    ).copyWith(height: 1.4),
                    maxLines: 2,
                    overflow: TextOverflow.ellipsis,
                  ),
                ],
                
                SizedBox(height: ResponsiveHelper.spacing(context, ResponsiveHelper.isMobile(context) ? 12 : 14)),
                
                // Action Buttons
                Row(
                  children: [
                    // Join/Chat Button
                    Expanded(
                      child: ElevatedButton.icon(
                        onPressed: () async {
                          if (!isMember) {
                            final success = await controller.joinGroup(group['id'] as int);
                            if (success) {
                              Get.snackbar(
                                'Success',
                                'Joined group successfully',
                                backgroundColor: Colors.green,
                                colorText: Colors.white,
                                snackPosition: SnackPosition.BOTTOM,
                              );
                              controller.refresh();
                            }
                          } else {
                            Get.toNamed(
                              Routes.GROUP_CHAT,
                              arguments: group['id'],
                            );
                          }
                        },
                        icon: Icon(
                          isMember ? Icons.chat_bubble_outline : Icons.person_add,
                          size: ResponsiveHelper.iconSize(context, mobile: 14, tablet: 16, desktop: 18),
                          color: Colors.white,
                        ),
                        label: Text(
                          isMember ? 'Chat' : 'Join',
                          style: ResponsiveHelper.textStyle(
                            context,
                            fontSize: ResponsiveHelper.fontSize(context, mobile: 12, tablet: 13, desktop: 14),
                            fontWeight: FontWeight.bold,
                            color: Colors.white,
                          ),
                        ),
                        style: ElevatedButton.styleFrom(
                          backgroundColor: isMember ? const Color(0xFF8B4513) : const Color(0xFF4CAF50),
                          padding: ResponsiveHelper.padding(
                            context,
                            vertical: ResponsiveHelper.isMobile(context) ? 8 : 10,
                          ),
                          shape: RoundedRectangleBorder(
                            borderRadius: BorderRadius.circular(ResponsiveHelper.borderRadius(context, mobile: 8)),
                          ),
                          elevation: 0,
                        ),
                      ),
                    ),
                    SizedBox(width: ResponsiveHelper.spacing(context, ResponsiveHelper.isMobile(context) ? 8 : 10)),
                    // Details Button
                    Expanded(
                      child: OutlinedButton.icon(
                        onPressed: () {
                          Get.toNamed(
                            Routes.GROUP_DETAILS,
                            arguments: group['id'],
                          );
                        },
                        icon: Icon(
                          Icons.info_outline,
                          size: ResponsiveHelper.iconSize(context, mobile: 14, tablet: 16, desktop: 18),
                          color: const Color(0xFF8B4513),
                        ),
                        label: Text(
                          'Details',
                          style: ResponsiveHelper.textStyle(
                            context,
                            fontSize: ResponsiveHelper.fontSize(context, mobile: 12, tablet: 13, desktop: 14),
                            fontWeight: FontWeight.bold,
                            color: const Color(0xFF8B4513),
                          ),
                        ),
                        style: OutlinedButton.styleFrom(
                          side: const BorderSide(color: Color(0xFF8B4513), width: 1.5),
                          padding: const EdgeInsets.symmetric(vertical: 10),
                          shape: RoundedRectangleBorder(
                            borderRadius: BorderRadius.circular(8),
                          ),
                        ),
                      ),
                    ),
                  ],
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }
}

