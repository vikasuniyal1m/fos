import 'dart:convert';
import 'dart:io' show Platform;
import 'dart:async';
import 'package:flutter/foundation.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:get/get.dart';
import 'package:in_app_purchase/in_app_purchase.dart';
import 'package:in_app_purchase_storekit/in_app_purchase_storekit.dart';
import 'package:http/http.dart' as http;
import 'package:shared_preferences/shared_preferences.dart';
import 'package:fruitsofspirit/config/api_config.dart';
import 'package:fruitsofspirit/services/user_storage.dart';

class IAPService extends GetxService {
  final InAppPurchase _iap = InAppPurchase.instance;
  final RxList<ProductDetails> products = <ProductDetails>[].obs;
  final RxBool isInitialized = false.obs;
  final RxBool isLoading = false.obs;
  final RxString errorMessage = ''.obs;
  final RxBool premiumActive = false.obs;
  final RxBool purchasesDisabled = false.obs;
  final RxString disableReason = ''.obs;
  final RxBool isSandbox = true.obs;

  static const String _iosProductId = 'com.fruitsofspirit.ios.premium'; // Fruit-Full Life Pack
  static const String _androidProductId = 'com.fruitsofspirit.android.premium'; // Fruit-Full Life Pack
  
  static Set<String> get _productIds => {
    Platform.isIOS ? _iosProductId : _androidProductId
  };
  
  Stream<List<PurchaseDetails>>? _subscription;
  StreamSubscription<List<PurchaseDetails>>? _purchaseSubscription;

  static const int _maxRetries = 3;
  static const Duration _retryDelay = Duration(seconds: 2);
  
  // Purchase disable functionality
  static const String _purchasesDisabledKey = 'purchases_disabled';
  static const String _disableReasonKey = 'disable_reason';
  static const String _disableUntilKey = 'disable_until';

  // Detect if purchase is from sandbox environment
  bool _isSandboxEnvironment(String? verificationData) {
    if (verificationData == null || verificationData.isEmpty) {
      return false;
    }
    // Sandbox receipts contain "Sandbox" in the receipt data
    return verificationData.contains('Sandbox') || 
           verificationData.contains('sandbox') ||
           verificationData.contains('Environment=Sandbox');
  }

  @override
  void onInit() {
    super.onInit();
    _setupPurchaseStream(); // Setup stream once on init
    _loadPurchaseDisableStatus();
    WidgetsBinding.instance.addPostFrameCallback((_) {
      _delayedInitialize();
    });
    _fetchPremiumStatusFromBackend(); // Fetch premium status from backend
  }

  Future<void> _delayedInitialize() async {
    await Future.delayed(Duration(milliseconds: 500));
    await initialize();
  }

  Future<void> initialize() async {
    if (isInitialized.value && !errorMessage.value.contains('Store error')) {
      // Still refresh products if they're empty
      if (products.isEmpty) {
        await loadProducts();
      }
      return;
    }

    try {
      isLoading.value = true;
      errorMessage.value = '';

      // Add timeout and retry logic for StoreKit availability check
      debugPrint('IAP: Checking App Store availability...');
      final available = await _iap.isAvailable().timeout(
        const Duration(seconds: 10),
        onTimeout: () {
          debugPrint('IAP: ⚠️ App Store availability check timed out');
          return false;
        },
      );

      debugPrint('IAP: App Store available: $available');

      if (!available) {
        errorMessage.value = 'App Store is not available. Please check your internet connection and try again.';
        debugPrint('IAP: ❌ App Store not available - possible network or TestFlight environment issue');
        products.clear();
        // Load current premium status
        try {
          final prefs = await SharedPreferences.getInstance();
          premiumActive.value = prefs.getBool('is_lifetime_premium') ?? false;
        } catch (_) {}
        isInitialized.value = true;
        return;
      }

      await loadProducts();
      await _checkPendingPurchase();

      // Load current premium status
      try {
        final prefs = await SharedPreferences.getInstance();
        premiumActive.value = prefs.getBool('is_lifetime_premium') ?? false;
      } catch (_) {}
      isInitialized.value = true;
    } catch (e) {
      // Better error handling for StoreKit specific errors
      String errorMsg = 'Failed to initialize';
      
      debugPrint('IAP Initialization Error:');
      debugPrint('  Error: $e');
      debugPrint('  Error Type: ${e.runtimeType}');
      debugPrint('  Platform: ${Platform.isIOS ? "iOS" : "Android"}');
      
      if (e.toString().contains('storekit_no_response')) {
        errorMsg = 'Store error: Unable to connect to App Store. Please try again.';
        debugPrint('IAP: ⚠️ StoreKit no response during initialization');
      } else if (e.toString().contains('storekit')) {
        errorMsg = 'Store error: App Store is temporarily unavailable. Please try again later.';
        debugPrint('IAP: ⚠️ StoreKit error during initialization');
      } else {
        errorMsg = 'Failed to initialize: $e';
      }
      errorMessage.value = errorMsg;
      
      // Retry logic for StoreKit errors
      if (e.toString().contains('storekit') && !isInitialized.value) {
        Future.delayed(const Duration(seconds: 3), () {
          if (!isInitialized.value) {
            initialize();
          }
        });
      }
    } finally {
      isLoading.value = false;
    }
  }

  void _setupPurchaseStream() {
    if (_purchaseSubscription != null) return; // Already subscribed

    _purchaseSubscription = _iap.purchaseStream.listen(
      _handlePurchases,
      onDone: () {
        debugPrint('IAP: Purchase stream closed');
        _purchaseSubscription = null;
        // Auto-reconnect after a delay
        Future.delayed(const Duration(seconds: 2), () {
          if (_purchaseSubscription == null) {
            _setupPurchaseStream();
          }
        });
      },
      onError: (error) {
        debugPrint('IAP: Stream error: $error');
        _purchaseSubscription = null;
        // Auto-reconnect after a delay
        Future.delayed(const Duration(seconds: 3), () {
          if (_purchaseSubscription == null) {
            _setupPurchaseStream();
          }
        });
      },
    );
  }

  // Load products from store
  Future<void> loadProducts() async {
    try {
      // Add timeout for product query
      final response = await _iap.queryProductDetails(_productIds).timeout(
        const Duration(seconds: 15),
        onTimeout: () => ProductDetailsResponse(
          productDetails: [],
          notFoundIDs: _productIds.toList(),
          error: IAPError(
            source: 'store',
            code: 'timeout',
            message: 'Request timed out',
          ),
        ),
      );

      if (response.error != null) {
        String errorMsg = 'Store error: ${response.error!.message}';
        
        // Detailed logging for debugging
        debugPrint('IAP Error Details:');
        debugPrint('  Error Code: ${response.error!.code}');
        debugPrint('  Error Message: ${response.error!.message}');
        debugPrint('  Error Source: ${response.error!.source}');
        debugPrint('  Platform: ${Platform.isIOS ? "iOS" : "Android"}');
        debugPrint('  Product IDs queried: $_productIds');
        debugPrint('  Is Sandbox: $isSandbox');
        debugPrint('  Is Initialized: $isInitialized');
        
        // Better error messages for common StoreKit errors
        if (response.error!.code == 'storekit_no_response') {
          errorMsg = 'Store error: Unable to connect to App Store. Please check your connection and try again.';
          debugPrint('IAP: ⚠️ StoreKit no response - possible network or configuration issue');
        } else if (response.error!.code == 'storekit') {
          errorMsg = 'Store error: App Store is temporarily unavailable. Please try again later.';
          debugPrint('IAP: ⚠️ StoreKit general error - possible App Store issue');
        } else if (response.error!.message?.contains('product') == true) {
          errorMsg = 'Store error: Product configuration issue found. Please contact support.';
          debugPrint('IAP: ⚠️ Product configuration error - check App Store Connect');
        }
        
        errorMessage.value = errorMsg;
        products.clear();
        
        // Retry logic for temporary errors
        if (response.error!.code == 'storekit_no_response' || 
            response.error!.code == 'timeout') {
          Future.delayed(const Duration(seconds: 3), () {
            if (products.isEmpty && !isLoading.value) {
              loadProducts();
            }
          });
        }
        return;
      }

      if (response.productDetails.isEmpty) {
        if (response.notFoundIDs.isNotEmpty) {
          errorMessage.value = 'Premium product not found. Please check your App Store Connect configuration.';
          debugPrint('IAP: ❌ Product not found: ${response.notFoundIDs}');
        } else {
          errorMessage.value = 'No products available at the moment. Please try again later.';
          debugPrint('IAP: ❌ No products available');
        }
        products.clear();
      } else {
        products.assignAll(response.productDetails);
        errorMessage.value = ''; // Clear error on success
        debugPrint('IAP: ✅ Products loaded successfully: ${response.productDetails.length} products');
        for (var product in response.productDetails) {
          debugPrint('IAP:   - ${product.id}: ${product.title}');
        }
      }
    } catch (e) {
      String errorMsg = 'Error loading products';
      if (e.toString().contains('storekit_no_response')) {
        errorMsg = 'Store error: Unable to connect to App Store. Please try again.';
      } else if (e.toString().contains('timeout')) {
        errorMsg = 'Store error: Connection timed out. Please check your internet connection.';
      }
      
      errorMessage.value = errorMsg + ': $e';
      products.clear();
    }
  }

  // Purchase a package (type unused — single premium product)
  Future<bool> purchasePackage(int type) async {
    try {
      // Check if purchases are disabled
      if (purchasesDisabled.value) {
        errorMessage.value = 'Purchases are temporarily disabled: ${disableReason.value}';
        return false;
      }

      final targetId = Platform.isIOS ? _iosProductId : _androidProductId;

      if (!isInitialized.value) {
        await initialize();
      }

      if (products.isEmpty) {
        await loadProducts();
        // Wait a bit for products to load
        await Future.delayed(const Duration(milliseconds: 500));
      }

      final product = products.firstWhereOrNull((p) => p.id == targetId);

      if (product == null) {
        errorMessage.value = 'Premium product is not available. Please try again later.';
        return false;
      }

      isLoading.value = true;

      // Add timeout for store availability check
      final available = await _iap.isAvailable().timeout(
        const Duration(seconds: 10),
        onTimeout: () => false,
      );
      
      if (available && products.isNotEmpty) {
        final purchaseParam = PurchaseParam(productDetails: product);
        
        // Add timeout for purchase operation
        await _iap.buyNonConsumable(purchaseParam: purchaseParam).timeout(
          const Duration(seconds: 30),
          onTimeout: () {
            throw PlatformException(
              code: 'timeout',
              message: 'The purchase request timed out. Please try again.',
            );
          },
        );
        
        final prefs = await SharedPreferences.getInstance();
        await prefs.setString('iap_last_product_id', product.id);
        return true;
      } else {
        errorMessage.value = 'Store unavailable. Please check your connection and try again.';
        return false;
      }

    } on PlatformException catch (e) {
      String errorMsg = 'Purchase failed';
      
      // Better error handling for specific StoreKit errors
      if (e.code == 'storekit_no_response') {
        errorMsg = 'Store error: Unable to connect to App Store. Please try again.';
      } else if (e.code == 'payment_canceled') {
        errorMsg = 'Purchase was cancelled.';
      } else if (e.code == 'payment_not_allowed') {
        errorMsg = 'Purchases are not allowed on this device.';
      } else if (e.code == 'timeout') {
        errorMsg = 'Purchase timed out. Please try again.';
      } else if (e.code == 'billing_response_item_already_owned') {
        errorMsg = 'You already own this premium membership. Restoring your purchase...';
        // Handle already owned purchase scenario
        await handleAlreadyOwnedPurchase();
      } else if (e.code == 'billing_response' && e.message?.contains('already owned') == true) {
        errorMsg = 'You already own this premium membership. Restoring your purchase...';
        // Handle already owned purchase scenario
        await handleAlreadyOwnedPurchase();
      } else if (e.message?.contains('storekit') == true) {
        errorMsg = 'Store error: ${e.message ?? 'Unknown StoreKit error'}';
      } else {
        errorMsg = 'Purchase failed: ${e.code} ${e.message ?? ''}'.trim();
      }
      
      errorMessage.value = errorMsg;
      return false;
    } catch (e) {
      String errorMsg = 'Purchase failed';
      if (e.toString().contains('timeout')) {
        errorMsg = 'Purchase timed out. Please try again.';
      } else if (e.toString().contains('storekit')) {
        errorMsg = 'Store error: Unable to complete purchase. Please try again.';
      }
      
      errorMessage.value = errorMsg + '. Please try again.';
      return false;
    } finally {
      isLoading.value = false;
    }
  }

  Future<void> _handlePurchases(List<PurchaseDetails> purchases) async {
    for (final purchase in purchases) {
      debugPrint('IAP: Processing purchase status: ${purchase.status} for ${purchase.productID}');
      debugPrint('IAP: Purchase ID: ${purchase.purchaseID}');
      debugPrint('IAP: Transaction date: ${purchase.transactionDate}');
      
      switch (purchase.status) {
        case PurchaseStatus.purchased:
        case PurchaseStatus.restored:
          debugPrint('IAP: Starting backend verification...');
          
          // For Android: Acknowledge purchase IMMEDIATELY to prevent refunds
          // This must happen before any other operations to avoid cancellation
          if (Platform.isAndroid) {
            try {
              await _iap.completePurchase(purchase);
              debugPrint('IAP: ✅ Purchase acknowledged and completed for Android');
            } catch (e) {
              debugPrint('IAP: ❌ Error acknowledging purchase: $e');
              // Don't proceed if acknowledgment fails
              errorMessage.value = 'Failed to acknowledge purchase. Please try again.';
              return;
            }
          }
          
          // Complete the purchase on the platform side
          if (purchase.pendingCompletePurchase) {
            try {
              await _iap.completePurchase(purchase);
              debugPrint('IAP: ✅ Purchase completed on platform');
            } catch (e) {
              debugPrint('IAP: ❌ Error completing purchase: $e');
            }
          }
          
          // Activate premium immediately for better user experience
          await _activatePremium();
          
          // Then verify with backend in background
          bool verified = await _verifyOnBackend(purchase);
          if (verified) {
            debugPrint('IAP: Purchase verified and activated');
          } else {
            debugPrint('IAP: Backend verification failed, but premium activated locally');
            // Don't show error to user since they already have access
            debugPrint('IAP: Will retry backend verification later');
          }
          break;
          
        case PurchaseStatus.error:
          debugPrint('IAP: ❌ Purchase error details:');
          debugPrint('IAP:   Error code: ${purchase.error?.code}');
          debugPrint('IAP:   Error message: ${purchase.error?.message}');
          debugPrint('IAP:   Error details: ${purchase.error?.details}');
          debugPrint('IAP:   Product ID: ${purchase.productID}');
          debugPrint('IAP:   Purchase ID: ${purchase.purchaseID}');
          debugPrint('IAP:   Status: ${purchase.status}');
          debugPrint('IAP:   Pending complete: ${purchase.pendingCompletePurchase}');

          // Handle itemAlreadyOwned - user already owns the product
          final errorCode = purchase.error?.code ?? '';
          final errorMsg = purchase.error?.message ?? '';
          if (errorCode.contains('already_owned') ||
              errorCode.contains('itemAlreadyOwned') ||
              errorMsg.contains('already owned') ||
              errorMsg.contains('AlreadyOwned')) {
            debugPrint('IAP: 🔄 Item already owned - attempting restore...');
            await handleAlreadyOwnedPurchase();
            if (purchase.pendingCompletePurchase) {
              try {
                await _iap.completePurchase(purchase);
                debugPrint('IAP: ✅ Already-owned purchase completed');
              } catch (e) {
                debugPrint('IAP: ❌ Error completing already-owned purchase: $e');
              }
            }
          } else {
            errorMessage.value = 'Purchase failed: ${purchase.error?.message ?? 'Unknown error'}';
          }
          break;
          
        case PurchaseStatus.pending:
          debugPrint('IAP: Purchase pending - storing for retry');
          await _storePendingPurchase(purchase);
          break;
          
        default:
          debugPrint('IAP: Unhandled purchase status: ${purchase.status}');
          break;
      }
    }
  }

  Future<void> _activatePremium() async {
    try {
      debugPrint('IAP: === Activating premium ===');
      final prefs = await SharedPreferences.getInstance();
      await prefs.setBool('is_lifetime_premium', true);
      premiumActive.value = true;
      errorMessage.value = '';
      debugPrint('IAP: ✅ Premium activated successfully');
      debugPrint('IAP: premiumActive.value: ${premiumActive.value}');
    } catch (e) {
      debugPrint('IAP: ❌ Error activating premium: $e');
      debugPrint('IAP: Exception type: ${e.runtimeType}');
    }
  }

  Future<void> _storePendingPurchase(PurchaseDetails purchase) async {
    try {
      final prefs = await SharedPreferences.getInstance();
      final userId = await UserStorage.getUserId();
      
      final pendingData = {
        'product_id': purchase.productID,
        'transaction_id': purchase.purchaseID,
        'verification_data': purchase.verificationData.localVerificationData,
        'server_data': purchase.verificationData.serverVerificationData,
        'user_id': userId?.toString() ?? '',
        'timestamp': DateTime.now().toIso8601String(),
      };
      
      await prefs.setString('pending_purchase', json.encode(pendingData));
      debugPrint('IAP: Stored pending purchase for retry');
    } catch (e) {
      debugPrint('IAP: Error storing pending purchase: $e');
    }
  }

  Future<void> _checkPendingPurchase() async {
    try {
      final prefs = await SharedPreferences.getInstance();
      final userId = await UserStorage.getUserId();
      final pendingJson = prefs.getString('pending_purchase');
      
      if (pendingJson != null && userId != null) {
        final data = json.decode(pendingJson);
        
        final success = await _verifyManual(
          productId: data['product_id'] ?? '',
          transactionId: data['transaction_id'],
          verificationData: data['verification_data'] ?? '',
          serverData: data['server_data'],
        );

        if (success) {
          debugPrint('IAP: Pending purchase verified successfully during retry');
          await _clearPendingPurchase();
        } else {
          debugPrint('IAP: Pending purchase retry verification failed');
        }
      }
    } catch (e) {
      debugPrint('IAP: Error checking pending purchase: $e');
    }
  }

  Future<bool> _verifyOnBackend(PurchaseDetails purchase) async {
    return _verifyManual(
      productId: purchase.productID,
      transactionId: purchase.purchaseID,
      verificationData: purchase.verificationData.serverVerificationData,
      serverData: purchase.verificationData.serverVerificationData,
      isPending: false,
    );
  }

  Future<bool> _verifyManual({
    required String productId,
    String? transactionId,
    required String verificationData,
    String? serverData,
    bool isPending = true,
  }) async {
    try {
      debugPrint('IAP: === Starting verification ===');
      debugPrint('IAP: Product ID: $productId');
      debugPrint('IAP: Transaction ID: $transactionId');
      debugPrint('IAP: Is pending: $isPending');
      debugPrint('IAP: Verification data length: ${verificationData.length}');
      debugPrint('IAP: Server data length: ${serverData?.length ?? 0}');
      
      final userIdInt = await UserStorage.getUserId();
      final userId = userIdInt?.toString() ?? '';
      
      debugPrint('IAP: User ID: $userId');

      if (userId.isEmpty) {
        debugPrint('IAP: ❌ No user logged in for verification');
        if (!isPending) {
            // Need to store it so we can retry after login
            final storedData = {
              'product_id': productId,
              'transaction_id': transactionId,
              'verification_data': verificationData,
              'server_data': serverData,
              'timestamp': DateTime.now().toIso8601String(),
            };
            final prefs = await SharedPreferences.getInstance();
            await prefs.setString('pending_purchase', json.encode(storedData));
            debugPrint('IAP: Stored purchase for retry after login');
        }
        return false;
      }

      debugPrint('IAP: Calling backend API: ${ApiConfig.verifyPurchase}');
      
      final response = await http.post(
        Uri.parse(ApiConfig.verifyPurchase),
        headers: {
          'Content-Type': 'application/json',
          'Accept': 'application/json',
        },
        body: json.encode({
          'receipt': verificationData,
          'product_id': productId,
          'transaction_id': transactionId,
          'user_id': userId,
          'platform': Platform.isIOS ? 'apple' : 'android',
          'is_sandbox': isSandbox.value,
        }),
      );

      debugPrint('IAP: Backend response status code: ${response.statusCode}');
      debugPrint('IAP: Backend response body: ${response.body}');

      if (response.statusCode == 200) {
        final responseData = json.decode(response.body);
        debugPrint('IAP: Parsed response: $responseData');
        
        if (responseData['success'] == true) {
          debugPrint('IAP: ✅ Backend verification successful');
          if (!isPending) {
            await _activatePremium();
          }
          return true;
        } else {
          debugPrint('IAP: ❌ Backend returned success=false');
          debugPrint('IAP: Error message from backend: ${responseData['error'] ?? 'No error message'}');
        }
      } else {
        debugPrint('IAP: ❌ Backend returned non-200 status: ${response.statusCode}');
      }
      
      return false;
    } catch (e) {
      debugPrint('IAP: ❌ Verification exception: $e');
      debugPrint('IAP: Exception type: ${e.runtimeType}');
      return false;
    }
  }

  Future<void> _clearPendingPurchase() async {
    try {
      final prefs = await SharedPreferences.getInstance();
      await prefs.remove('pending_purchase');
      debugPrint('IAP: Cleared pending purchase');
    } catch (e) {
      debugPrint('IAP: Error clearing pending purchase: $e');
    }
  }

  Future<bool> hasPremium() async {
    final prefs = await SharedPreferences.getInstance();
    return prefs.getBool('is_lifetime_premium') ?? false;
  }

  Future<bool> restorePurchases() async {
    try {
      isLoading.value = true;
      errorMessage.value = '';
      
      // Add timeout for restore operation
      await _iap.restorePurchases().timeout(
        const Duration(seconds: 30),
        onTimeout: () {
          throw PlatformException(
            code: 'timeout',
            message: 'The restore request timed out. Please try again.',
          );
        },
      );
      
      return true;
    } on PlatformException catch (e) {
      String errorMsg = 'Restore failed';
      
      // Better error handling for specific StoreKit errors
      if (e.code == 'storekit_no_response') {
        errorMsg = 'Store error: Unable to connect to App Store. Please try again.';
      } else if (e.code == 'No active account') {
        errorMsg = 'Please sign in to your App Store account to restore purchases.';
      } else if (e.code == 'payment_canceled') {
        errorMsg = 'Restore was cancelled.';
      } else if (e.code == 'timeout') {
        errorMsg = 'Restore timed out. Please check your connection and try again.';
      } else if (e.message?.contains('storekit') == true) {
        errorMsg = 'Store error: ${e.message ?? 'Unknown StoreKit error'}';
      } else {
        errorMsg = 'Restore failed: ${e.code} ${e.message ?? ''}'.trim();
      }
      
      errorMessage.value = errorMsg;
      return false;
    } catch (e) {
      String errorMsg = 'Restore failed';
      if (e.toString().contains('timeout')) {
        errorMsg = 'Restore timed out. Please check your internet connection.';
      } else if (e.toString().contains('storekit')) {
        errorMsg = 'Store error: Unable to restore purchases. Please try again.';
      } else if (e.toString().contains('connection') || e.toString().contains('network')) {
        errorMsg = 'Network issue during restore. Check your internet and try again.';
      }
      
      errorMessage.value = errorMsg + '. Please try again.';
      return false;
    } finally {
      isLoading.value = false;
    }
  }

  Future<void> _fetchPremiumStatusFromBackend() async {
    try {
      final userIdInt = await UserStorage.getUserId();
      if (userIdInt == null || userIdInt == 0) {
        debugPrint('IAP: No user ID, skipping premium status fetch');
        return;
      }

      debugPrint('IAP: Fetching premium status for user ID: $userIdInt');
      debugPrint('IAP: API URL: ${ApiConfig.checkPremiumStatus}?user_id=$userIdInt');
      
      final response = await http.get(
        Uri.parse('${ApiConfig.checkPremiumStatus}?user_id=$userIdInt'),
        headers: ApiConfig.jsonHeaders,
      );

      debugPrint('IAP: Backend response status: ${response.statusCode}');
      debugPrint('IAP: Backend response body: ${response.body}');

      if (response.statusCode == 200) {
        final data = json.decode(response.body);
        debugPrint('IAP: Parsed response data: $data');
        
        if (data['success'] == true && data['is_premium'] == true) {
          final prefs = await SharedPreferences.getInstance();
          await prefs.setBool('is_lifetime_premium', true);
          premiumActive.value = true;
          debugPrint('IAP: ✅ Premium status restored from backend');
        } else {
          debugPrint('IAP: User is not premium or failed response');
          debugPrint('IAP: success: ${data['success']}, is_premium: ${data['is_premium']}');
        }
      } else {
        debugPrint('IAP: Backend returned non-200 status: ${response.statusCode}');
      }
    } catch (e) {
      debugPrint('IAP: Error fetching premium status from backend: $e');
    }
  }

  /// Update premium status from login response
  Future<void> updatePremiumStatusFromLogin(Map<String, dynamic> userData) async {
    try {
      final isPremium = userData['is_lifetime_premium'] ?? 0;
      debugPrint('IAP: Updating premium status from login: is_lifetime_premium = $isPremium');
      
      if (isPremium == 1) {
        final prefs = await SharedPreferences.getInstance();
        await prefs.setBool('is_lifetime_premium', true);
        premiumActive.value = true;
        debugPrint('IAP: ✅ Premium status updated from login response');
      } else {
        premiumActive.value = false;
        debugPrint('IAP: User is not premium according to login data');
      }
    } catch (e) {
      debugPrint('IAP: Error updating premium status from login: $e');
    }
  }

  /// Load purchase disable status from SharedPreferences
  Future<void> _loadPurchaseDisableStatus() async {
    try {
      final prefs = await SharedPreferences.getInstance();
      final isDisabled = prefs.getBool(_purchasesDisabledKey) ?? false;
      final reason = prefs.getString(_disableReasonKey) ?? '';
      final disableUntil = prefs.getString(_disableUntilKey);
      
      // Check if disable period has expired
      if (isDisabled && disableUntil != null) {
        final disableUntilTime = DateTime.parse(disableUntil);
        if (DateTime.now().isAfter(disableUntilTime)) {
          // Disable period expired, enable purchases
          await _savePurchaseDisableStatus(false, '', null);
        } else {
          // Still disabled
          purchasesDisabled.value = true;
          disableReason.value = reason;
        }
      }
    } catch (e) {
      debugPrint('Error loading purchase disable status: $e');
    }
  }

  /// Save purchase disable status to SharedPreferences
  Future<void> _savePurchaseDisableStatus(bool isDisabled, String reason, DateTime? disableUntil) async {
    try {
      final prefs = await SharedPreferences.getInstance();
      await prefs.setBool(_purchasesDisabledKey, isDisabled);
      await prefs.setString(_disableReasonKey, reason);
      if (disableUntil != null) {
        await prefs.setString(_disableUntilKey, disableUntil.toIso8601String());
      } else {
        await prefs.remove(_disableUntilKey);
      }
      
      purchasesDisabled.value = isDisabled;
      disableReason.value = reason;
      debugPrint('IAP: Purchase disable status saved - $isDisabled, $reason');
    } catch (e) {
      debugPrint('Error saving purchase disable status: $e');
    }
  }

  // Disable purchases temporarily
  Future<void> disablePurchasesTemporarily({
    required String reason,
    Duration? duration,
  }) async {
    final disableUntil = duration != null 
        ? DateTime.now().add(duration)
        : null;
    
    await _savePurchaseDisableStatus(true, reason, disableUntil);
  }

  // Enable purchases
  Future<void> enablePurchases() async {
    await _savePurchaseDisableStatus(false, '', null);
  }

  // Check if purchases are disabled
  bool arePurchasesDisabled() {
    return purchasesDisabled.value;
  }

  // Get disable reason
  String getDisableReason() {
    return disableReason.value;
  }

  // Handle already owned purchases by checking with Google Play
  Future<void> handleAlreadyOwnedPurchase() async {
    try {
      debugPrint('IAP: Handling already owned purchase scenario');
      
      // First try to restore purchases which will query existing purchases
      await restorePurchases();
      
      // Also check if premium is already active locally
      final prefs = await SharedPreferences.getInstance();
      final isPremium = prefs.getBool('is_lifetime_premium') ?? false;
      
      if (isPremium) {
        premiumActive.value = true;
        debugPrint('IAP: ✅ Premium status already active locally');
      } else {
        // Try to fetch from backend
        await _fetchPremiumStatusFromBackend();
      }
    } catch (e) {
      debugPrint('IAP: Error handling already owned purchase: $e');
    }
  }
}
