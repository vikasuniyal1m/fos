import 'dart:async';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:get/get.dart';
import 'package:video_player/video_player.dart';
import 'package:cached_network_image/cached_network_image.dart';
import 'package:fruitsofspirit/controllers/shorts_controller.dart';
import 'package:fruitsofspirit/services/shorts_service.dart';
import 'package:fruitsofspirit/services/user_storage.dart';
import 'package:fruitsofspirit/utils/share_helper.dart';
import 'package:fruitsofspirit/utils/responsive_helper.dart';
import 'package:fruitsofspirit/widgets/short_comments_sheet.dart';
import 'package:fruitsofspirit/routes/routes.dart';

/// Vertical Shorts feed — TikTok/Reels-style standalone screen
class ShortsScreen extends StatefulWidget {
  const ShortsScreen({Key? key}) : super(key: key);

  @override
  State<ShortsScreen> createState() => _ShortsScreenState();
}

class _ShortsScreenState extends State<ShortsScreen> {
  final controller = Get.put(ShortsController());
  final PageController _pageController = PageController();
  final Map<int, VideoPlayerController> _players = {};
  int _currentIndex = 0;

  static const Color _gold = Color(0xFFD4AF37);

  @override
  void initState() {
    super.initState();
    SystemChrome.setEnabledSystemUIMode(SystemUiMode.immersiveSticky);
    unawaited(controller.loadShorts(refresh: true));
    controller.startPolling();
  }

  @override
  void dispose() {
    SystemChrome.setEnabledSystemUIMode(SystemUiMode.edgeToEdge);
    controller.stopPolling();
    _disposeAllPlayers();
    _pageController.dispose();
    super.dispose();
  }

  void _disposeAllPlayers() {
    for (final p in _players.values) {
      p.dispose();
    }
    _players.clear();
  }

  void _disposePlayerAt(int index) {
    _players.remove(index)?.dispose();
  }

  Future<void> _initPlayer(int index) async {
    if (index < 0 || index >= controller.shorts.length) return;
    if (_players.containsKey(index)) return;

    final url = ShortsService.getVideoUrl(controller.shorts[index]);
    if (url == null || url.isEmpty) return;

    final player = VideoPlayerController.networkUrl(Uri.parse(url));
    _players[index] = player;
    try {
      await player.initialize();
      player.setLooping(true);
      if (mounted && _currentIndex == index) {
        await player.play();
      }
      if (mounted) setState(() {});
    } catch (_) {
      _disposePlayerAt(index);
    }
  }

  void _onPageChanged(int index) {
    _players[_currentIndex]?.pause();
    _currentIndex = index;
    unawaited(_initPlayer(index));
    _players[index]?.play();
    unawaited(controller.recordView(index));

    if (index >= controller.shorts.length - 3 && controller.hasMore.value) {
      unawaited(controller.loadShorts());
    }

    if (index > 0) _disposePlayerAt(index - 2);
    unawaited(_initPlayer(index + 1));
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.black,
      body: Obx(() {
        if (controller.isLoading.value && controller.shorts.isEmpty) {
          return const Center(child: CircularProgressIndicator(color: _gold));
        }
        if (controller.shorts.isEmpty) {
          return _buildEmptyState();
        }
        return Stack(
          children: [
            PageView.builder(
              controller: _pageController,
              scrollDirection: Axis.vertical,
              itemCount: controller.shorts.length,
              onPageChanged: _onPageChanged,
              itemBuilder: (context, index) {
                unawaited(_initPlayer(index));
                return _ShortPage(
                  short: controller.shorts[index],
                  index: index,
                  player: _players[index],
                  gold: _gold,
                  onLike: () => controller.toggleLike(index),
                  onSave: () => controller.toggleSave(index),
                  onComment: () => _openComments(index),
                  onShare: () => _shareShort(index),
                  onMore: () => _showMoreOptions(index),
                );
              },
            ),
            _buildTopBar(context),
          ],
        );
      }),
      floatingActionButton: FloatingActionButton(
        onPressed: () => Get.toNamed(Routes.UPLOAD_SHORT),
        backgroundColor: _gold,
        child: const Icon(Icons.add, color: Colors.white),
      ),
    );
  }

  Widget _buildTopBar(BuildContext context) {
    return SafeArea(
      child: Padding(
        padding: ResponsiveHelper.padding(context, horizontal: 16, vertical: 8),
        child: Row(
          children: [
            IconButton(
              icon: const Icon(Icons.arrow_back, color: Colors.white),
              onPressed: () => Get.back(),
            ),
            const Expanded(
              child: Text(
                'Shorts',
                textAlign: TextAlign.center,
                style: TextStyle(
                  color: Colors.white,
                  fontSize: 20,
                  fontWeight: FontWeight.w600,
                  fontFamily: 'Georgia',
                ),
              ),
            ),
            IconButton(
              icon: const Icon(Icons.bookmark_border, color: Colors.white),
              onPressed: () => Get.toNamed(Routes.SAVED_SHORTS),
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildEmptyState() {
    return Center(
      child: Column(
        mainAxisAlignment: MainAxisAlignment.center,
        children: [
          const Icon(Icons.play_circle_outline, color: Colors.white54, size: 64),
          const SizedBox(height: 16),
          const Text('No shorts yet', style: TextStyle(color: Colors.white70)),
          const SizedBox(height: 24),
          ElevatedButton(
            onPressed: () => Get.toNamed(Routes.UPLOAD_SHORT),
            style: ElevatedButton.styleFrom(backgroundColor: _gold),
            child: const Text('Upload Short', style: TextStyle(color: Colors.white)),
          ),
        ],
      ),
    );
  }

  void _openComments(int index) {
    final short = controller.shorts[index];
    final shortId = ShortsService.shortId(short);
    showModalBottomSheet(
      context: context,
      isScrollControlled: true,
      backgroundColor: Colors.transparent,
      builder: (_) => ShortCommentsSheet(
        shortId: shortId,
        feedIndex: index,
        controller: controller,
      ),
    );
  }

  Future<void> _shareShort(int index) async {
    final short = controller.shorts[index];
    final id = ShortsService.shortId(short);
    final title = short['title']?.toString() ?? 'Short';
    final description = short['description']?.toString();
    final mediaUrl = ShortsService.getVideoUrl(short);

    await showModalBottomSheet(
      context: context,
      backgroundColor: Colors.white,
      shape: const RoundedRectangleBorder(
        borderRadius: BorderRadius.vertical(top: Radius.circular(16)),
      ),
      builder: (ctx) => SafeArea(
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            ListTile(
              leading: const Icon(Icons.link),
              title: const Text('Copy Link'),
              onTap: () async {
                Navigator.pop(ctx);
                final link = 'https://fosmessenger.com/share/short/$id';
                await Clipboard.setData(ClipboardData(text: link));
                unawaited(controller.trackShare(index, shareType: 'copy_link'));
                if (mounted) {
                  ScaffoldMessenger.of(context).showSnackBar(
                    const SnackBar(content: Text('Link copied')),
                  );
                }
              },
            ),
            ListTile(
              leading: const Icon(Icons.share),
              title: const Text('Share'),
              onTap: () async {
                Navigator.pop(ctx);
                await ShareHelper.shareContent(
                  contentType: 'short',
                  contentId: id,
                  title: title,
                  content: description,
                  mediaUrl: mediaUrl,
                  context: context,
                );
                unawaited(controller.trackShare(index, shareType: 'native'));
              },
            ),
            ListTile(
              leading: const Icon(Icons.send),
              title: const Text('Share in App'),
              onTap: () async {
                Navigator.pop(ctx);
                unawaited(controller.trackShare(index, shareType: 'internal'));
                if (mounted) {
                  ScaffoldMessenger.of(context).showSnackBar(
                    const SnackBar(content: Text('Share tracked')),
                  );
                }
              },
            ),
          ],
        ),
      ),
    );
  }

  void _showMoreOptions(int index) async {
    final short = controller.shorts[index];
    final shortId = ShortsService.shortId(short);
    final ownerId = int.tryParse(short['user_id']?.toString() ?? '0') ?? 0;
    final currentUserId = await UserStorage.getUserId() ?? 0;
    final isOwner = ownerId == currentUserId;

    if (!mounted) return;
    showModalBottomSheet(
      context: context,
      builder: (ctx) => SafeArea(
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            if (isOwner)
              ListTile(
                leading: const Icon(Icons.delete, color: Colors.red),
                title: const Text('Delete Short'),
                onTap: () async {
                  Navigator.pop(ctx);
                  final confirm = await showDialog<bool>(
                    context: context,
                    builder: (d) => AlertDialog(
                      title: const Text('Delete Short?'),
                      content: const Text('This cannot be undone.'),
                      actions: [
                        TextButton(onPressed: () => Navigator.pop(d, false), child: const Text('Cancel')),
                        TextButton(
                          onPressed: () => Navigator.pop(d, true),
                          child: const Text('Delete', style: TextStyle(color: Colors.red)),
                        ),
                      ],
                    ),
                  );
                  if (confirm == true) {
                    await controller.deleteOwnShort(shortId, index);
                  }
                },
              )
            else
              ListTile(
                leading: const Icon(Icons.flag),
                title: const Text('Report'),
                onTap: () {
                  Navigator.pop(ctx);
                  _showReportDialog(shortId);
                },
              ),
          ],
        ),
      ),
    );
  }

  void _showReportDialog(int shortId) {
    const reasons = ['Spam', 'Harassment', 'Inappropriate Content', 'Copyright', 'Other'];
    showDialog(
      context: context,
      builder: (ctx) => AlertDialog(
        title: const Text('Report Short'),
        content: SizedBox(
          width: double.maxFinite,
          child: ListView(
            shrinkWrap: true,
            children: reasons.map((r) => ListTile(
              title: Text(r),
              onTap: () async {
                Navigator.pop(ctx);
                await controller.reportShort(shortId, r);
                if (mounted) {
                  ScaffoldMessenger.of(context).showSnackBar(
                    const SnackBar(content: Text('Report submitted')),
                  );
                }
              },
            )).toList(),
          ),
        ),
      ),
    );
  }
}

class _ShortPage extends StatelessWidget {
  final Map<String, dynamic> short;
  final int index;
  final VideoPlayerController? player;
  final Color gold;
  final VoidCallback onLike;
  final VoidCallback onSave;
  final VoidCallback onComment;
  final VoidCallback onShare;
  final VoidCallback onMore;

  const _ShortPage({
    required this.short,
    required this.index,
    required this.player,
    required this.gold,
    required this.onLike,
    required this.onSave,
    required this.onComment,
    required this.onShare,
    required this.onMore,
  });

  @override
  Widget build(BuildContext context) {
    final thumb = ShortsService.getThumbnailUrl(short);
    final isLiked = short['is_liked'] == true;
    final isSaved = short['is_saved'] == true;
    final likes = int.tryParse(short['total_likes']?.toString() ?? '0') ?? 0;
    final comments = int.tryParse(short['total_comments']?.toString() ?? '0') ?? 0;
    final shares = int.tryParse(short['total_shares']?.toString() ?? '0') ?? 0;
    final userName = short['user_name']?.toString() ?? 'User';
    final title = short['title']?.toString() ?? '';
    final description = short['description']?.toString() ?? '';

    return Stack(
      fit: StackFit.expand,
      children: [
        if (player != null && player!.value.isInitialized)
          FittedBox(
            fit: BoxFit.cover,
            child: SizedBox(
              width: player!.value.size.width,
              height: player!.value.size.height,
              child: VideoPlayer(player!),
            ),
          )
        else if (thumb != null)
          CachedNetworkImage(imageUrl: thumb, fit: BoxFit.cover)
        else
          Container(color: Colors.grey.shade900),

        Container(
          decoration: BoxDecoration(
            gradient: LinearGradient(
              begin: Alignment.bottomCenter,
              end: Alignment.topCenter,
              colors: [Colors.black.withOpacity(0.7), Colors.transparent],
              stops: const [0.0, 0.5],
            ),
          ),
        ),

        Positioned(
          right: 12,
          bottom: 100,
          child: Column(
            children: [
              _ActionButton(
                icon: isLiked ? Icons.favorite : Icons.favorite_border,
                label: ShortsService.formatCount(likes),
                color: isLiked ? Colors.red : Colors.white,
                onTap: onLike,
              ),
              const SizedBox(height: 20),
              _ActionButton(
                icon: Icons.chat_bubble_outline,
                label: ShortsService.formatCount(comments),
                onTap: onComment,
              ),
              const SizedBox(height: 20),
              _ActionButton(
                icon: Icons.share,
                label: shares > 0 ? ShortsService.formatCount(shares) : 'Share',
                onTap: onShare,
              ),
              const SizedBox(height: 20),
              _ActionButton(
                icon: isSaved ? Icons.bookmark : Icons.bookmark_border,
                label: isSaved ? 'Saved' : 'Save',
                color: isSaved ? gold : Colors.white,
                onTap: onSave,
              ),
              const SizedBox(height: 20),
              GestureDetector(
                onTap: onMore,
                child: const Icon(Icons.more_vert, color: Colors.white, size: 28),
              ),
            ],
          ),
        ),

        Positioned(
          left: 16,
          right: 80,
          bottom: 32,
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Row(
                children: [
                  Text(
                    '@${userName.replaceAll(' ', '_').toLowerCase()}',
                    style: const TextStyle(color: Colors.white, fontWeight: FontWeight.bold),
                  ),
                  const SizedBox(width: 8),
                  Container(
                    padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 4),
                    decoration: BoxDecoration(
                      color: gold,
                      borderRadius: BorderRadius.circular(4),
                    ),
                    child: const Text('Follow', style: TextStyle(color: Colors.white, fontSize: 12)),
                  ),
                ],
              ),
              if (title.isNotEmpty) ...[
                const SizedBox(height: 8),
                Text(title, style: const TextStyle(color: Colors.white, fontWeight: FontWeight.w600)),
              ],
              if (description.isNotEmpty) ...[
                const SizedBox(height: 4),
                Text(
                  description,
                  maxLines: 2,
                  overflow: TextOverflow.ellipsis,
                  style: TextStyle(color: Colors.white.withOpacity(0.9)),
                ),
              ],
            ],
          ),
        ),
      ],
    );
  }
}

class _ActionButton extends StatelessWidget {
  final IconData icon;
  final String label;
  final Color color;
  final VoidCallback onTap;

  const _ActionButton({
    required this.icon,
    required this.label,
    this.color = Colors.white,
    required this.onTap,
  });

  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTap: onTap,
      child: Column(
        children: [
          Icon(icon, color: color, size: 32),
          const SizedBox(height: 4),
          Text(
            label,
            style: TextStyle(color: color, fontSize: 12, fontWeight: FontWeight.w500),
          ),
        ],
      ),
    );
  }
}
