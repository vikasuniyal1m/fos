import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:fruitsofspirit/controllers/groups_controller.dart';
import 'package:fruitsofspirit/utils/responsive_helper.dart';
import 'package:fruitsofspirit/routes/routes.dart';
import 'package:fruitsofspirit/widgets/cached_image.dart';
import 'package:fruitsofspirit/config/image_config.dart';

/// Group Details Screen
/// Shows single group with members
class GroupDetailsScreen extends GetView<GroupsController> {
  const GroupDetailsScreen({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    final groupId = Get.arguments as int? ?? 0;
    
    if (groupId > 0 && (controller.selectedGroup.isEmpty || controller.selectedGroup['id'] != groupId)) {
      WidgetsBinding.instance.addPostFrameCallback((_) {
        controller.loadGroupDetails(groupId);
      });
    }

    return Scaffold(
      backgroundColor: Colors.white,
      appBar: PreferredSize(
        preferredSize: Size.fromHeight(
          ResponsiveHelper.safeHeight(
            context,
            mobile: 70,
            tablet: 120,
            desktop: 90,
          ),
        ),
        child: Container(
          decoration: BoxDecoration(
            color: Colors.white,
            boxShadow: [
              BoxShadow(
                color: Colors.black.withOpacity(0.05),
                blurRadius: ResponsiveHelper.isMobile(context) ? 4 : 8,
                offset: Offset(0, ResponsiveHelper.isMobile(context) ? 2 : 4),
              ),
            ],
            border: Border(
              bottom: BorderSide(
                color: Colors.grey.withOpacity(0.15),
                width: ResponsiveHelper.isMobile(context) ? 0.5 : 1,
              ),
            ),
          ),
          child: SafeArea(
            bottom: false,
            child: Padding(
              padding: ResponsiveHelper.padding(
                context,
                horizontal: ResponsiveHelper.isMobile(context)
                    ? ResponsiveHelper.spacing(context, 16)
                    : ResponsiveHelper.isTablet(context)
                        ? ResponsiveHelper.spacing(context, 24)
                        : ResponsiveHelper.spacing(context, 32),
                vertical: ResponsiveHelper.isMobile(context)
                    ? ResponsiveHelper.spacing(context, 12)
                    : ResponsiveHelper.isTablet(context)
                        ? ResponsiveHelper.spacing(context, 14)
                        : ResponsiveHelper.spacing(context, 16),
              ),
              child: Row(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                crossAxisAlignment: CrossAxisAlignment.center,
                children: [
                  // Left Side - Logo
                  Expanded(
                    flex: ResponsiveHelper.isDesktop(context) ? 4 : 3,
                    child: Align(
                      alignment: Alignment.centerLeft,
                      child: CachedImage(
                        imageUrl: ImageConfig.logo,
                        width: double.infinity,
                        height: ResponsiveHelper.isMobile(context)
                            ? 52.0
                            : ResponsiveHelper.isTablet(context)
                                ? 58.0
                                : 64.0,
                        fit: BoxFit.contain,
                        errorWidget: Container(
                          height: ResponsiveHelper.isMobile(context)
                              ? 52.0
                              : ResponsiveHelper.isTablet(context)
                                  ? 58.0
                                  : 64.0,
                          alignment: Alignment.centerLeft,
                          child: Text(
                            'Group Details',
                            style: TextStyle(
                              fontSize: ResponsiveHelper.fontSize(context, mobile: 20),
                              fontWeight: FontWeight.bold,
                              color: const Color(0xFF5F4628),
                            ),
                          ),
                        ),
                      ),
                    ),
                  ),
                  SizedBox(
                    width: ResponsiveHelper.isMobile(context)
                        ? 12.0
                        : ResponsiveHelper.isTablet(context)
                            ? 16.0
                            : 20.0,
                  ),
                  // Right Side - Back Button
                  Material(
                    color: Colors.transparent,
                    child: InkWell(
                      onTap: () => Get.back(),
                      borderRadius: BorderRadius.circular(30),
                      child: Container(
                        width: ResponsiveHelper.isMobile(context)
                            ? 40.0
                            : ResponsiveHelper.isTablet(context)
                                ? 44.0
                                : 48.0,
                        height: ResponsiveHelper.isMobile(context)
                            ? 40.0
                            : ResponsiveHelper.isTablet(context)
                                ? 44.0
                                : 48.0,
                        decoration: BoxDecoration(
                          gradient: const LinearGradient(
                            begin: Alignment.topLeft,
                            end: Alignment.bottomRight,
                            colors: [
                              Color(0xFF8B4513),
                              Color(0xFF6B3410),
                            ],
                          ),
                          shape: BoxShape.circle,
                          border: Border.all(
                            color: Colors.grey.withOpacity(0.2),
                            width: 1.5,
                          ),
                          boxShadow: [
                            BoxShadow(
                              color: const Color(0xFF8B4513).withOpacity(0.3),
                              blurRadius: 8,
                              offset: const Offset(0, 2),
                            ),
                          ],
                        ),
                        child: Icon(
                          Icons.arrow_back_rounded,
                          color: Colors.white,
                          size: ResponsiveHelper.isMobile(context)
                              ? 20.0
                              : ResponsiveHelper.isTablet(context)
                                  ? 22.0
                                  : 24.0,
                        ),
                      ),
                    ),
                  ),
                ],
              ),
            ),
          ),
        ),
      ),
      body: Obx(() {
        if (controller.isLoading.value && controller.selectedGroup.isEmpty) {
          return Center(
            child: CircularProgressIndicator(
              color: const Color(0xFF8B4513),
            ),
          );
        }

        if (controller.selectedGroup.isEmpty) {
          return Center(
            child: Column(
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                Icon(
                  Icons.error_outline,
                  size: ResponsiveHelper.iconSize(context, mobile: 64),
                  color: Colors.grey,
                ),
                SizedBox(height: ResponsiveHelper.spacing(context, 16)),
                Text(
                  'Group not found',
                  style: ResponsiveHelper.textStyle(
                    context,
                    fontSize: ResponsiveHelper.fontSize(context, mobile: 16),
                    color: Colors.grey,
                  ),
                ),
              ],
            ),
          );
        }

        final group = controller.selectedGroup;
        final isMember = controller.isMember(groupId);
        final baseUrl = 'https://fruitofthespirit.templateforwebsites.com/';
        String? imageUrl;
        if (group['group_image'] != null && group['group_image'].toString().isNotEmpty) {
          final imgPath = group['group_image'].toString();
          if (!imgPath.startsWith('http')) {
            imageUrl = baseUrl + (imgPath.startsWith('/') ? imgPath.substring(1) : imgPath);
          } else {
            imageUrl = imgPath;
          }
        }
        final category = group['category'] as String? ?? 'General';
        final memberCount = controller.groupMembers.length;

        return SingleChildScrollView(
          padding: EdgeInsets.all(ResponsiveHelper.spacing(context, 16)),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              // Group Image
              if (imageUrl != null && imageUrl.isNotEmpty)
                ClipRRect(
                  borderRadius: BorderRadius.circular(12),
                  child: CachedImage(
                    imageUrl: imageUrl,
                    width: double.infinity,
                    height: ResponsiveHelper.imageHeight(context, mobile: 200, tablet: 250, desktop: 300),
                    fit: BoxFit.cover,
                    errorWidget: Container(
                      width: double.infinity,
                      height: ResponsiveHelper.imageHeight(context, mobile: 200, tablet: 250, desktop: 300),
                      decoration: BoxDecoration(
                        gradient: LinearGradient(
                          begin: Alignment.topLeft,
                          end: Alignment.bottomRight,
                          colors: [
                            const Color(0xFFFAF6EC),
                            const Color(0xFF9F9467).withOpacity(0.3),
                          ],
                        ),
                      ),
                      child: Icon(
                        Icons.group_rounded,
                        size: ResponsiveHelper.iconSize(context, mobile: 60, tablet: 70, desktop: 80),
                        color: const Color(0xFF9F9467),
                      ),
                    ),
                  ),
                ),
              SizedBox(height: ResponsiveHelper.spacing(context, 20)),
              
              // Group Name and Category Row
              Row(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Expanded(
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Text(
                          group['name'] as String? ?? 'Untitled Group',
                          style: const TextStyle(
                            fontSize: 22,
                            fontWeight: FontWeight.bold,
                            color: Colors.black,
                          ),
                        ),
                        const SizedBox(height: 8),
                        Container(
                          padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 6),
                          decoration: BoxDecoration(
                            gradient: LinearGradient(
                              colors: [
                                const Color(0xFF8B4513),
                                const Color(0xFF9F9467),
                              ],
                            ),
                            borderRadius: BorderRadius.circular(12),
                          ),
                          child: Text(
                            category,
                            style: const TextStyle(
                              fontSize: 12,
                              fontWeight: FontWeight.bold,
                              color: Colors.white,
                            ),
                          ),
                        ),
                      ],
                    ),
                  ),
                  // Member Count
                  Row(
                    mainAxisSize: MainAxisSize.min,
                    children: [
                      Icon(
                        Icons.people_outline,
                        size: 18,
                        color: Colors.grey[600],
                      ),
                      const SizedBox(width: 4),
                      Text(
                        '$memberCount',
                        style: TextStyle(
                          fontSize: 14,
                          color: Colors.grey[600],
                          fontWeight: FontWeight.w500,
                        ),
                      ),
                    ],
                  ),
                ],
              ),
              SizedBox(height: ResponsiveHelper.spacing(context, 16)),
              
              // Description
              if (group['description'] != null && group['description'].toString().isNotEmpty)
                Text(
                  group['description'] as String,
                  style: const TextStyle(
                    fontSize: 14,
                    color: Colors.black87,
                    height: 1.6,
                  ),
                ),
              SizedBox(height: ResponsiveHelper.spacing(context, 24)),
              
              // Join/Leave Button
              SizedBox(
                width: double.infinity,
                height: ResponsiveHelper.buttonHeight(context, mobile: 52),
                child: ElevatedButton(
                  onPressed: controller.isLoading.value
                      ? null
                      : () async {
                          final success = isMember
                              ? await controller.leaveGroup(groupId)
                              : await controller.joinGroup(groupId);
                          
                          if (success) {
                            Get.snackbar(
                              'Success',
                              controller.message.value,
                              backgroundColor: Colors.green,
                              colorText: Colors.white,
                            );
                          } else {
                            Get.snackbar(
                              'Error',
                              controller.message.value,
                              backgroundColor: Colors.red,
                              colorText: Colors.white,
                            );
                          }
                        },
                  style: ElevatedButton.styleFrom(
                    backgroundColor: isMember ? Colors.red : const Color(0xFF8B4513),
                    elevation: 0,
                    shape: RoundedRectangleBorder(
                      borderRadius: BorderRadius.circular(12),
                    ),
                  ),
                  child: controller.isLoading.value
                      ? const CircularProgressIndicator(color: Colors.white)
                      : Text(
                          isMember ? 'Leave Group' : 'Join Group',
                          style: const TextStyle(
                            fontSize: 16,
                            fontWeight: FontWeight.bold,
                            color: Colors.white,
                          ),
                        ),
                ),
              ),
              SizedBox(height: ResponsiveHelper.spacing(context, 12)),
              
              // Group Chat Button (only for members)
              if (isMember)
                SizedBox(
                  width: double.infinity,
                  height: ResponsiveHelper.buttonHeight(context, mobile: 52),
                  child: ElevatedButton.icon(
                    onPressed: () {
                      Get.toNamed(Routes.GROUP_CHAT, arguments: groupId);
                    },
                    icon: const Icon(Icons.chat_bubble_outline, color: Colors.white, size: 20),
                    label: const Text(
                      'Group Chat / Community',
                      style: TextStyle(
                        fontSize: 16,
                        fontWeight: FontWeight.bold,
                        color: Colors.white,
                      ),
                    ),
                    style: ElevatedButton.styleFrom(
                      backgroundColor: const Color(0xFF8B4513),
                      elevation: 0,
                      shape: RoundedRectangleBorder(
                        borderRadius: BorderRadius.circular(12),
                      ),
                    ),
                  ),
                ),
              SizedBox(height: ResponsiveHelper.spacing(context, 24)),
              
              // Members Section
              Text(
                'Members ($memberCount)',
                style: const TextStyle(
                  fontSize: 18,
                  fontWeight: FontWeight.bold,
                  color: Colors.black,
                ),
              ),
              SizedBox(height: ResponsiveHelper.spacing(context, 12)),
              
              if (controller.groupMembers.isEmpty)
                Container(
                  padding: EdgeInsets.all(ResponsiveHelper.spacing(context, 20)),
                  decoration: BoxDecoration(
                    color: Colors.grey[50],
                    borderRadius: BorderRadius.circular(12),
                  ),
                  child: Center(
                    child: Text(
                      'No members yet',
                      style: TextStyle(
                        fontSize: 14,
                        color: Colors.grey[600],
                      ),
                    ),
                  ),
                )
              else
                ...controller.groupMembers.map((member) => _buildMemberCard(context, member)),
            ],
          ),
        );
      }),
    );
  }

  Widget _buildMemberCard(BuildContext context, Map<String, dynamic> member) {
    final baseUrl = 'https://fruitofthespirit.templateforwebsites.com/';
    String? profilePhoto;
    if (member['profile_photo'] != null && member['profile_photo'].toString().isNotEmpty) {
      final photoPath = member['profile_photo'].toString();
      if (!photoPath.startsWith('http')) {
        profilePhoto = baseUrl + (photoPath.startsWith('/') ? photoPath.substring(1) : photoPath);
      } else {
        profilePhoto = photoPath;
      }
    }
    
    return Container(
      margin: EdgeInsets.only(bottom: ResponsiveHelper.spacing(context, 12)),
      padding: const EdgeInsets.all(12),
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(12),
        border: Border.all(
          color: Colors.grey[200]!.withOpacity(0.5),
          width: 0.5,
        ),
        boxShadow: [
          BoxShadow(
            color: Colors.black.withOpacity(0.03),
            spreadRadius: 0,
            blurRadius: 8,
            offset: const Offset(0, 1),
          ),
        ],
      ),
      child: Row(
        children: [
          CircleAvatar(
            radius: 24,
            backgroundColor: Colors.transparent,
            backgroundImage: profilePhoto != null ? NetworkImage(profilePhoto) : null,
            child: profilePhoto == null
                ? Icon(
                    Icons.person_rounded,
                    size: 24,
                    color: const Color(0xFF5F4628),
                  )
                : null,
          ),
          const SizedBox(width: 12),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  member['name'] as String? ?? 'Anonymous',
                  style: const TextStyle(
                    fontSize: 15,
                    fontWeight: FontWeight.bold,
                    color: Colors.black,
                  ),
                ),
                if (member['role'] != null && member['role'].toString().isNotEmpty)
                  Text(
                    member['role'] as String,
                    style: TextStyle(
                      fontSize: 12,
                      color: Colors.grey[600],
                    ),
                  ),
              ],
            ),
          ),
        ],
      ),
    );
  }
}

