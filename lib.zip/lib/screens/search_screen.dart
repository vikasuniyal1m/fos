import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:fruitsofspirit/services/search_service.dart';
import 'package:fruitsofspirit/utils/responsive_helper.dart';
import 'package:fruitsofspirit/routes/routes.dart';
import 'package:fruitsofspirit/services/api_service.dart';

/// Search Screen
class SearchScreen extends StatefulWidget {
  const SearchScreen({Key? key}) : super(key: key);

  @override
  State<SearchScreen> createState() => _SearchScreenState();
}

class _SearchScreenState extends State<SearchScreen> {
  final searchController = TextEditingController();
  var isLoading = false;
  var searchResults = <String, dynamic>{};
  String selectedType = 'all';

  Future<void> _performSearch(String query) async {
    if (query.trim().isEmpty) {
      setState(() {
        searchResults = {};
      });
      return;
    }

    setState(() {
      isLoading = true;
      searchResults = {};
    });

    try {
      final results = await SearchService.search(
        query: query.trim(),
        type: selectedType,
      );
      
      print('🔍 Search results received: ${results.keys}');
      print('🔍 Results structure: ${results['results']?.keys}');
      print('🔍 Full results: $results');
      
      setState(() {
        searchResults = results;
        isLoading = false;
      });
      
      print('🔍 After setState - searchResults keys: ${searchResults.keys}');
      print('🔍 After setState - searchResults[results]: ${searchResults['results']}');
      
      // Check if we have any results
      final resultsData = results['results'] as Map<String, dynamic>? ?? {};
      final hasResults = resultsData.values.any((list) => 
        list is List && list.isNotEmpty
      );
      
      if (!hasResults) {
        Get.snackbar(
          'No Results',
          'No content found for "$query"',
          backgroundColor: Colors.orange,
          colorText: Colors.white,
          duration: const Duration(seconds: 2),
        );
      }
    } catch (e) {
      setState(() {
        isLoading = false;
        searchResults = {};
      });
      print('❌ Search error: $e');
      Get.snackbar(
        'Search Error',
        e.toString().replaceAll('Exception: ', ''),
        backgroundColor: Colors.red,
        colorText: Colors.white,
        duration: const Duration(seconds: 3),
      );
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.white, // Match home page
      appBar: PreferredSize(
        preferredSize: Size.fromHeight(
          ResponsiveHelper.appBarHeight(context),
        ),
        child: AppBar(
          backgroundColor: Colors.white, // Match home page
          elevation: 0,
          leading: IconButton(
            icon: Icon(
              Icons.arrow_back,
              color: const Color(0xFF8B4513),
              size: ResponsiveHelper.iconSize(context, mobile: 24, tablet: 28, desktop: 32),
            ),
            onPressed: () => Get.back(),
          ),
          title: TextField(
            controller: searchController,
            autofocus: true,
            decoration: InputDecoration(
              hintText: 'Search...',
              border: InputBorder.none,
              hintStyle: ResponsiveHelper.textStyle(
                context,
                fontSize: ResponsiveHelper.fontSize(context, mobile: 16, tablet: 17, desktop: 18),
                color: Colors.grey,
              ),
            ),
            style: ResponsiveHelper.textStyle(
              context,
              fontSize: ResponsiveHelper.fontSize(context, mobile: 16, tablet: 17, desktop: 18),
              color: const Color(0xFF8B4513),
            ),
            onSubmitted: _performSearch,
          ),
          actions: [
            IconButton(
              icon: Icon(
                Icons.search,
                color: const Color(0xFF8B4513),
                size: ResponsiveHelper.iconSize(context, mobile: 24, tablet: 28, desktop: 32),
              ),
              onPressed: () => _performSearch(searchController.text),
            ),
          ],
        ),
      ),
      body: Column(
        children: [
          // Type Filter
          Container(
            padding: EdgeInsets.symmetric(
              horizontal: ResponsiveHelper.spacing(context, 16),
              vertical: ResponsiveHelper.spacing(context, 8),
            ),
            child: SingleChildScrollView(
              scrollDirection: Axis.horizontal,
              child: Row(
                children: [
                  _buildFilterChip(context, 'All', 'all'),
                  SizedBox(width: ResponsiveHelper.spacing(context, 8)),
                  _buildFilterChip(context, 'Blogs', 'blogs'),
                  SizedBox(width: ResponsiveHelper.spacing(context, 8)),
                  _buildFilterChip(context, 'Prayers', 'prayers'),
                  SizedBox(width: ResponsiveHelper.spacing(context, 8)),
                  _buildFilterChip(context, 'Videos', 'videos'),
                  SizedBox(width: ResponsiveHelper.spacing(context, 8)),
                  _buildFilterChip(context, 'Photos', 'photos'),
                  SizedBox(width: ResponsiveHelper.spacing(context, 8)),
                  _buildFilterChip(context, 'Stories', 'stories'),
                ],
              ),
            ),
          ),
          
          // Results
          Expanded(
            child: isLoading
                ? Center(
                    child: CircularProgressIndicator(
                      color: const Color(0xFF8B4513),
                    ),
                  )
                : _buildEmptyOrResults(),
          ),
        ],
      ),
    );
  }

  Widget _buildFilterChip(BuildContext context, String label, String type) {
    final isSelected = selectedType == type;
    return FilterChip(
      label: Text(label),
      selected: isSelected,
      onSelected: (selected) {
        setState(() {
          selectedType = type;
        });
        if (searchController.text.trim().isNotEmpty) {
          _performSearch(searchController.text);
        }
      },
      selectedColor: const Color(0xFFE3F2FD),
      checkmarkColor: const Color(0xFF8B4513),
      labelStyle: ResponsiveHelper.textStyle(
        context,
        fontSize: ResponsiveHelper.fontSize(context, mobile: 14),
        color: isSelected ? const Color(0xFF8B4513) : Colors.black,
        fontWeight: isSelected ? FontWeight.bold : FontWeight.normal,
      ),
    );
  }

  Widget _buildEmptyOrResults() {
    // Debug: Print current state
    print('🔍 _buildEmptyOrResults called');
    print('🔍 searchResults keys: ${searchResults.keys}');
    print('🔍 searchResults: $searchResults');
    
    // Check if we have any results
    final results = searchResults['results'] as Map<String, dynamic>? ?? {};
    print('🔍 Extracted results keys: ${results.keys}');
    print('🔍 Extracted results: $results');
    
    final hasResults = results.values.any((list) => 
      list is List && list.isNotEmpty
    );
    print('🔍 hasResults: $hasResults');
    
    if (!hasResults && searchController.text.trim().isNotEmpty) {
      // Show "no results" message
      return Center(
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Icon(
              Icons.search_off,
              size: ResponsiveHelper.iconSize(context, mobile: 64),
              color: Colors.grey,
            ),
            SizedBox(height: ResponsiveHelper.spacing(context, 16)),
            Text(
              'No results found',
              style: ResponsiveHelper.textStyle(
                context,
                fontSize: ResponsiveHelper.fontSize(context, mobile: 18),
                fontWeight: FontWeight.bold,
                color: Colors.grey[700],
              ),
            ),
            SizedBox(height: ResponsiveHelper.spacing(context, 8)),
            Text(
              'Try searching with different keywords',
              style: ResponsiveHelper.textStyle(
                context,
                fontSize: ResponsiveHelper.fontSize(context, mobile: 14),
                color: Colors.grey,
              ),
              textAlign: TextAlign.center,
            ),
          ],
        ),
      );
    }
    
    if (!hasResults) {
      // Show "enter query" message
      return Center(
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Icon(
              Icons.search_outlined,
              size: ResponsiveHelper.iconSize(context, mobile: 64),
              color: Colors.grey,
            ),
            SizedBox(height: ResponsiveHelper.spacing(context, 16)),
            Text(
              'Enter a search query',
              style: ResponsiveHelper.textStyle(
                context,
                fontSize: ResponsiveHelper.fontSize(context, mobile: 16),
                color: Colors.grey,
              ),
            ),
            SizedBox(height: ResponsiveHelper.spacing(context, 8)),
            Text(
              'Search across blogs, prayers, videos, photos, and stories',
              style: ResponsiveHelper.textStyle(
                context,
                fontSize: ResponsiveHelper.fontSize(context, mobile: 12),
                color: Colors.grey[600],
              ),
              textAlign: TextAlign.center,
            ),
          ],
        ),
      );
    }
    
    return _buildResults(results);
  }

  Widget _buildResults(Map<String, dynamic> results) {
    print('🔍 _buildResults called with keys: ${results.keys}');
    print('🔍 Blogs: ${results['blogs']} (type: ${results['blogs'].runtimeType})');
    print('🔍 Prayers: ${results['prayers']} (type: ${results['prayers'].runtimeType})');
    print('🔍 Videos: ${results['videos']} (type: ${results['videos'].runtimeType})');
    
    return SingleChildScrollView(
      padding: EdgeInsets.all(ResponsiveHelper.spacing(context, 16)),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          if (results['blogs'] != null && (results['blogs'] is List && (results['blogs'] as List).isNotEmpty)) ...[
            Text(
              'Blogs (${(results['blogs'] as List).length})',
              style: ResponsiveHelper.textStyle(
                context,
                fontSize: ResponsiveHelper.fontSize(context, mobile: 18),
                fontWeight: FontWeight.bold,
                color: const Color(0xFF8B4513),
              ),
            ),
            SizedBox(height: ResponsiveHelper.spacing(context, 8)),
            ...(results['blogs'] as List).map((blog) => _buildResultCard(
              context,
              blog,
              'Blog',
              () => Get.toNamed(Routes.BLOG_DETAILS, arguments: blog['id']),
            )),
            SizedBox(height: ResponsiveHelper.spacing(context, 16)),
          ],
          if (results['prayers'] != null && (results['prayers'] is List && (results['prayers'] as List).isNotEmpty)) ...[
            Text(
              'Prayers (${(results['prayers'] as List).length})',
              style: ResponsiveHelper.textStyle(
                context,
                fontSize: ResponsiveHelper.fontSize(context, mobile: 18),
                fontWeight: FontWeight.bold,
                color: const Color(0xFF8B4513),
              ),
            ),
            SizedBox(height: ResponsiveHelper.spacing(context, 8)),
            ...(results['prayers'] as List).map((prayer) => _buildResultCard(
              context,
              prayer,
              'Prayer',
              () => Get.toNamed(Routes.PRAYER_DETAILS, arguments: prayer['id']),
            )),
            SizedBox(height: ResponsiveHelper.spacing(context, 16)),
          ],
          if (results['videos'] != null && (results['videos'] is List && (results['videos'] as List).isNotEmpty)) ...[
            Text(
              'Videos (${(results['videos'] as List).length})',
              style: ResponsiveHelper.textStyle(
                context,
                fontSize: ResponsiveHelper.fontSize(context, mobile: 18),
                fontWeight: FontWeight.bold,
                color: const Color(0xFF8B4513),
              ),
            ),
            SizedBox(height: ResponsiveHelper.spacing(context, 8)),
            ...(results['videos'] as List).map((video) => _buildResultCard(
              context,
              video,
              'Video',
              () => Get.toNamed(Routes.VIDEO_DETAILS, arguments: video['id']),
            )),
            SizedBox(height: ResponsiveHelper.spacing(context, 16)),
          ],
          if (results['photos'] != null && (results['photos'] is List && (results['photos'] as List).isNotEmpty)) ...[
            Text(
              'Photos (${(results['photos'] as List).length})',
              style: ResponsiveHelper.textStyle(
                context,
                fontSize: ResponsiveHelper.fontSize(context, mobile: 18),
                fontWeight: FontWeight.bold,
                color: const Color(0xFF8B4513),
              ),
            ),
            SizedBox(height: ResponsiveHelper.spacing(context, 8)),
            ...(results['photos'] as List).map((photo) => _buildResultCard(
              context,
              photo,
              'Photo',
              () => Get.toNamed(Routes.PHOTO_DETAILS, arguments: photo['id']),
            )),
            SizedBox(height: ResponsiveHelper.spacing(context, 16)),
          ],
          if (results['stories'] != null && (results['stories'] is List && (results['stories'] as List).isNotEmpty)) ...[
            Text(
              'Stories (${(results['stories'] as List).length})',
              style: ResponsiveHelper.textStyle(
                context,
                fontSize: ResponsiveHelper.fontSize(context, mobile: 18),
                fontWeight: FontWeight.bold,
                color: const Color(0xFF8B4513),
              ),
            ),
            SizedBox(height: ResponsiveHelper.spacing(context, 8)),
            ...(results['stories'] as List).map((story) => _buildResultCard(
              context,
              story,
              'Story',
              () => Get.toNamed(Routes.STORY_DETAILS, arguments: story['id']),
            )),
          ],
        ],
      ),
    );
  }

  Widget _buildResultCard(BuildContext context, Map<String, dynamic> item, String type, VoidCallback onTap) {
    final baseUrl = 'https://fruitofthespirit.templateforwebsites.com/';
    final imageUrl = type == 'Blog' 
        ? (item['image_url'] != null ? baseUrl + (item['image_url'] as String) : null)
        : type == 'Photo' || type == 'Story'
            ? (item['file_path'] != null ? baseUrl + (item['file_path'] as String) : null)
            : null;
    
    // Match home page styling
    if (type == 'Blog') {
      return Container(
        margin: EdgeInsets.only(bottom: ResponsiveHelper.spacing(context, 16)),
        decoration: BoxDecoration(
          color: Colors.white,
          borderRadius: BorderRadius.circular(ResponsiveHelper.borderRadius(context, mobile: 12)),
          boxShadow: [
            BoxShadow(
              color: Colors.grey.withOpacity(0.2),
              spreadRadius: 2,
              blurRadius: 12,
              offset: const Offset(0, 4),
            ),
          ],
        ),
        child: Material(
          color: Colors.transparent,
          child: InkWell(
            onTap: onTap,
            borderRadius: BorderRadius.circular(ResponsiveHelper.borderRadius(context, mobile: 12)),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                if (imageUrl != null)
                  ClipRRect(
                    borderRadius: BorderRadius.vertical(
                      top: Radius.circular(ResponsiveHelper.borderRadius(context, mobile: 12)),
                    ),
                    child: Image.network(
                      imageUrl,
                      height: ResponsiveHelper.imageHeight(context, mobile: 200),
                      width: double.infinity,
                      fit: BoxFit.cover,
                      errorBuilder: (context, error, stackTrace) => Container(
                        height: ResponsiveHelper.imageHeight(context, mobile: 200),
                        color: Colors.grey[300],
                        child: Icon(Icons.article, size: 40),
                      ),
                    ),
                  ),
                Padding(
                  padding: EdgeInsets.all(ResponsiveHelper.spacing(context, 12)),
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text(
                        item['title'] as String? ?? 'Untitled',
                        style: ResponsiveHelper.textStyle(
                          context,
                          fontSize: ResponsiveHelper.fontSize(context, mobile: 16),
                          fontWeight: FontWeight.bold,
                          color: const Color(0xFF8B4513),
                        ),
                        maxLines: 2,
                        overflow: TextOverflow.ellipsis,
                      ),
                      if (item['author_name'] != null) ...[
                        SizedBox(height: ResponsiveHelper.spacing(context, 4)),
                        Text(
                          item['author_name'] as String,
                          style: ResponsiveHelper.textStyle(
                            context,
                            fontSize: ResponsiveHelper.fontSize(context, mobile: 14),
                            color: Colors.grey[600],
                          ),
                        ),
                      ],
                    ],
                  ),
                ),
              ],
            ),
          ),
        ),
      );
    } else if (type == 'Prayer') {
      return Container(
        margin: EdgeInsets.only(bottom: ResponsiveHelper.spacing(context, 12)),
        padding: ResponsiveHelper.padding(context, all: 12),
        decoration: BoxDecoration(
          color: const Color(0xFFE3F2FD), // Light blue like home page
          borderRadius: BorderRadius.circular(ResponsiveHelper.borderRadius(context, mobile: 16)),
          boxShadow: [
            BoxShadow(
              color: Colors.blue.withOpacity(0.12),
              spreadRadius: 1,
              blurRadius: 6,
              offset: Offset(0, ResponsiveHelper.spacing(context, 2)),
            ),
          ],
        ),
        child: Material(
          color: Colors.transparent,
          child: InkWell(
            onTap: onTap,
            borderRadius: BorderRadius.circular(ResponsiveHelper.borderRadius(context, mobile: 16)),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  item['title'] as String? ?? item['content'] as String? ?? 'Prayer Request',
                  style: ResponsiveHelper.textStyle(
                    context,
                    fontSize: ResponsiveHelper.fontSize(context, mobile: 16),
                    fontWeight: FontWeight.bold,
                    color: const Color(0xFF8B4513),
                  ),
                  maxLines: 2,
                  overflow: TextOverflow.ellipsis,
                ),
                if (item['content'] != null) ...[
                  SizedBox(height: ResponsiveHelper.spacing(context, 4)),
                  Text(
                    item['content'] as String,
                    style: ResponsiveHelper.textStyle(
                      context,
                      fontSize: ResponsiveHelper.fontSize(context, mobile: 14),
                      color: Colors.grey[700],
                    ),
                    maxLines: 3,
                    overflow: TextOverflow.ellipsis,
                  ),
                ],
              ],
            ),
          ),
        ),
      );
    }
    
    // Default card for other types
    return Card(
      margin: EdgeInsets.only(bottom: ResponsiveHelper.spacing(context, 12)),
      elevation: 1,
      shape: RoundedRectangleBorder(
        borderRadius: BorderRadius.circular(ResponsiveHelper.borderRadius(context, mobile: 12)),
      ),
      child: InkWell(
        onTap: onTap,
        borderRadius: BorderRadius.circular(ResponsiveHelper.borderRadius(context, mobile: 12)),
        child: Padding(
          padding: EdgeInsets.all(ResponsiveHelper.spacing(context, 12)),
          child: Row(
            children: [
              if (imageUrl != null)
                ClipRRect(
                  borderRadius: BorderRadius.circular(ResponsiveHelper.borderRadius(context, mobile: 8)),
                  child: Image.network(
                    imageUrl,
                    width: 60,
                    height: 60,
                    fit: BoxFit.cover,
                    errorBuilder: (context, error, stackTrace) => Container(
                      width: 60,
                      height: 60,
                      color: Colors.grey[300],
                      child: Icon(Icons.image, size: 24),
                    ),
                  ),
                ),
              if (imageUrl != null) SizedBox(width: ResponsiveHelper.spacing(context, 12)),
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(
                      item['title'] as String? ?? item['content'] as String? ?? 'Untitled',
                      style: ResponsiveHelper.textStyle(
                        context,
                        fontSize: ResponsiveHelper.fontSize(context, mobile: 16),
                        fontWeight: FontWeight.bold,
                        color: const Color(0xFF8B4513),
                      ),
                      maxLines: 2,
                      overflow: TextOverflow.ellipsis,
                    ),
                    SizedBox(height: ResponsiveHelper.spacing(context, 4)),
                    Text(
                      type,
                      style: ResponsiveHelper.textStyle(
                        context,
                        fontSize: ResponsiveHelper.fontSize(context, mobile: 12),
                        color: Colors.grey,
                      ),
                    ),
                  ],
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}

