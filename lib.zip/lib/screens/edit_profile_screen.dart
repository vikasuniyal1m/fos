import 'dart:io';
import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:image_picker/image_picker.dart';
import 'package:fruitsofspirit/controllers/profile_controller.dart';
import 'package:fruitsofspirit/utils/responsive_helper.dart';
import 'package:fruitsofspirit/routes/routes.dart';
import 'package:fruitsofspirit/widgets/cached_image.dart';
import 'package:fruitsofspirit/widgets/app_bottom_navigation_bar.dart';
import 'package:fruitsofspirit/utils/localization_helper.dart';
import 'package:fruitsofspirit/config/image_config.dart';

/// Edit Profile Screen
class EditProfileScreen extends StatefulWidget {
  const EditProfileScreen({Key? key}) : super(key: key);

  @override
  State<EditProfileScreen> createState() => _EditProfileScreenState();
}

class _EditProfileScreenState extends State<EditProfileScreen> {
  final ProfileController controller = Get.find<ProfileController>();
  late TextEditingController usernameController;
  late TextEditingController emailController;
  late TextEditingController phoneController;
  late TextEditingController passwordController;
  File? selectedImage;
  bool _controllersInitialized = false;

  @override
  void initState() {
    super.initState();
    // Initialize controllers with empty values, will be updated when profile loads
    usernameController = TextEditingController();
    emailController = TextEditingController();
    phoneController = TextEditingController();
    passwordController = TextEditingController();
    
    // Load profile if not already loaded
    if (controller.profile.isEmpty) {
      controller.loadProfile().then((_) {
        _updateControllers();
      });
    } else {
      _updateControllers();
    }
  }

  void _updateControllers() {
    if (!mounted) return;
    
    final name = controller.profile['name'] as String? ?? '';
    final email = controller.profile['email'] as String? ?? '';
    final phone = controller.profile['phone'] as String? ?? '';
    
    usernameController.text = name;
    emailController.text = email;
    phoneController.text = phone;
    passwordController.clear(); // Password field should be empty for security
    
    setState(() {
      _controllersInitialized = true;
    });
  }

  @override
  void dispose() {
    usernameController.dispose();
    emailController.dispose();
    phoneController.dispose();
    passwordController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: const Color(0xFFFAF6EC), // Light beige/cream background
      appBar: PreferredSize(
        preferredSize: Size.fromHeight(
          ResponsiveHelper.appBarHeight(context),
        ),
        child: AppBar(
        backgroundColor: const Color(0xFF5F4628), // Dark brown background
        elevation: 0,
        leading: IconButton(
            icon: Icon(
              Icons.arrow_back,
              color: Colors.white,
              size: ResponsiveHelper.iconSize(context, mobile: 24, tablet: 28, desktop: 32),
            ),
          onPressed: () => Get.back(),
        ),
        title: Text(
          'Edit Profile',
          style: ResponsiveHelper.textStyle(
            context,
            fontSize: ResponsiveHelper.fontSize(context, mobile: 20, tablet: 24, desktop: 28),
            fontWeight: FontWeight.bold,
            color: Colors.white,
          ),
        ),
        centerTitle: true,
        actions: [
          IconButton(
              icon: Icon(
                Icons.share,
                color: Colors.white,
                size: ResponsiveHelper.iconSize(context, mobile: 24, tablet: 28, desktop: 32),
              ),
            onPressed: () {
              // Share profile functionality
            },
          ),
        ],
        ),
      ),
      body: Obx(() {
        if (controller.isLoading.value && controller.profile.isEmpty) {
          return Center(
            child: CircularProgressIndicator(
              color: const Color(0xFF5F4628),
            ),
          );
        }

        // Update controllers when profile data changes
        if (!_controllersInitialized && controller.profile.isNotEmpty) {
          WidgetsBinding.instance.addPostFrameCallback((_) {
            _updateControllers();
          });
        }

        return _buildEditProfileContent(context);
      }),
      extendBodyBehindAppBar: false,
    );
  }

  Widget _buildEditProfileContent(BuildContext context) {
    // Get data from controller (from database)
    final profilePhoto = controller.profile['profile_photo'] as String?;
    
    return StatefulBuilder(
      builder: (context, setState) {
        return Stack(
          clipBehavior: Clip.none,
          children: [
            // Main scrollable content
            SingleChildScrollView(
              child: Column(
                children: [
                  // Dark brown section at top (with space for avatar)
                  Container(
                    height: ResponsiveHelper.isMobile(context) 
                        ? 180 
                        : ResponsiveHelper.isTablet(context) 
                            ? 200 
                            : 220, // More space for larger avatar
                    color: const Color(0xFF5F4628),
                  ),
                  // Light beige section with content
                  Container(
                    color: const Color(0xFFFAF6EC),
                    padding: ResponsiveHelper.padding(context, top: 80, left: 16, right: 16, bottom: 16), // Responsive padding
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        // "Change Picture" text - positioned below profile picture
                        Center(
                          child: GestureDetector(
                            onTap: () async {
                              final picker = ImagePicker();
                              final image = await picker.pickImage(source: ImageSource.gallery);
                              if (image != null) {
                                setState(() {
                                  selectedImage = File(image.path);
                                });
                              }
                            },
                            child: Padding(
                              padding: EdgeInsets.only(top: 0), // Removed top padding since avatar is fixed
                              child: Text(
                                'Change Picture',
                                style: ResponsiveHelper.textStyle(
                                  context,
                                  fontSize: ResponsiveHelper.fontSize(context, mobile: 16, tablet: 17, desktop: 18),
                                  color: Colors.black,
                                  fontWeight: FontWeight.w500,
                                ),
                              ),
                            ),
                          ),
                        ),
                        SizedBox(height: ResponsiveHelper.spacing(context, 16)), // Responsive spacing
              
              // Username Field
              Text(
                'Username',
                style: ResponsiveHelper.textStyle(
                  context,
                  fontSize: ResponsiveHelper.fontSize(context, mobile: 16, tablet: 17, desktop: 18),
                  fontWeight: FontWeight.bold,
                  color: Colors.black,
                ),
              ),
              SizedBox(height: ResponsiveHelper.spacing(context, 8)),
              TextField(
                controller: usernameController,
                style: ResponsiveHelper.textStyle(
                  context,
                  fontSize: ResponsiveHelper.fontSize(context, mobile: 16, tablet: 17, desktop: 18),
                  color: Colors.black87,
                ),
                decoration: InputDecoration(
                  border: OutlineInputBorder(
                    borderRadius: BorderRadius.circular(ResponsiveHelper.borderRadius(context, mobile: 6)),
                    borderSide: BorderSide(color: Colors.grey.withOpacity(0.2), width: 1),
                  ),
                  enabledBorder: OutlineInputBorder(
                    borderRadius: BorderRadius.circular(ResponsiveHelper.borderRadius(context, mobile: 6)),
                    borderSide: BorderSide(color: Colors.grey.withOpacity(0.2), width: 1),
                  ),
                  focusedBorder: OutlineInputBorder(
                    borderRadius: BorderRadius.circular(ResponsiveHelper.borderRadius(context, mobile: 6)),
                    borderSide: const BorderSide(color: Color(0xFF5F4628), width: 1.5),
                  ),
                  filled: true,
                  fillColor: Colors.white,
                  contentPadding: ResponsiveHelper.padding(context, horizontal: 16, vertical: 14),
                ),
              ),
              SizedBox(height: ResponsiveHelper.spacing(context, 16)),
              
              // Email I'd Field
              Text(
                'Email I\'d',
                style: ResponsiveHelper.textStyle(
                  context,
                  fontSize: ResponsiveHelper.fontSize(context, mobile: 16, tablet: 17, desktop: 18),
                  fontWeight: FontWeight.bold,
                  color: Colors.black,
                ),
              ),
              SizedBox(height: ResponsiveHelper.spacing(context, 8)),
              TextField(
                controller: emailController,
                keyboardType: TextInputType.emailAddress,
                style: ResponsiveHelper.textStyle(
                  context,
                  fontSize: ResponsiveHelper.fontSize(context, mobile: 16, tablet: 17, desktop: 18),
                  color: Colors.black87,
                ),
                decoration: InputDecoration(
                  border: OutlineInputBorder(
                    borderRadius: BorderRadius.circular(ResponsiveHelper.borderRadius(context, mobile: 6)),
                    borderSide: BorderSide(color: Colors.grey.withOpacity(0.2), width: 1),
                  ),
                  enabledBorder: OutlineInputBorder(
                    borderRadius: BorderRadius.circular(ResponsiveHelper.borderRadius(context, mobile: 6)),
                    borderSide: BorderSide(color: Colors.grey.withOpacity(0.2), width: 1),
                  ),
                  focusedBorder: OutlineInputBorder(
                    borderRadius: BorderRadius.circular(ResponsiveHelper.borderRadius(context, mobile: 6)),
                    borderSide: const BorderSide(color: Color(0xFF5F4628), width: 1.5),
                  ),
                  filled: true,
                  fillColor: Colors.white,
                  contentPadding: ResponsiveHelper.padding(context, horizontal: 16, vertical: 14),
                ),
              ),
              SizedBox(height: ResponsiveHelper.spacing(context, 16)),
              
              // Phone Number Field
              Text(
                'Phone Number',
                style: ResponsiveHelper.textStyle(
                  context,
                  fontSize: ResponsiveHelper.fontSize(context, mobile: 16, tablet: 17, desktop: 18),
                  fontWeight: FontWeight.bold,
                  color: Colors.black,
                ),
              ),
              SizedBox(height: ResponsiveHelper.spacing(context, 8)),
              TextField(
                controller: phoneController,
                keyboardType: TextInputType.phone,
                style: ResponsiveHelper.textStyle(
                  context,
                  fontSize: ResponsiveHelper.fontSize(context, mobile: 16, tablet: 17, desktop: 18),
                  color: Colors.black87,
                ),
                decoration: InputDecoration(
                  border: OutlineInputBorder(
                    borderRadius: BorderRadius.circular(ResponsiveHelper.borderRadius(context, mobile: 6)),
                    borderSide: BorderSide(color: Colors.grey.withOpacity(0.2), width: 1),
                  ),
                  enabledBorder: OutlineInputBorder(
                    borderRadius: BorderRadius.circular(ResponsiveHelper.borderRadius(context, mobile: 6)),
                    borderSide: BorderSide(color: Colors.grey.withOpacity(0.2), width: 1),
                  ),
                  focusedBorder: OutlineInputBorder(
                    borderRadius: BorderRadius.circular(ResponsiveHelper.borderRadius(context, mobile: 6)),
                    borderSide: const BorderSide(color: Color(0xFF5F4628), width: 1.5),
                  ),
                  filled: true,
                  fillColor: Colors.white,
                  contentPadding: ResponsiveHelper.padding(context, horizontal: 16, vertical: 14),
                ),
              ),
              SizedBox(height: ResponsiveHelper.spacing(context, 16)),
              
              // Password Field
              Text(
                'Password',
                style: ResponsiveHelper.textStyle(
                  context,
                  fontSize: ResponsiveHelper.fontSize(context, mobile: 16, tablet: 17, desktop: 18),
                  fontWeight: FontWeight.bold,
                  color: Colors.black,
                ),
              ),
              SizedBox(height: ResponsiveHelper.spacing(context, 8)),
              TextField(
                controller: passwordController,
                obscureText: true,
                style: ResponsiveHelper.textStyle(
                  context,
                  fontSize: ResponsiveHelper.fontSize(context, mobile: 16, tablet: 17, desktop: 18),
                  color: Colors.black87,
                ),
                decoration: InputDecoration(
                  border: OutlineInputBorder(
                    borderRadius: BorderRadius.circular(ResponsiveHelper.borderRadius(context, mobile: 6)),
                    borderSide: BorderSide(color: Colors.grey.withOpacity(0.2), width: 1),
                  ),
                  enabledBorder: OutlineInputBorder(
                    borderRadius: BorderRadius.circular(ResponsiveHelper.borderRadius(context, mobile: 6)),
                    borderSide: BorderSide(color: Colors.grey.withOpacity(0.2), width: 1),
                  ),
                  focusedBorder: OutlineInputBorder(
                    borderRadius: BorderRadius.circular(ResponsiveHelper.borderRadius(context, mobile: 6)),
                    borderSide: const BorderSide(color: Color(0xFF5F4628), width: 1.5),
                  ),
                  filled: true,
                  fillColor: Colors.white,
                  contentPadding: ResponsiveHelper.padding(context, horizontal: 16, vertical: 14),
                ),
              ),
              SizedBox(height: ResponsiveHelper.spacing(context, 32)),
              
              // Update Button
              SizedBox(
                width: double.infinity,
                height: ResponsiveHelper.buttonHeight(context, mobile: 50, tablet: 55, desktop: 60),
                child: ElevatedButton(
                  onPressed: controller.isLoading.value
                      ? null
                      : () async {
                          final success = await controller.updateProfile(
                            name: usernameController.text.trim().isEmpty
                                ? null
                                : usernameController.text.trim(),
                            email: emailController.text.trim().isEmpty
                                ? null
                                : emailController.text.trim(),
                            phone: phoneController.text.trim().isEmpty
                                ? null
                                : phoneController.text.trim(),
                            password: passwordController.text.trim().isEmpty
                                ? null
                                : passwordController.text.trim(),
                            profilePhoto: selectedImage,
                          );

                          if (success) {
                            Get.back();
                            Get.snackbar(
                              'Success',
                              controller.message.value,
                              backgroundColor: Colors.green,
                              colorText: Colors.white,
                            );
                          } else {
                            Get.snackbar(
                              'Error',
                              controller.message.value,
                              backgroundColor: Colors.red,
                              colorText: Colors.white,
                            );
                          }
                        },
                  style: ElevatedButton.styleFrom(
                    backgroundColor: const Color(0xFF9F9467), // Muted olive green/brown
                    foregroundColor: Colors.white,
                    elevation: 0,
                    shape: RoundedRectangleBorder(
                      borderRadius: BorderRadius.circular(8),
                    ),
                  ),
                  child: controller.isLoading.value
                      ? const CircularProgressIndicator(color: Colors.white)
                      : Text(
                          'Update',
                          style: ResponsiveHelper.textStyle(
                            context,
                            fontSize: ResponsiveHelper.fontSize(context, mobile: 18, tablet: 20, desktop: 22),
                            fontWeight: FontWeight.bold,
                            color: Colors.white,
                          ),
                        ),
                ),
              ),
                      ],
                    ),
                  ),
                ],
              ),
            ),
            // Profile Picture - Fixed position (doesn't scroll)
            Positioned(
              top: ResponsiveHelper.isMobile(context) 
                  ? 120 
                  : ResponsiveHelper.isTablet(context) 
                      ? 130 
                      : 140, // Position for larger avatar
              left: 0,
              right: 0,
              child: IgnorePointer(
                ignoring: false, // Allow taps
                child: Center(
                  child: GestureDetector(
                    onTap: () async {
                      final picker = ImagePicker();
                      final image = await picker.pickImage(source: ImageSource.gallery);
                      if (image != null) {
                        setState(() {
                          selectedImage = File(image.path);
                        });
                      }
                    },
                    child: Container(
                      decoration: BoxDecoration(
                        shape: BoxShape.circle,
                        border: Border.all(
                          color: Colors.white,
                          width: 4,
                        ),
                        boxShadow: [
                          BoxShadow(
                            color: Colors.black.withOpacity(0.2),
                            blurRadius: 8,
                            offset: const Offset(0, 4),
                          ),
                        ],
                      ),
                    child: CircleAvatar(
                      radius: ResponsiveHelper.isMobile(context) 
                          ? 60 
                          : ResponsiveHelper.isTablet(context) 
                              ? 70 
                              : 80, // Larger size for better visibility
                      backgroundColor: const Color(0xFFFEECE2),
                      backgroundImage: selectedImage != null
                          ? FileImage(selectedImage!)
                          : (profilePhoto != null && profilePhoto.isNotEmpty
                              ? NetworkImage('https://fruitofthespirit.templateforwebsites.com/$profilePhoto')
                              : null) as ImageProvider?,
                      child: selectedImage == null && (profilePhoto == null || profilePhoto.isEmpty)
                          ? Icon(
                              Icons.person,
                              size: ResponsiveHelper.isMobile(context) 
                                  ? 60 
                                  : ResponsiveHelper.isTablet(context) 
                                      ? 70 
                                      : 80, // Match avatar size
                              color: const Color(0xFF5F4628),
                            )
                          : null,
                    ),
                    ),
                  ),
                ),
              ),
            ),
          ],
        );
      },
    );
  }
}
