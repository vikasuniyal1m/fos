import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:fruitsofspirit/controllers/prayers_controller.dart';
import 'package:fruitsofspirit/utils/responsive_helper.dart';
import 'package:fruitsofspirit/utils/auto_translate_helper.dart';
import 'package:fruitsofspirit/routes/routes.dart';
import 'package:fruitsofspirit/widgets/cached_image.dart';
import 'package:fruitsofspirit/config/image_config.dart';
import 'package:fruitsofspirit/widgets/app_bottom_navigation_bar.dart';

/// Prayer Requests Screen
/// Modern, user-friendly design with attractive UI
class PrayerRequestsScreen extends GetView<PrayersController> {
  const PrayerRequestsScreen({Key? key}) : super(key: key);

  /// Get ImageProvider for profile photo (handles both network and assets)
  ImageProvider? _getImageProvider(String? photoUrl) {
    if (photoUrl == null || photoUrl.isEmpty) {
      return null;
    }
    
    if (photoUrl.startsWith('assets/') || photoUrl.startsWith('assets/images/')) {
      return AssetImage(photoUrl);
    }
    
    if (photoUrl.startsWith('http://') || photoUrl.startsWith('https://')) {
      return NetworkImage(photoUrl);
    }
    
    if (photoUrl.startsWith('file://')) {
      return null;
    }
    
    return NetworkImage('https://fruitofthespirit.templateforwebsites.com/$photoUrl');
  }

  /// Format time ago
  String _getTimeAgo(String? dateString) {
    if (dateString == null || dateString.isEmpty) return '';
    
    try {
      final date = DateTime.parse(dateString);
      final now = DateTime.now();
      final difference = now.difference(date);
      
      if (difference.inDays > 365) {
        final years = (difference.inDays / 365).floor();
        return '$years ${years == 1 ? 'year' : 'years'} ago';
      } else if (difference.inDays > 30) {
        final months = (difference.inDays / 30).floor();
        return '$months ${months == 1 ? 'month' : 'months'} ago';
      } else if (difference.inDays > 0) {
        return '${difference.inDays} ${difference.inDays == 1 ? 'day' : 'days'} ago';
      } else if (difference.inHours > 0) {
        return '${difference.inHours} ${difference.inHours == 1 ? 'hour' : 'hours'} ago';
      } else if (difference.inMinutes > 0) {
        return '${difference.inMinutes} ${difference.inMinutes == 1 ? 'minute' : 'minutes'} ago';
      } else {
        return 'Just now';
      }
    } catch (e) {
      return '';
    }
  }

  /// Get prayer type color
  Color _getPrayerTypeColor(String? category) {
    switch (category) {
      case 'Healing':
        return const Color(0xFF4CAF50); // Green
      case 'Peace & Anxiety':
        return const Color(0xFF2196F3); // Blue
      case 'Work & Provision':
        return const Color(0xFFFF9800); // Orange
      case 'Relationships':
        return const Color(0xFFE91E63); // Pink
      case 'Guidance':
        return const Color(0xFF9C27B0); // Purple
      default:
        return const Color(0xFF8B4513); // Brown
    }
  }

  @override
  Widget build(BuildContext context) {
    // Professional responsive design for tablets/iPads
    final isTabletDevice = ResponsiveHelper.isTablet(context);
    final double? maxContentWidthValue = isTabletDevice 
        ? (ResponsiveHelper.isLargeTablet(context) ? 1200.0 : 840.0)
        : null;
    
    return Scaffold(
      backgroundColor: Colors.white,
      appBar: PreferredSize(
        preferredSize: Size.fromHeight(
          ResponsiveHelper.safeHeight(
            context,
            mobile: 70,
            tablet: 120,
            desktop: 90,
          ),
        ),
        child: Container(
          decoration: BoxDecoration(
            color: Colors.white,
            boxShadow: [
              BoxShadow(
                color: Colors.black.withOpacity(0.05),
                blurRadius: ResponsiveHelper.isMobile(context) ? 4 : 8,
                offset: Offset(0, ResponsiveHelper.isMobile(context) ? 2 : 4),
              ),
            ],
            border: Border(
              bottom: BorderSide(
                color: Colors.grey.withOpacity(0.15),
                width: ResponsiveHelper.isMobile(context) ? 0.5 : 1,
              ),
            ),
          ),
          child: SafeArea(
            bottom: false,
            child: Padding(
              padding: ResponsiveHelper.padding(
                context,
                horizontal: ResponsiveHelper.isMobile(context)
                    ? ResponsiveHelper.spacing(context, 16)
                    : ResponsiveHelper.isTablet(context)
                        ? ResponsiveHelper.spacing(context, 24)
                        : ResponsiveHelper.spacing(context, 32),
                vertical: ResponsiveHelper.isMobile(context)
                    ? ResponsiveHelper.spacing(context, 12)
                    : ResponsiveHelper.isTablet(context)
                        ? ResponsiveHelper.spacing(context, 14)
                        : ResponsiveHelper.spacing(context, 16),
              ),
              child: Row(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                crossAxisAlignment: CrossAxisAlignment.center,
                children: [
                  // Left Side - Logo
                  Expanded(
                    flex: ResponsiveHelper.isDesktop(context) ? 4 : 3,
                    child: Align(
                      alignment: Alignment.centerLeft,
                      child: CachedImage(
                        imageUrl: ImageConfig.logo,
                        width: double.infinity,
                        height: ResponsiveHelper.isMobile(context)
                            ? 52.0
                            : ResponsiveHelper.isTablet(context)
                                ? 58.0
                                : 64.0,
                        fit: BoxFit.contain,
                        errorWidget: Text(
                          'Prayers',
                          style: ResponsiveHelper.textStyle(
                            context,
                            fontSize: ResponsiveHelper.fontSize(context, mobile: 22, tablet: 24, desktop: 26),
                            fontWeight: FontWeight.bold,
                            color: const Color(0xFF5F4628),
                          ),
                        ),
                      ),
                    ),
                  ),
                  SizedBox(
                    width: ResponsiveHelper.isMobile(context)
                        ? 12.0
                        : ResponsiveHelper.isTablet(context)
                            ? 16.0
                            : 20.0,
                  ),
                  // Right Side - Actions
                  Row(
                    mainAxisSize: MainAxisSize.min,
                    children: [
                      // Create Prayer Button
                      Material(
                        color: Colors.transparent,
                        child: InkWell(
                          onTap: () => Get.toNamed(Routes.CREATE_PRAYER),
                          borderRadius: BorderRadius.circular(30),
                          child: Container(
                            width: ResponsiveHelper.isMobile(context) ? 40.0 : ResponsiveHelper.isTablet(context) ? 44.0 : 48.0,
                            height: ResponsiveHelper.isMobile(context) ? 40.0 : ResponsiveHelper.isTablet(context) ? 44.0 : 48.0,
                            decoration: BoxDecoration(
                              gradient: LinearGradient(
                                begin: Alignment.topLeft,
                                end: Alignment.bottomRight,
                                colors: [
                                  const Color(0xFF8B4513),
                                  const Color(0xFFA0522D),
                                ],
                              ),
                              shape: BoxShape.circle,
                              boxShadow: [
                                BoxShadow(
                                  color: const Color(0xFF8B4513).withOpacity(0.3),
                                  blurRadius: 6,
                                  offset: const Offset(0, 3),
                                ),
                              ],
                            ),
                            child: Icon(
                              Icons.add,
                              color: Colors.white,
                              size: ResponsiveHelper.isMobile(context) ? 20.0 : ResponsiveHelper.isTablet(context) ? 22.0 : 24.0,
                            ),
                          ),
                        ),
                      ),
                      SizedBox(
                        width: ResponsiveHelper.isMobile(context) ? 10.0 : ResponsiveHelper.isTablet(context) ? 12.0 : 14.0,
                      ),
                      // Back Button
                      Material(
                        color: Colors.transparent,
                        child: InkWell(
                          onTap: () => Get.back(),
                          borderRadius: BorderRadius.circular(30),
                          child: Container(
                            width: ResponsiveHelper.isMobile(context) ? 40.0 : ResponsiveHelper.isTablet(context) ? 44.0 : 48.0,
                            height: ResponsiveHelper.isMobile(context) ? 40.0 : ResponsiveHelper.isTablet(context) ? 44.0 : 48.0,
                            decoration: BoxDecoration(
                              gradient: LinearGradient(
                                begin: Alignment.topLeft,
                                end: Alignment.bottomRight,
                                colors: [
                                  Colors.grey[50]!,
                                  Colors.grey[100]!,
                                ],
                              ),
                              shape: BoxShape.circle,
                              border: Border.all(
                                color: Colors.grey.withOpacity(0.2),
                                width: 1.5,
                              ),
                              boxShadow: [
                                BoxShadow(
                                  color: Colors.black.withOpacity(0.05),
                                  blurRadius: 4,
                                  offset: const Offset(0, 2),
                                ),
                              ],
                            ),
                            child: Icon(
                              Icons.arrow_back_rounded,
                              color: const Color(0xFF5F4628),
                              size: ResponsiveHelper.isMobile(context) ? 20.0 : ResponsiveHelper.isTablet(context) ? 22.0 : 24.0,
                            ),
                          ),
                        ),
                      ),
                    ],
                  ),
                ],
              ),
            ),
          ),
        ),
      ),
      body: Column(
        mainAxisSize: MainAxisSize.min,
        children: [
          // Search and Filter Section
          Container(
            color: Colors.white,
            padding: ResponsiveHelper.padding(
              context,
              all: ResponsiveHelper.isMobile(context) ? 14 : 16,
            ),
            child: Column(
              mainAxisSize: MainAxisSize.min,
              children: [
                // Category Filter Chips - Each chip has its own Obx, no need for outer Obx
                SingleChildScrollView(
                  scrollDirection: Axis.horizontal,
                  child: Row(
                    children: [
                      _buildFilterChip(context, 'All', '', controller, Icons.all_inclusive),
                      SizedBox(width: ResponsiveHelper.spacing(context, ResponsiveHelper.isMobile(context) ? 6 : 8)),
                      _buildFilterChip(context, 'Healing', 'Healing', controller, Icons.healing),
                      SizedBox(width: ResponsiveHelper.spacing(context, ResponsiveHelper.isMobile(context) ? 6 : 8)),
                      _buildFilterChip(context, 'Peace', 'Peace & Anxiety', controller, Icons.self_improvement),
                      SizedBox(width: ResponsiveHelper.spacing(context, ResponsiveHelper.isMobile(context) ? 6 : 8)),
                      _buildFilterChip(context, 'Work', 'Work & Provision', controller, Icons.work),
                      SizedBox(width: ResponsiveHelper.spacing(context, ResponsiveHelper.isMobile(context) ? 6 : 8)),
                      _buildFilterChip(context, 'Relationships', 'Relationships', controller, Icons.favorite),
                      SizedBox(width: ResponsiveHelper.spacing(context, ResponsiveHelper.isMobile(context) ? 6 : 8)),
                      _buildFilterChip(context, 'Guidance', 'Guidance', controller, Icons.lightbulb),
                    ],
                  ),
                ),
              ],
            ),
          ),
          
          // Prayer List
          Expanded(
            child: Obx(() {
              if (controller.isLoading.value && controller.prayers.isEmpty) {
                return Center(
                  child: Column(
                    mainAxisAlignment: MainAxisAlignment.center,
                    children: [
                      CircularProgressIndicator(
                        color: const Color(0xFF9F9467),
                      ),
                      SizedBox(height: ResponsiveHelper.spacing(context, ResponsiveHelper.isMobile(context) ? 14 : 16)),
                      Text(
                        'Loading prayers...',
                        style: TextStyle(
                          fontSize: ResponsiveHelper.fontSize(context, mobile: 13, tablet: 14, desktop: 15),
                          color: Colors.grey[600],
                        ),
                      ),
                    ],
                  ),
                );
              }

              if (controller.prayers.isEmpty) {
                return _buildEmptyState(context);
              }

              return RefreshIndicator(
                onRefresh: () async {
                  // Performance: Only refresh when user explicitly pulls to refresh
                  await controller.refresh();
                },
                color: const Color(0xFF9F9467),
                child: Center(
                  child: ResponsiveHelper.constrainedContent(
                    context: context,
                    maxWidth: maxContentWidthValue,
                    child: ListView.builder(
                  padding: ResponsiveHelper.padding(
                    context,
                    all: ResponsiveHelper.isMobile(context) ? 14 : 16,
                  ),
                  itemCount: controller.prayers.length,
                  itemBuilder: (context, index) {
                    final prayer = controller.prayers[index];
                    return _buildPrayerCard(context, prayer, controller);
                  },
                    ),
                  ),
                ),
              );
            }),
          ),
        ],
      ),
      bottomNavigationBar: const AppBottomNavigationBar(currentIndex: 2),
    );
  }

  Widget _buildEmptyState(BuildContext context) {
    return Center(
      child: Column(
        mainAxisAlignment: MainAxisAlignment.center,
        children: [
          Container(
            padding: ResponsiveHelper.padding(
              context,
              all: ResponsiveHelper.isMobile(context) ? 20 : 24,
            ),
            decoration: BoxDecoration(
              color: Colors.white,
              shape: BoxShape.circle,
              boxShadow: [
                BoxShadow(
                  color: Colors.grey.withOpacity(0.1),
                  blurRadius: 20,
                  spreadRadius: 5,
                ),
              ],
            ),
            child: Icon(
              Icons.favorite_outline,
              size: ResponsiveHelper.iconSize(context, mobile: 56, tablet: 64, desktop: 72),
              color: Colors.grey[400],
            ),
          ),
          SizedBox(height: ResponsiveHelper.spacing(context, ResponsiveHelper.isMobile(context) ? 20 : 24)),
          Text(
            'No Prayer Requests Yet',
            style: ResponsiveHelper.textStyle(
              context,
              fontSize: ResponsiveHelper.fontSize(context, mobile: 18, tablet: 20, desktop: 22),
              fontWeight: FontWeight.bold,
              color: const Color(0xFF5F4628),
            ),
          ),
          SizedBox(height: ResponsiveHelper.spacing(context, ResponsiveHelper.isMobile(context) ? 6 : 8)),
          Text(
            'Be the first to share your prayer request',
            style: ResponsiveHelper.textStyle(
              context,
              fontSize: ResponsiveHelper.fontSize(context, mobile: 13, tablet: 14, desktop: 15),
              color: Colors.grey[600],
            ),
          ),
          SizedBox(height: ResponsiveHelper.spacing(context, ResponsiveHelper.isMobile(context) ? 24 : 32)),
          ElevatedButton(
            onPressed: () => Get.toNamed(Routes.CREATE_PRAYER),
            style: ElevatedButton.styleFrom(
              backgroundColor: const Color(0xFF9F9467),
              padding: ResponsiveHelper.padding(
                context,
                horizontal: ResponsiveHelper.isMobile(context) ? 24 : 32,
                vertical: ResponsiveHelper.isMobile(context) ? 14 : 16,
              ),
              shape: RoundedRectangleBorder(
                borderRadius: BorderRadius.circular(ResponsiveHelper.borderRadius(context, mobile: 12)),
              ),
              elevation: 2,
            ),
            child: Text(
              'Create Prayer Request',
              style: ResponsiveHelper.textStyle(
                context,
                fontSize: ResponsiveHelper.fontSize(context, mobile: 15, tablet: 16, desktop: 17),
                color: Colors.white,
                fontWeight: FontWeight.bold,
              ),
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildFilterChip(BuildContext context, String label, String category, PrayersController controller, IconData icon) {
    // Performance: Use Obx to make it reactive to filter changes
    return Obx(() {
      final isSelected = controller.selectedCategory.value == category;
      return FilterChip(
        avatar: Icon(
          icon,
          size: ResponsiveHelper.iconSize(context, mobile: 14, tablet: 16, desktop: 18),
          color: isSelected ? Colors.white : const Color(0xFF5F4628),
        ),
        label: Text(
          label,
          style: ResponsiveHelper.textStyle(
            context,
            fontSize: ResponsiveHelper.fontSize(context, mobile: 12, tablet: 13, desktop: 14),
            fontWeight: isSelected ? FontWeight.bold : FontWeight.w500,
            color: isSelected ? Colors.white : const Color(0xFF5F4628),
          ),
        ),
        selected: isSelected,
        onSelected: (selected) {
          if (selected) {
            // Performance: Only filter if category is actually changing
            if (controller.selectedCategory.value != category) {
              controller.filterByCategory(category);
            }
          } else {
            // Performance: Only clear if filter is actually set
            if (controller.selectedCategory.value.isNotEmpty) {
              controller.clearFilter();
            }
          }
        },
        selectedColor: const Color(0xFF9F9467),
        checkmarkColor: Colors.white,
        backgroundColor: Colors.grey[100],
        padding: ResponsiveHelper.padding(
          context,
          horizontal: ResponsiveHelper.isMobile(context) ? 10 : 12,
          vertical: ResponsiveHelper.isMobile(context) ? 6 : 8,
        ),
        side: BorderSide(
          color: isSelected ? const Color(0xFF9F9467) : Colors.grey[300]!,
          width: isSelected ? 2 : 1,
        ),
        shape: RoundedRectangleBorder(
          borderRadius: BorderRadius.circular(ResponsiveHelper.borderRadius(context, mobile: 20)),
        ),
      );
    });
  }

  Widget _buildPrayerCard(BuildContext context, Map<String, dynamic> prayer, PrayersController controller) {
    final isAnonymous = prayer['is_anonymous'] == 1 || prayer['is_anonymous'] == true;
    final userName = isAnonymous ? 'Anonymous' : (prayer['user_name'] ?? prayer['name'] ?? 'Anonymous');
    String? profilePhotoUrl;
    if (!isAnonymous && prayer['profile_photo'] != null && prayer['profile_photo'].toString().isNotEmpty) {
      final photoPath = prayer['profile_photo'].toString();
      if (!photoPath.startsWith('assets/') && !photoPath.startsWith('file://') && !photoPath.startsWith('assets/images/')) {
        profilePhotoUrl = 'https://fruitofthespirit.templateforwebsites.com/$photoPath';
      }
    }
    final prayerContent = AutoTranslateHelper.getTranslatedTextSync(
      text: prayer['content'] ?? '',
      sourceLanguage: prayer['language'] as String?,
    );
    final responseCount = int.tryParse((prayer['response_count'] ?? 0).toString()) ?? 0;
    final commentCount = int.tryParse((prayer['comment_count'] ?? 0).toString()) ?? 0;
    // Get prayer type - check multiple fields
    final category = prayer['category'] as String? ?? prayer['type'] as String? ?? prayer['prayer_type'] as String? ?? 'Prayer Request';
    
    return InkWell(
      onTap: () => Get.toNamed(Routes.PRAYER_DETAILS, arguments: prayer['id']),
      borderRadius: BorderRadius.circular(12),
      child: Container(
        margin: ResponsiveHelper.safeMargin(
          context,
          bottom: ResponsiveHelper.isMobile(context) ? 14 : 16,
        ),
        decoration: BoxDecoration(
          color: Colors.white,
          borderRadius: BorderRadius.circular(12),
          boxShadow: [
            BoxShadow(
              color: Colors.black.withOpacity(0.05),
              spreadRadius: 0,
              blurRadius: 8,
              offset: const Offset(0, 1),
            ),
          ],
        ),
        child: Column(
          mainAxisSize: MainAxisSize.min,
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            // Header - Profile + Name + Three-dot menu (Exact match home screen)
            Padding(
              padding: const EdgeInsets.all(16),
              child: Row(
                children: [
                  // Profile Picture - Exact same as home screen
                  profilePhotoUrl != null && !isAnonymous
                      ? ClipOval(
                          child: CachedImage(
                            imageUrl: profilePhotoUrl,
                            width: 48,
                            height: 48,
                            fit: BoxFit.cover,
                            errorWidget: CircleAvatar(
                              radius: 24,
                              backgroundColor: Colors.grey[300]!,
                              child: Icon(
                                Icons.person_rounded,
                                size: 24,
                                color: Colors.grey[600],
                              ),
                            ),
                          ),
                        )
                      : CircleAvatar(
                          radius: 24,
                          backgroundColor: Colors.grey[300]!,
                          child: Icon(
                            Icons.person_rounded,
                            size: 24,
                            color: isAnonymous ? Colors.grey[600] : const Color(0xFF5F4628),
                          ),
                        ),
                  const SizedBox(width: 12),
                  // Name - Exact same as home screen
                  Expanded(
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      mainAxisSize: MainAxisSize.min,
                      children: [
                        Text(
                          userName,
                          style: const TextStyle(
                            fontSize: 16,
                            fontWeight: FontWeight.bold,
                            color: Colors.black,
                          ),
                          overflow: TextOverflow.ellipsis,
                          maxLines: 1,
                        ),
                      ],
                    ),
                  ),
                  // Three-dot menu - Exact match
                  IconButton(
                    icon: Icon(
                      Icons.more_vert,
                      size: 20,
                      color: Colors.grey[600],
                    ),
                    onPressed: () {
                      // Menu options can be added here
                    },
                    padding: EdgeInsets.zero,
                    constraints: const BoxConstraints(),
                  ),
                ],
              ),
            ),
            // Prayer Type - Below name (Exact same as home screen subtitle)
            Padding(
              padding: ResponsiveHelper.padding(
                context,
                horizontal: ResponsiveHelper.isMobile(context) ? 14 : 16,
                vertical: 0,
              ),
              child: Text(
                category,
                style: TextStyle(
                  fontSize: 14,
                  color: Colors.grey[600],
                  fontWeight: FontWeight.normal,
                ),
                overflow: TextOverflow.ellipsis,
                maxLines: 1,
              ),
            ),
            const SizedBox(height: 12),
            // Content - Full content displayed (Same style as home screen)
            Padding(
              padding: ResponsiveHelper.padding(
                context,
                horizontal: ResponsiveHelper.isMobile(context) ? 14 : 16,
                vertical: 0,
              ),
              child: Text(
                prayerContent,
                style: const TextStyle(
                  fontSize: 14,
                  color: Colors.black87,
                  height: 1.5,
                  fontWeight: FontWeight.normal,
                ),
              ),
            ),
            const SizedBox(height: 16),
            // Bottom Actions - Left: Prayed count, Right: Comments count (Exact match home screen)
            Padding(
              padding: ResponsiveHelper.padding(
                context,
                horizontal: ResponsiveHelper.isMobile(context) ? 14 : 16,
                vertical: ResponsiveHelper.isMobile(context) ? 10 : 12,
              ),
              child: Row(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                children: [
                  // Left: Prayed count with icon - Only show if > 0 (Exact match)
                  if (responseCount > 0)
                    Row(
                      mainAxisSize: MainAxisSize.min,
                      children: [
                        Icon(
                          Icons.favorite,
                          size: 18,
                          color: Colors.blue[600],
                        ),
                        const SizedBox(width: 6),
                        Text(
                          '$responseCount prayed',
                          style: TextStyle(
                            fontSize: ResponsiveHelper.fontSize(context, mobile: 13, tablet: 14, desktop: 15),
                            color: Colors.blue[600],
                            fontWeight: FontWeight.normal,
                          ),
                        ),
                      ],
                    ),
                  // Right: Comments count with icon - Only show if > 0 (Exact match)
                  if (commentCount > 0)
                    Row(
                      mainAxisSize: MainAxisSize.min,
                      children: [
                        Icon(
                          Icons.comment_outlined,
                          size: 18,
                          color: Colors.grey[600],
                        ),
                        const SizedBox(width: 6),
                        Text(
                          '$commentCount Comments',
                          style: TextStyle(
                            fontSize: ResponsiveHelper.fontSize(context, mobile: 13, tablet: 14, desktop: 15),
                            color: Colors.grey[600],
                            fontWeight: FontWeight.normal,
                          ),
                        ),
                      ],
                    ),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }
}
