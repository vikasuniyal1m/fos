import 'dart:convert';
import 'dart:typed_data';

/// URL Obfuscator
/// Hides API URLs in production builds using character encoding
class UrlObfuscator {
  // Obfuscate URL using character codes (harder to find in reverse engineering)
  static String obfuscateUrl(String url) {
    List<int> charCodes = [];
    for (int i = 0; i < url.length; i++) {
      charCodes.add(url.codeUnitAt(i) + 3); // Shift characters by +3
    }
    return String.fromCharCodes(charCodes);
  }
  
  // Deobfuscate URL
  static String deobfuscateUrl(String obfuscatedUrl) {
    List<int> charCodes = [];
    for (int i = 0; i < obfuscatedUrl.length; i++) {
      charCodes.add(obfuscatedUrl.codeUnitAt(i) - 3); // Shift back by -3
    }
    return String.fromCharCodes(charCodes);
  }
  
  // Base64 encode for additional obfuscation
  static String base64Encode(String input) {
    return base64.encode(utf8.encode(input));
  }
  
  static String base64Decode(String input) {
    return utf8.decode(base64.decode(input));
  }
  
  // Split URL into parts and encode each part differently
  static String advancedObfuscate(String url) {
    // Split URL into parts
    final parts = url.split('.');
    if (parts.length < 2) return url;
    
    // Encode domain and TLD separately
    final domain = base64Encode(parts[0]);
    final tld = parts[1];
    final path = parts.length > 2 ? '.' + parts.sublist(2).join('.') : '';
    
    return '$domain.$tld$path';
  }
  
  // Reverse the advanced obfuscation
  static String advancedDeobfuscate(String obfuscatedUrl) {
    final parts = obfuscatedUrl.split('.');
    if (parts.length < 2) return obfuscatedUrl;
    
    try {
      final domain = base64Decode(parts[0]);
      final tld = parts[1];
      final path = parts.length > 2 ? '.' + parts.sublist(2).join('.') : '';
      
      return '$domain.$tld$path';
    } catch (e) {
      return obfuscatedUrl; // Return original if decode fails
    }
  }
}
