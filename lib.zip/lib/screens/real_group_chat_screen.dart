import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:image_picker/image_picker.dart';
import 'package:fruitsofspirit/controllers/group_chat_controller.dart';
import 'package:fruitsofspirit/controllers/groups_controller.dart';
import 'package:fruitsofspirit/utils/responsive_helper.dart';
import 'package:fruitsofspirit/widgets/cached_image.dart';
import 'package:fruitsofspirit/config/image_config.dart';
import 'package:fruitsofspirit/services/emojis_service.dart';
import 'package:fruitsofspirit/screens/home_screen.dart';
import 'dart:io';

/// Real Group Chat Screen - App Theme Style
/// Shows real-time chat messages with app theme colors
class RealGroupChatScreen extends StatefulWidget {
  final int groupId;
  final String groupName;
  
  const RealGroupChatScreen({
    Key? key,
    required this.groupId,
    required this.groupName,
  }) : super(key: key);

  @override
  State<RealGroupChatScreen> createState() => _RealGroupChatScreenState();
}

class _RealGroupChatScreenState extends State<RealGroupChatScreen> {
  final GroupChatController controller = Get.put(GroupChatController());
  final TextEditingController messageController = TextEditingController();
  final ScrollController scrollController = ScrollController();
  final ImagePicker _picker = ImagePicker();
  var availableEmojis = <Map<String, dynamic>>[].obs;
  var isLoadingEmojis = true.obs;
  int? groupOwnerId; // Group owner/creator ID

  @override
  void initState() {
    super.initState();
    WidgetsBinding.instance.addPostFrameCallback((_) {
      // Load messages for this specific group
      print('🔄 Loading messages for group ${widget.groupId}');
      controller.loadMessages(widget.groupId, refresh: true);
      _loadEmojis();
      _loadGroupOwner();
    });
    
    // Auto-scroll to bottom when new messages arrive (only for current group)
    controller.messages.listen((_) {
      Future.delayed(const Duration(milliseconds: 100), () {
        if (scrollController.hasClients) {
          scrollController.animateTo(
            scrollController.position.maxScrollExtent,
            duration: const Duration(milliseconds: 300),
            curve: Curves.easeOut,
          );
        }
      });
    });
  }
  
  @override
  void didUpdateWidget(RealGroupChatScreen oldWidget) {
    super.didUpdateWidget(oldWidget);
    // If group changed, reload messages
    if (oldWidget.groupId != widget.groupId) {
      print('🔄 Group changed: ${oldWidget.groupId} -> ${widget.groupId}');
      controller.loadMessages(widget.groupId, refresh: true);
    }
  }

  Future<void> _loadEmojis() async {
    try {
      isLoadingEmojis.value = true;
      final emojis = await EmojisService.getEmojis(
        status: 'Active',
        sortBy: 'image_url',
        order: 'ASC',
      );
      availableEmojis.value = emojis;
    } catch (e) {
      print('Error loading emojis: $e');
      availableEmojis.value = [];
    } finally {
      isLoadingEmojis.value = false;
    }
  }

  Future<void> _loadGroupOwner() async {
    try {
      // Try to get group info from GroupsController
      try {
        final groupsController = Get.find<GroupsController>();
        final selectedGroup = groupsController.selectedGroup;
        if (selectedGroup != null && selectedGroup['id'] == widget.groupId) {
          groupOwnerId = selectedGroup['created_by'] as int?;
          print('✅ Group owner ID from GroupsController: $groupOwnerId');
          return;
        }
      } catch (e) {
        print('⚠️ GroupsController not found: $e');
      }
      
      // If not found, try to get from messages (some messages might have group owner info)
      // Or we can load group details from API
      // For now, we'll check if any message has group owner info
      if (groupOwnerId == null && controller.messages.isNotEmpty) {
        // Check first message or any message for group owner info
        // This is a fallback - ideally we should load group details
        print('⚠️ Group owner ID not found, will check messages');
      }
    } catch (e) {
      print('Error loading group owner: $e');
    }
  }

  @override
  void dispose() {
    messageController.dispose();
    scrollController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.white, // App theme background
      appBar: PreferredSize(
        preferredSize: Size.fromHeight(
          ResponsiveHelper.safeHeight(
            context,
            mobile: 70,
            tablet: 120,
            desktop: 90,
          ),
        ),
        child: Container(
          decoration: BoxDecoration(
            color: Colors.white,
            boxShadow: [
              BoxShadow(
                color: Colors.black.withOpacity(0.05),
                blurRadius: ResponsiveHelper.isMobile(context) ? 4 : 8,
                offset: Offset(0, ResponsiveHelper.isMobile(context) ? 2 : 4),
              ),
            ],
            border: Border(
              bottom: BorderSide(
                color: Colors.grey.withOpacity(0.15),
                width: ResponsiveHelper.isMobile(context) ? 0.5 : 1,
              ),
            ),
          ),
          child: SafeArea(
            bottom: false,
            child: Padding(
              padding: ResponsiveHelper.padding(
                context,
                horizontal: ResponsiveHelper.isMobile(context)
                    ? ResponsiveHelper.spacing(context, 16)
                    : ResponsiveHelper.isTablet(context)
                        ? ResponsiveHelper.spacing(context, 24)
                        : ResponsiveHelper.spacing(context, 32),
                vertical: ResponsiveHelper.isMobile(context)
                    ? ResponsiveHelper.spacing(context, 12)
                    : ResponsiveHelper.isTablet(context)
                        ? ResponsiveHelper.spacing(context, 14)
                        : ResponsiveHelper.spacing(context, 16),
              ),
              child: Row(
                children: [
                  // Back button
                  Material(
                    color: Colors.transparent,
                    child: InkWell(
                      onTap: () => Get.back(),
                      borderRadius: BorderRadius.circular(30),
                      child: Container(
                        width: ResponsiveHelper.isMobile(context) ? 40.0 : ResponsiveHelper.isTablet(context) ? 44.0 : 48.0,
                        height: ResponsiveHelper.isMobile(context) ? 40.0 : ResponsiveHelper.isTablet(context) ? 44.0 : 48.0,
                        decoration: BoxDecoration(
                          gradient: LinearGradient(
                            begin: Alignment.topLeft,
                            end: Alignment.bottomRight,
                            colors: [
                              Colors.grey[50]!,
                              Colors.grey[100]!,
                            ],
                          ),
                          shape: BoxShape.circle,
                          border: Border.all(
                            color: Colors.grey.withOpacity(0.2),
                            width: 1.5,
                          ),
                          boxShadow: [
                            BoxShadow(
                              color: Colors.black.withOpacity(0.05),
                              blurRadius: 4,
                              offset: const Offset(0, 2),
                            ),
                          ],
                        ),
                        child: Icon(
                          Icons.arrow_back_rounded,
                          color: const Color(0xFF5F4628),
                          size: ResponsiveHelper.isMobile(context) ? 20.0 : ResponsiveHelper.isTablet(context) ? 22.0 : 24.0,
                        ),
                      ),
                    ),
                  ),
                  SizedBox(width: ResponsiveHelper.spacing(context, 12)),
                  // Group avatar
                  CircleAvatar(
                    radius: ResponsiveHelper.isMobile(context) ? 20 : 24,
                    backgroundColor: const Color(0xFF8B4513).withOpacity(0.1),
                    child: Icon(
                      Icons.group,
                      color: const Color(0xFF8B4513),
                      size: ResponsiveHelper.isMobile(context) ? 24 : 28,
                    ),
                  ),
                  SizedBox(width: ResponsiveHelper.spacing(context, 12)),
                  // Group name and member count
                  Expanded(
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      mainAxisAlignment: MainAxisAlignment.center,
                      children: [
                        Text(
                          widget.groupName,
                          style: ResponsiveHelper.textStyle(
                            context,
                            fontSize: ResponsiveHelper.fontSize(context, mobile: 16, tablet: 18, desktop: 20),
                            fontWeight: FontWeight.bold,
                            color: const Color(0xFF5F4628),
                          ),
                          maxLines: 1,
                          overflow: TextOverflow.ellipsis,
                        ),
                        Obx(() {
                          // Count unique users in current group messages
                          final groupMessages = controller.messages.where((m) {
                            final msgGroupId = m['group_id'] as int?;
                            return msgGroupId == widget.groupId;
                          }).toList();
                          
                          final memberCount = groupMessages
                              .map((m) => m['user_id'])
                              .toSet()
                              .length;
                          return Text(
                            '$memberCount members',
                            style: ResponsiveHelper.textStyle(
                              context,
                              fontSize: ResponsiveHelper.fontSize(context, mobile: 12, tablet: 13, desktop: 14),
                              color: Colors.grey[600],
                            ),
                          );
                        }),
                      ],
                    ),
                  ),
                  // More options
                  Material(
                    color: Colors.transparent,
                    child: InkWell(
                      onTap: () {
                        // Group info menu
                      },
                      borderRadius: BorderRadius.circular(30),
                      child: Container(
                        width: ResponsiveHelper.isMobile(context) ? 40.0 : ResponsiveHelper.isTablet(context) ? 44.0 : 48.0,
                        height: ResponsiveHelper.isMobile(context) ? 40.0 : ResponsiveHelper.isTablet(context) ? 44.0 : 48.0,
                        decoration: BoxDecoration(
                          gradient: LinearGradient(
                            begin: Alignment.topLeft,
                            end: Alignment.bottomRight,
                            colors: [
                              Colors.grey[50]!,
                              Colors.grey[100]!,
                            ],
                          ),
                          shape: BoxShape.circle,
                          border: Border.all(
                            color: Colors.grey.withOpacity(0.2),
                            width: 1.5,
                          ),
                        ),
                        child: Icon(
                          Icons.more_vert,
                          color: const Color(0xFF5F4628),
                          size: ResponsiveHelper.isMobile(context) ? 20.0 : ResponsiveHelper.isTablet(context) ? 22.0 : 24.0,
                        ),
                      ),
                    ),
                  ),
                ],
              ),
            ),
          ),
        ),
      ),
      body: Column(
        children: [
          // Messages List
          Expanded(
            child: Obx(() {
              // Debug logging
              print('📊 Messages List State:');
              print('   Total messages: ${controller.messages.length}');
              print('   Current groupId: ${widget.groupId}');
              print('   isLoading: ${controller.isLoading.value}');
              
              // Filter messages by current group_id
              // If group_id is missing, assume it's for current group (for backward compatibility)
              final groupMessages = controller.messages.where((msg) {
                final msgGroupId = msg['group_id'] as int?;
                // If group_id is null or matches current group, include it
                final matches = msgGroupId == null || msgGroupId == widget.groupId;
                if (matches) {
                  // Ensure message has group_id set
                  if (msgGroupId == null) {
                    msg['group_id'] = widget.groupId;
                  }
                  print('   ✅ Message matches group: id=${msg['id']}, group_id=${msg['group_id']}, text="${msg['message']}"');
                } else {
                  print('   ❌ Message filtered out: id=${msg['id']}, group_id=$msgGroupId (expected ${widget.groupId})');
                }
                return matches;
              }).toList();
              
              print('   Filtered groupMessages: ${groupMessages.length} out of ${controller.messages.length} total');
              
              if (controller.isLoading.value && groupMessages.isEmpty) {
                print('   ⏳ Showing loading indicator');
                return Center(
                  child: CircularProgressIndicator(
                    color: const Color(0xFF8B4513),
                  ),
                );
              }

              if (groupMessages.isEmpty) {
                print('   📭 No messages found - showing empty state');
                // Show debug info if messages exist but don't match
                if (controller.messages.isNotEmpty) {
                  print('   ⚠️ WARNING: ${controller.messages.length} messages exist but none match groupId ${widget.groupId}');
                  print('   ⚠️ Current groupId: ${widget.groupId}');
                  for (var msg in controller.messages.take(5)) {
                    final msgGroupId = msg['group_id'];
                    print('      Sample message: id=${msg['id']}, group_id=$msgGroupId (type: ${msgGroupId.runtimeType}), text="${msg['message']}"');
                  }
                  
                  // TEMPORARY: If no messages match, show all messages for debugging
                  // Remove this after fixing the group_id issue
                  if (controller.messages.length > 0) {
                    print('   🔧 TEMPORARY: Showing all messages for debugging');
                    final allMessages = controller.messages.map((msg) {
                      if (msg['group_id'] == null) {
                        msg['group_id'] = widget.groupId;
                      }
                      return msg;
                    }).toList();
                    
                    return RefreshIndicator(
                      onRefresh: () => controller.refresh(),
                      color: const Color(0xFF8B4513),
                      child: ListView.builder(
                        controller: scrollController,
                        padding: EdgeInsets.all(ResponsiveHelper.spacing(context, 8)),
                        reverse: false,
                        itemCount: allMessages.length,
                        itemBuilder: (context, index) {
                          final msg = allMessages[index];
                          return _buildMessageBubble(context, msg, index, allMessages);
                        },
                      ),
                    );
                  }
                } else {
                  print('   ℹ️ No messages loaded yet. isLoading: ${controller.isLoading.value}');
                }
                
                return Center(
                  child: Column(
                    mainAxisAlignment: MainAxisAlignment.center,
                    children: [
                      Icon(
                        Icons.chat_bubble_outline,
                        size: 64,
                        color: Colors.grey[400],
                      ),
                      const SizedBox(height: 16),
                      Text(
                        'No messages yet',
                        style: TextStyle(
                          fontSize: 16,
                          color: Colors.grey[600],
                        ),
                      ),
                      const SizedBox(height: 8),
                      Text(
                        'Start the conversation!',
                        style: TextStyle(
                          fontSize: 14,
                          color: Colors.grey[500],
                        ),
                      ),
                      if (controller.messages.isNotEmpty) ...[
                        const SizedBox(height: 16),
                        Text(
                          'Debug: ${controller.messages.length} messages loaded\nbut none match group ${widget.groupId}',
                          style: TextStyle(
                            fontSize: 12,
                            color: Colors.red[300],
                          ),
                          textAlign: TextAlign.center,
                        ),
                      ],
                    ],
                  ),
                );
              }
              
              print('   ✅ Displaying ${groupMessages.length} messages');
              
              return RefreshIndicator(
                onRefresh: () => controller.refresh(),
                color: const Color(0xFF8B4513),
                child: ListView.builder(
                  controller: scrollController,
                  padding: EdgeInsets.all(ResponsiveHelper.spacing(context, 8)),
                  reverse: false,
                  itemCount: groupMessages.length + (controller.hasMore.value ? 1 : 0),
                  itemBuilder: (context, index) {
                    if (index == 0 && controller.hasMore.value) {
                      // Load more button
                      return Center(
                        child: TextButton(
                          onPressed: () => controller.loadMore(),
                          child: const Text('Load older messages'),
                        ),
                      );
                    }
                    
                    final messageIndex = controller.hasMore.value ? index - 1 : index;
                    if (messageIndex >= groupMessages.length) {
                      return const SizedBox.shrink();
                    }
                    final msg = groupMessages[messageIndex];
                    // Pass filtered messages list for avatar display logic
                    return _buildMessageBubble(context, msg, messageIndex, groupMessages);
                  },
                ),
              );
            }),
          ),
          
          // Message Input
          _buildMessageInput(context),
        ],
      ),
    );
  }

  Widget _buildMessageBubble(BuildContext context, Map<String, dynamic> msg, int index, List<Map<String, dynamic>> groupMessages) {
    final msgUserId = msg['user_id'] as int? ?? 0;
    final isOwner = groupOwnerId != null && msgUserId == groupOwnerId;
    final isMe = msgUserId == controller.userId.value;
    // Owner messages on LEFT (white), Member messages on RIGHT (brown)
    final isLeftSide = isOwner;
    final userName = msg['user_name'] as String? ?? 'Unknown';
    final messageText = msg['message'] as String? ?? '';
    final messageType = msg['message_type'] as String? ?? 'text';
    final createdAt = msg['created_at'] as String? ?? '';
    final fileUrl = msg['file_url'] as String?;
    final profilePhoto = msg['profile_photo'] as String?;
    
    // Skip empty messages
    if ((messageText.isEmpty || messageText.trim().isEmpty || messageText == 'null') && 
        messageType == 'text' && 
        (fileUrl == null || fileUrl.isEmpty)) {
      print('⚠️ Skipping empty message: id=${msg['id']}, text="$messageText"');
      return const SizedBox.shrink();
    }
    
    print('💬 _buildMessageBubble: messageText="$messageText", messageType=$messageType, isOwner=$isOwner, isLeftSide=$isLeftSide, userId=$msgUserId, ownerId=$groupOwnerId');
    
    final baseUrl = 'https://fruitofthespirit.templateforwebsites.com/';
    String? photoUrl;
    if (profilePhoto != null && profilePhoto.isNotEmpty) {
      final photoPath = profilePhoto.toString();
      if (!photoPath.startsWith('http')) {
        photoUrl = baseUrl + (photoPath.startsWith('/') ? photoPath.substring(1) : photoPath);
      } else {
        photoUrl = photoPath;
      }
    }

    return Container(
      margin: EdgeInsets.only(
        bottom: ResponsiveHelper.spacing(context, 1), // Professional chat spacing
        top: _shouldShowAvatar(msg, index, groupMessages) ? ResponsiveHelper.spacing(context, 2) : ResponsiveHelper.spacing(context, 0.5),
      ),
      child: Row(
        mainAxisAlignment: isLeftSide ? MainAxisAlignment.start : MainAxisAlignment.end,
        crossAxisAlignment: CrossAxisAlignment.end,
        children: [
          // Avatar (only for left side/owner, only when new sender)
          if (isLeftSide && _shouldShowAvatar(msg, index, groupMessages)) ...[
            CircleAvatar(
              radius: 16, // Professional chat avatar size
              backgroundColor: Colors.grey[300],
              backgroundImage: photoUrl != null ? NetworkImage(photoUrl) : null,
              child: photoUrl == null
                  ? Text(
                      userName.isNotEmpty ? userName[0].toUpperCase() : '?',
                      style: const TextStyle(fontSize: 14, color: Colors.black87),
                    )
                  : null,
            ),
            const SizedBox(width: 8),
          ] else if (isLeftSide) ...[
            const SizedBox(width: 40), // Avatar width + spacing
          ],
          
          // Message Bubble
          Flexible(
            child: Container(
              constraints: BoxConstraints(
                maxWidth: MediaQuery.of(context).size.width * 0.75,
              ),
              padding: EdgeInsets.symmetric(
                horizontal: ResponsiveHelper.spacing(context, 12), // Professional chat padding
                vertical: ResponsiveHelper.spacing(context, 8), // Professional chat padding
              ),
              decoration: BoxDecoration(
                color: isLeftSide 
                    ? Colors.white  // Owner messages - WHITE background (LEFT side)
                    : const Color(0xFF8B4513).withOpacity(0.15), // Member messages - LIGHT brown background (RIGHT side)
                borderRadius: BorderRadius.only(
                  topLeft: Radius.circular(ResponsiveHelper.borderRadius(context, mobile: 12)),
                  topRight: Radius.circular(ResponsiveHelper.borderRadius(context, mobile: 12)),
                  bottomLeft: Radius.circular(isLeftSide ? ResponsiveHelper.borderRadius(context, mobile: 12) : 0),
                  bottomRight: Radius.circular(isLeftSide ? 0 : ResponsiveHelper.borderRadius(context, mobile: 12)),
                ),
                border: Border.all(
                  color: isLeftSide 
                      ? Colors.grey.withOpacity(0.2)  // Owner messages - grey border
                      : const Color(0xFF8B4513).withOpacity(0.2), // Member messages - brown border
                  width: 1,
                ),
                boxShadow: [
                  BoxShadow(
                    color: Colors.black.withOpacity(0.03), // Reduced opacity
                    blurRadius: 2, // Reduced from 4
                    offset: const Offset(0, 1), // Reduced from 2
                  ),
                ],
              ),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                mainAxisSize: MainAxisSize.min, // Added to reduce height
                children: [
                  // User name (only for left side/owner, only when new sender)
                  if (isLeftSide && _shouldShowAvatar(msg, index, groupMessages)) ...[
                    Text(
                      userName + (isOwner ? ' (Owner)' : ''),
                      style: ResponsiveHelper.textStyle(
                        context,
                        fontSize: ResponsiveHelper.fontSize(context, mobile: 13, tablet: 14, desktop: 15),
                        fontWeight: FontWeight.w600, // Professional chat name weight
                        color: const Color(0xFF8B4513),
                      ),
                    ),
                    const SizedBox(height: 4),
                  ],
                  
                  // Message content
                  if (messageType == 'image' && fileUrl != null) ...[
                    ClipRRect(
                      borderRadius: BorderRadius.circular(4),
                      child: CachedImage(
                        imageUrl: fileUrl,
                        width: double.infinity,
                        height: 150, // Reduced from 200
                        fit: BoxFit.cover,
                      ),
                    ),
                    if (messageText.isNotEmpty) ...[
                      const SizedBox(height: 4), // Reduced from 8
                      Text(
                        messageText,
                        style: const TextStyle(fontSize: 13, color: Colors.black87), // Reduced from 14
                      ),
                    ],
                  ] else if (messageType == 'file' && fileUrl != null) ...[
                    Container(
                      padding: const EdgeInsets.all(12),
                      decoration: BoxDecoration(
                        color: Colors.grey[200],
                        borderRadius: BorderRadius.circular(4),
                      ),
                      child: Row(
                        children: [
                          const Icon(Icons.insert_drive_file, size: 24),
                          const SizedBox(width: 8),
                          Expanded(
                            child: Text(
                              messageText.isNotEmpty ? messageText : 'File',
                              style: const TextStyle(fontSize: 14),
                              overflow: TextOverflow.ellipsis,
                            ),
                          ),
                        ],
                      ),
                    ),
                  ] else ...[
                    _buildMessageText(context, messageText),
                  ],
                  
                  // Timestamp
                  const SizedBox(height: 4),
                  Align(
                    alignment: isLeftSide ? Alignment.bottomLeft : Alignment.bottomRight,
                    child: Text(
                      _formatTime(createdAt),
                      style: TextStyle(
                        fontSize: 11, // Professional chat timestamp size
                        color: Colors.grey[600],
                      ),
                    ),
                  ),
                ],
              ),
            ),
          ),
          
          // Spacing for alignment
          if (!isLeftSide) ...[
            const SizedBox(width: 8),
          ],
        ],
      ),
    );
  }

  bool _shouldShowAvatar(Map<String, dynamic> msg, int index, List<Map<String, dynamic>> groupMessages) {
    if (index == 0) return true;
    if (index >= groupMessages.length) return true;
    final prevMsg = groupMessages[index - 1];
    return prevMsg['user_id'] != msg['user_id'];
  }

  Widget _buildMessageInput(BuildContext context) {
    return Container(
      padding: EdgeInsets.symmetric(
        horizontal: ResponsiveHelper.spacing(context, 8),
        vertical: ResponsiveHelper.spacing(context, 8),
      ),
      decoration: BoxDecoration(
        color: Colors.white,
        boxShadow: [
          BoxShadow(
            color: Colors.black.withOpacity(0.1),
            blurRadius: 4,
            offset: const Offset(0, -2),
          ),
        ],
      ),
      child: SafeArea(
          child: Row(
            children: [
              // Emoji button
              Material(
                color: Colors.transparent,
                child: InkWell(
                  onTap: () => _showEmojiPicker(context),
                  borderRadius: BorderRadius.circular(30),
                  child: Container(
                    width: 40,
                    height: 40,
                    decoration: BoxDecoration(
                      color: Colors.grey[100],
                      shape: BoxShape.circle,
                    ),
                    child: Icon(
                      Icons.emoji_emotions_outlined,
                      color: const Color(0xFF8B4513),
                      size: 20,
                    ),
                  ),
                ),
              ),
              
              const SizedBox(width: 8),
              
              // Attachment button
              Material(
                color: Colors.transparent,
                child: InkWell(
                  onTap: () => _showAttachmentOptions(context),
                  borderRadius: BorderRadius.circular(30),
                  child: Container(
                    width: 40,
                    height: 40,
                    decoration: BoxDecoration(
                      color: Colors.grey[100],
                      shape: BoxShape.circle,
                    ),
                    child: Icon(
                      Icons.attach_file,
                      color: const Color(0xFF8B4513),
                      size: 20,
                    ),
                  ),
                ),
              ),
              
              const SizedBox(width: 8),
              
              // Text input
            Expanded(
              child: Container(
                decoration: BoxDecoration(
                  color: Colors.grey[50],
                  borderRadius: BorderRadius.circular(ResponsiveHelper.borderRadius(context, mobile: 24)),
                  border: Border.all(
                    color: const Color(0xFF8B4513).withOpacity(0.2),
                    width: 1,
                  ),
                ),
                child: TextField(
                  controller: messageController,
                  maxLines: null,
                  textInputAction: TextInputAction.send,
                  onSubmitted: (_) => _sendMessage(),
                  style: ResponsiveHelper.textStyle(
                    context,
                    fontSize: ResponsiveHelper.fontSize(context, mobile: 14, tablet: 15, desktop: 16),
                    color: const Color(0xFF5F4628),
                  ),
                  decoration: InputDecoration(
                    hintText: 'Type a message...',
                    hintStyle: ResponsiveHelper.textStyle(
                      context,
                      fontSize: ResponsiveHelper.fontSize(context, mobile: 14, tablet: 15, desktop: 16),
                      color: Colors.grey[500],
                    ),
                    border: InputBorder.none,
                    contentPadding: EdgeInsets.symmetric(
                      horizontal: ResponsiveHelper.spacing(context, 16),
                      vertical: ResponsiveHelper.spacing(context, 10),
                    ),
                  ),
                ),
              ),
            ),
            
            const SizedBox(width: 8),
            
            // Send button
            Obx(() {
              return Material(
                color: Colors.transparent,
                child: InkWell(
                  onTap: controller.isSending.value ? null : _sendMessage,
                  borderRadius: BorderRadius.circular(30),
                  child: Container(
                    width: 40,
                    height: 40,
                    decoration: BoxDecoration(
                      gradient: LinearGradient(
                        begin: Alignment.topLeft,
                        end: Alignment.bottomRight,
                        colors: [
                          const Color(0xFF8B4513),
                          const Color(0xFF5F4628),
                        ],
                      ),
                      shape: BoxShape.circle,
                      boxShadow: [
                        BoxShadow(
                          color: const Color(0xFF8B4513).withOpacity(0.3),
                          blurRadius: 8,
                          offset: const Offset(0, 4),
                        ),
                      ],
                    ),
                    child: controller.isSending.value
                        ? Center(
                            child: SizedBox(
                              width: 20,
                              height: 20,
                              child: CircularProgressIndicator(
                                strokeWidth: 2,
                                valueColor: AlwaysStoppedAnimation<Color>(Colors.white),
                              ),
                            ),
                          )
                        : Icon(
                            Icons.send,
                            color: Colors.white,
                            size: 20,
                          ),
                  ),
                ),
              );
            }),
          ],
        ),
      ),
    );
  }

  void _showAttachmentOptions(BuildContext context) {
    showModalBottomSheet(
      context: context,
      builder: (context) => Container(
        padding: const EdgeInsets.all(16),
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            ListTile(
              leading: Icon(Icons.photo, color: const Color(0xFF8B4513)),
              title: Text(
                'Photo',
                style: ResponsiveHelper.textStyle(
                  context,
                  fontSize: ResponsiveHelper.fontSize(context, mobile: 16),
                  color: const Color(0xFF5F4628),
                ),
              ),
              onTap: () {
                Get.back();
                _pickImage(ImageSource.gallery);
              },
            ),
            ListTile(
              leading: Icon(Icons.camera_alt, color: const Color(0xFF8B4513)),
              title: Text(
                'Camera',
                style: ResponsiveHelper.textStyle(
                  context,
                  fontSize: ResponsiveHelper.fontSize(context, mobile: 16),
                  color: const Color(0xFF5F4628),
                ),
              ),
              onTap: () {
                Get.back();
                _pickImage(ImageSource.camera);
              },
            ),
          ],
        ),
      ),
    );
  }

  Future<void> _pickImage(ImageSource source) async {
    try {
      final image = await _picker.pickImage(source: source);
      if (image != null) {
        await controller.sendMessage(
          groupId: widget.groupId,
          text: '',
          file: File(image.path),
          messageType: 'image',
        );
      }
    } catch (e) {
      Get.snackbar('Error', 'Failed to pick image: $e');
    }
  }

  Future<void> _sendMessage() async {
    final text = messageController.text.trim();
    if (text.isEmpty) return;
    
    print('📤 Sending message to group ${widget.groupId}: "$text"');
    print('📤 Message length: ${text.length}');
    print('📤 Message type check: isNumeric=${int.tryParse(text) != null}');
    
    // Clear input immediately for better UX
    messageController.clear();
    
    final success = await controller.sendMessage(
      groupId: widget.groupId,
      text: text,
    );
    
    if (success) {
      print('✅ Message sent successfully');
      print('📥 Waiting for message to appear in UI...');
      // Scroll to bottom after sending
      Future.delayed(const Duration(milliseconds: 200), () {
        if (scrollController.hasClients) {
          scrollController.animateTo(
            scrollController.position.maxScrollExtent,
            duration: const Duration(milliseconds: 300),
            curve: Curves.easeOut,
          );
        }
      });
    } else {
      print('❌ Failed to send message');
      // Restore text if sending failed
      messageController.text = text;
    }
  }

  String _formatTime(String? dateStr) {
    if (dateStr == null) return '';
    try {
      final date = DateTime.parse(dateStr);
      final now = DateTime.now();
      final difference = now.difference(date);
      
      if (difference.inDays > 0) {
        return '${date.day}/${date.month} ${date.hour}:${date.minute.toString().padLeft(2, '0')}';
      } else {
        return '${date.hour}:${date.minute.toString().padLeft(2, '0')}';
      }
    } catch (e) {
      return '';
    }
  }

  void _showEmojiPicker(BuildContext context) {
    showModalBottomSheet(
      context: context,
      backgroundColor: Colors.transparent,
      builder: (context) => Container(
        height: ResponsiveHelper.screenHeight(context) * 0.5,
        decoration: BoxDecoration(
          color: Colors.white,
          borderRadius: BorderRadius.only(
            topLeft: Radius.circular(ResponsiveHelper.borderRadius(context, mobile: 24)),
            topRight: Radius.circular(ResponsiveHelper.borderRadius(context, mobile: 24)),
          ),
        ),
        child: Column(
          children: [
            // Header
            Container(
              padding: EdgeInsets.all(ResponsiveHelper.spacing(context, 16)),
              decoration: BoxDecoration(
                border: Border(
                  bottom: BorderSide(
                    color: Colors.grey.withOpacity(0.2),
                    width: 1,
                  ),
                ),
              ),
              child: Row(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                children: [
                  Text(
                    'Select Emoji',
                    style: ResponsiveHelper.textStyle(
                      context,
                      fontSize: ResponsiveHelper.fontSize(context, mobile: 18, tablet: 20, desktop: 22),
                      fontWeight: FontWeight.bold,
                      color: const Color(0xFF8B4513),
                    ),
                  ),
                  IconButton(
                    icon: const Icon(Icons.close, color: Color(0xFF8B4513)),
                    onPressed: () => Get.back(),
                  ),
                ],
              ),
            ),
            // Emoji Grid
            Expanded(
              child: Obx(() {
                if (isLoadingEmojis.value) {
                  return const Center(
                    child: CircularProgressIndicator(
                      color: Color(0xFF8B4513),
                    ),
                  );
                }
                
                if (availableEmojis.isEmpty) {
                  return Center(
                    child: Text(
                      'No emojis available',
                      style: ResponsiveHelper.textStyle(
                        context,
                        fontSize: ResponsiveHelper.fontSize(context, mobile: 14),
                        color: Colors.grey[600],
                      ),
                    ),
                  );
                }
                
                return GridView.builder(
                  padding: EdgeInsets.all(ResponsiveHelper.spacing(context, 12)),
                  gridDelegate: SliverGridDelegateWithFixedCrossAxisCount(
                    crossAxisCount: ResponsiveHelper.isMobile(context) ? 6 : ResponsiveHelper.isTablet(context) ? 8 : 10,
                    crossAxisSpacing: ResponsiveHelper.spacing(context, 10),
                    mainAxisSpacing: ResponsiveHelper.spacing(context, 10),
                    childAspectRatio: 1.0,
                  ),
                  itemCount: availableEmojis.length,
                  itemBuilder: (context, index) {
                    final emoji = availableEmojis[index];
                    final emojiChar = emoji['emoji_char'] as String? ?? '';
                    final emojiCode = emoji['code'] as String? ?? '';
                    final emojiName = emoji['name'] as String? ?? '';
                    
                    return Material(
                      color: Colors.transparent,
                      child: InkWell(
                        onTap: () async {
                          // WhatsApp/Instagram style: Send emoji directly when selected
                          // Priority: emoji_char > code > id > image_url filename
                          String textToSend;
                          if (emojiChar.isNotEmpty) {
                            textToSend = emojiChar;
                          } else if (emojiCode.isNotEmpty) {
                            textToSend = emojiCode;
                          } else {
                            // Use emoji ID as fallback
                            final emojiId = emoji['id']?.toString() ?? '';
                            if (emojiId.isNotEmpty) {
                              textToSend = emojiId;
                            } else {
                              // Last resort: use image URL filename
                              final imageUrl = emoji['image_url'] as String? ?? '';
                              if (imageUrl.isNotEmpty && imageUrl.contains('/')) {
                                textToSend = imageUrl.split('/').last;
                              } else {
                                textToSend = emojiName; // Use name as last fallback
                              }
                            }
                          }
                          
                          print('📤 Sending emoji directly: char="$emojiChar", code="$emojiCode", id=${emoji['id']}, textToSend="$textToSend"');
                          
                          // Close emoji picker
                          Get.back();
                          
                          // Send message directly
                          final success = await controller.sendMessage(
                            groupId: widget.groupId,
                            text: textToSend,
                          );
                          
                          if (success) {
                            print('✅ Emoji message sent successfully');
                            // Scroll to bottom after sending
                            Future.delayed(const Duration(milliseconds: 200), () {
                              if (scrollController.hasClients) {
                                scrollController.animateTo(
                                  scrollController.position.maxScrollExtent,
                                  duration: const Duration(milliseconds: 300),
                                  curve: Curves.easeOut,
                                );
                              }
                            });
                          } else {
                            print('❌ Failed to send emoji message');
                            Get.snackbar(
                              'Error',
                              'Failed to send emoji',
                              backgroundColor: Colors.red,
                              colorText: Colors.white,
                              duration: const Duration(seconds: 2),
                            );
                          }
                        },
                        borderRadius: BorderRadius.circular(ResponsiveHelper.borderRadius(context, mobile: 16)),
                        splashColor: const Color(0xFF8B4513).withOpacity(0.1),
                        highlightColor: const Color(0xFF8B4513).withOpacity(0.05),
                        child: Container(
                          decoration: BoxDecoration(
                            color: Colors.white,
                            borderRadius: BorderRadius.circular(ResponsiveHelper.borderRadius(context, mobile: 16)),
                            border: Border.all(
                              color: Colors.grey.withOpacity(0.15),
                              width: 1.5,
                            ),
                            boxShadow: [
                              BoxShadow(
                                color: Colors.black.withOpacity(0.03),
                                blurRadius: 4,
                                offset: const Offset(0, 2),
                              ),
                            ],
                          ),
                          child: Center(
                            child: Padding(
                              padding: EdgeInsets.all(ResponsiveHelper.spacing(context, 8)),
                              child: HomeScreen.buildEmojiDisplay(
                                context,
                                emoji,
                                size: ResponsiveHelper.isMobile(context) ? 36 : ResponsiveHelper.isTablet(context) ? 40 : 44,
                              ),
                            ),
                          ),
                        ),
                      ),
                    );
                  },
                );
              }),
            ),
          ],
        ),
      ),
    );
  }

  /// Build message text with emoji support
  Widget _buildMessageText(BuildContext context, String messageText) {
    final trimmed = messageText.trim();
    
    if (trimmed.isEmpty) {
      return const SizedBox.shrink();
    }
    
    print('🔍 _buildMessageText: messageText="$messageText", trimmed="$trimmed"');
    
    // Check if message contains emoji characters
    final emojiPattern = RegExp(r'[\u{1F300}-\u{1F9FF}]|[\u{2600}-\u{26FF}]|[\u{2700}-\u{27BF}]', unicode: true);
    final hasEmojiChar = emojiPattern.hasMatch(messageText);
    
    // Check if entire message is just an emoji code/ID (for emoji-only messages)
    Map<String, dynamic>? emojiData = _findEmojiByText(trimmed);
    final isOnlyEmoji = emojiData != null && trimmed.length <= 10;
    
    // If message is ONLY an emoji (no other text), show large emoji
    if (isOnlyEmoji && !hasEmojiChar && messageText.trim() == trimmed) {
      print('✅ Message is ONLY emoji, displaying as image: ${emojiData['name']}');
      return SizedBox(
        width: 48,
        height: 48,
        child: HomeScreen.buildEmojiDisplay(
          context,
          emojiData,
          size: 48,
        ),
      );
    }
    
    // Otherwise, show text with emojis inline
    if (hasEmojiChar) {
      // Message has emoji characters - parse and display with emoji images
      return RichText(
        text: TextSpan(
          style: ResponsiveHelper.textStyle(
            context,
            fontSize: ResponsiveHelper.fontSize(context, mobile: 14, tablet: 15, desktop: 16),
            color: Colors.black87,
          ),
          children: _parseMessageWithEmojis(context, messageText),
        ),
      );
    }
    
    // Regular text message - always show text
    print('📝 Displaying as regular text: "$messageText"');
    return Text(
      messageText,
      style: ResponsiveHelper.textStyle(
        context,
        fontSize: ResponsiveHelper.fontSize(context, mobile: 14, tablet: 15, desktop: 16),
        color: Colors.black87,
      ),
    );
  }
  
  /// Find emoji by text (can be character, code, image URL, or ID)
  Map<String, dynamic>? _findEmojiByText(String text) {
    if (text.isEmpty) return null;
    
    final trimmedText = text.trim();
    print('🔍 _findEmojiByText: searching for "$trimmedText" in ${availableEmojis.length} emojis');
    
    for (var emoji in availableEmojis) {
      final emojiChar = emoji['emoji_char'] as String? ?? '';
      final emojiCode = emoji['code'] as String? ?? '';
      final emojiImageUrl = emoji['image_url'] as String? ?? '';
      final emojiId = emoji['id']?.toString() ?? '';
      final emojiName = emoji['name'] as String? ?? '';
      
      // Strategy 1: Match by ID (most reliable for numeric IDs)
      if (emojiId.isNotEmpty && emojiId == trimmedText) {
        print('✅ Match by ID: $emojiId -> ${emojiName}');
        return emoji;
      }
      
      // Strategy 2: Match by emoji_char
      if (emojiChar.isNotEmpty && emojiChar.trim() == trimmedText) {
        print('✅ Match by emoji_char: "$emojiChar" -> ${emojiName}');
        return emoji;
      }
      
      // Strategy 3: Match by code
      if (emojiCode.isNotEmpty && emojiCode.trim() == trimmedText) {
        print('✅ Match by code: "$emojiCode" -> ${emojiName}');
        return emoji;
      }
      
      // Strategy 4: Match by image_url filename
      if (emojiImageUrl.isNotEmpty) {
        String? textFilename;
        String? urlFilename;
        
        if (trimmedText.contains('/')) {
          textFilename = trimmedText.split('/').last.replaceAll('%20', ' ').toLowerCase();
        } else {
          textFilename = trimmedText.toLowerCase();
        }
        
        if (emojiImageUrl.contains('/')) {
          urlFilename = emojiImageUrl.split('/').last.replaceAll('%20', ' ').toLowerCase();
        } else {
          urlFilename = emojiImageUrl.toLowerCase();
        }
        
        if (textFilename == urlFilename || 
            emojiImageUrl.contains(trimmedText) || 
            trimmedText.contains(emojiImageUrl)) {
          print('✅ Match by image_url: "$textFilename" -> ${emojiName}');
          return emoji;
        }
      }
      
      // Strategy 5: Match by name (partial match for filenames)
      if (emojiName.isNotEmpty) {
        final nameLower = emojiName.toLowerCase();
        final textLower = trimmedText.toLowerCase();
        // Check if text is part of emoji name (e.g., "Joy_Pineapple" matches "Joy_Pineapple (1).png")
        if (nameLower.contains(textLower) || textLower.contains(nameLower.replaceAll(' ', '_'))) {
          print('✅ Match by name: "$emojiName" contains "$trimmedText"');
          return emoji;
        }
      }
    }
    
    print('❌ No emoji match found for "$trimmedText"');
    return null;
  }

  List<InlineSpan> _parseMessageWithEmojis(BuildContext context, String text) {
    final List<InlineSpan> spans = [];
    final emojiPattern = RegExp(r'[\u{1F300}-\u{1F9FF}]|[\u{2600}-\u{26FF}]|[\u{2700}-\u{27BF}]', unicode: true);
    
    // Also check for emoji codes (words with underscores like "joy_01", "kindness_peach_01")
    final emojiCodePattern = RegExp(r'\b(joy|peace|love|patience|kindness|goodness|faithfulness|gentleness|meekness|self|control)[_\w]*\b', caseSensitive: false);
    
    int lastIndex = 0;
    
    // Find all potential emoji matches (both Unicode and codes)
    final allMatches = <_EmojiMatch>[];
    
    // Unicode emoji matches
    for (final match in emojiPattern.allMatches(text)) {
      allMatches.add(_EmojiMatch(match.start, match.end, match.group(0)!, isUnicode: true));
    }
    
    // Emoji code matches
    for (final match in emojiCodePattern.allMatches(text)) {
      allMatches.add(_EmojiMatch(match.start, match.end, match.group(0)!, isUnicode: false));
    }
    
    // Sort by position
    allMatches.sort((a, b) => a.start.compareTo(b.start));
    
    // Remove overlapping matches (keep first)
    final nonOverlappingMatches = <_EmojiMatch>[];
    for (var match in allMatches) {
      if (nonOverlappingMatches.isEmpty || match.start >= nonOverlappingMatches.last.end) {
        nonOverlappingMatches.add(match);
      }
    }
    
    // Build spans
    for (final match in nonOverlappingMatches) {
      // Add text before emoji
      if (match.start > lastIndex) {
        spans.add(TextSpan(
          text: text.substring(lastIndex, match.start),
        ));
      }
      
      // Try to find emoji in available emojis
      Map<String, dynamic>? emojiData;
      
      if (match.isUnicode) {
        // Unicode emoji - match by emoji_char
        for (var emoji in availableEmojis) {
          if (emoji['emoji_char'] == match.text) {
            emojiData = emoji;
            break;
          }
        }
      } else {
        // Emoji code - match by code or name
        emojiData = _findEmojiByText(match.text);
      }
      
      if (emojiData != null) {
        // Add emoji as widget span (will be rendered as image)
        spans.add(WidgetSpan(
          child: SizedBox(
            width: 20,
            height: 20,
            child: HomeScreen.buildEmojiDisplay(
              context,
              emojiData,
              size: 20,
            ),
          ),
        ));
      } else {
        // Fallback to text
        spans.add(TextSpan(text: match.text));
      }
      
      lastIndex = match.end;
    }
    
    // Add remaining text
    if (lastIndex < text.length) {
      spans.add(TextSpan(text: text.substring(lastIndex)));
    }
    
    return spans;
  }
}

/// Helper class for emoji matches
class _EmojiMatch {
  final int start;
  final int end;
  final String text;
  final bool isUnicode;
  
  _EmojiMatch(this.start, this.end, this.text, {this.isUnicode = true});
}

