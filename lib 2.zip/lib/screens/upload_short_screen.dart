import 'dart:io';
import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:image_picker/image_picker.dart';
import 'package:video_player/video_player.dart';
import 'package:video_thumbnail/video_thumbnail.dart';
import 'package:fruitsofspirit/controllers/shorts_controller.dart';
import 'package:fruitsofspirit/widgets/standard_app_bar.dart';
import 'package:fruitsofspirit/utils/app_theme.dart';
import 'package:fruitsofspirit/utils/responsive_helper.dart';

/// Upload Short Screen
class UploadShortScreen extends StatefulWidget {
  const UploadShortScreen({Key? key}) : super(key: key);

  @override
  State<UploadShortScreen> createState() => _UploadShortScreenState();
}

class _UploadShortScreenState extends State<UploadShortScreen> {
  final controller = Get.find<ShortsController>();
  final titleController = TextEditingController();
  final descriptionController = TextEditingController();
  File? selectedVideo;
  File? thumbnailFile;
  VideoPlayerController? _previewController;
  int _duration = 0;

  @override
  void dispose() {
    titleController.dispose();
    descriptionController.dispose();
    _previewController?.dispose();
    super.dispose();
  }

  Future<void> _pickVideo() async {
    final picker = ImagePicker();
    final picked = await picker.pickVideo(source: ImageSource.gallery, maxDuration: const Duration(minutes: 3));
    if (picked == null) return;

    final file = File(picked.path);
    setState(() => selectedVideo = file);

    _previewController?.dispose();
    _previewController = VideoPlayerController.file(file);
    await _previewController!.initialize();
    _duration = _previewController!.value.duration.inSeconds;
    setState(() {});

    final thumbPath = await VideoThumbnail.thumbnailFile(
      video: file.path,
      imageFormat: ImageFormat.JPEG,
      maxWidth: 512,
      quality: 85,
    );
    if (thumbPath != null) {
      setState(() => thumbnailFile = File(thumbPath));
    }
  }

  Future<void> _upload() async {
    if (selectedVideo == null) {
      _snack('Please select a video', error: true);
      return;
    }
    final ok = await controller.uploadShort(
      videoFile: selectedVideo!,
      thumbnailFile: thumbnailFile,
      title: titleController.text.trim(),
      description: descriptionController.text.trim(),
      duration: _duration,
    );
    if (ok && mounted) {
      _snack(controller.message.value);
      Get.back();
    } else if (mounted) {
      _snack(controller.message.value, error: true);
    }
  }

  void _snack(String msg, {bool error = false}) {
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(
        content: Text(msg),
        backgroundColor: error ? AppTheme.errorColor : AppTheme.successColor,
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: const StandardAppBar(showBackButton: true),
      body: SingleChildScrollView(
        padding: ResponsiveHelper.padding(context, all: 16),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.stretch,
          children: [
            Text('Upload Short', style: AppTheme.heading2(context)),
            const SizedBox(height: 16),
            GestureDetector(
              onTap: _pickVideo,
              child: Container(
                height: 200,
                decoration: BoxDecoration(
                  color: Colors.grey.shade200,
                  borderRadius: BorderRadius.circular(AppTheme.radiusMD),
                ),
                child: _previewController != null && _previewController!.value.isInitialized
                    ? ClipRRect(
                        borderRadius: BorderRadius.circular(AppTheme.radiusMD),
                        child: AspectRatio(
                          aspectRatio: _previewController!.value.aspectRatio,
                          child: VideoPlayer(_previewController!),
                        ),
                      )
                    : const Column(
                        mainAxisAlignment: MainAxisAlignment.center,
                        children: [
                          Icon(Icons.video_library, size: 48, color: Colors.grey),
                          SizedBox(height: 8),
                          Text('Tap to select video'),
                        ],
                      ),
              ),
            ),
            const SizedBox(height: 16),
            TextField(
              controller: titleController,
              decoration: const InputDecoration(labelText: 'Title', border: OutlineInputBorder()),
            ),
            const SizedBox(height: 12),
            TextField(
              controller: descriptionController,
              maxLines: 3,
              decoration: const InputDecoration(labelText: 'Description', border: OutlineInputBorder()),
            ),
            const SizedBox(height: 24),
            Obx(() => ElevatedButton(
              onPressed: controller.isUploading.value ? null : _upload,
              style: ElevatedButton.styleFrom(
                backgroundColor: AppTheme.primaryColor,
                padding: const EdgeInsets.symmetric(vertical: 14),
              ),
              child: controller.isUploading.value
                  ? const SizedBox(height: 20, width: 20, child: CircularProgressIndicator(color: Colors.white, strokeWidth: 2))
                  : const Text('Upload Short', style: TextStyle(color: Colors.white)),
            )),
          ],
        ),
      ),
    );
  }
}
