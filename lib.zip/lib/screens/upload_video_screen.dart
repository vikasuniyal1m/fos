import 'dart:io';
import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:image_picker/image_picker.dart';
import 'package:fruitsofspirit/controllers/videos_controller.dart';
import 'package:fruitsofspirit/utils/responsive_helper.dart';
import 'package:video_player/video_player.dart';
import 'dart:async';

/// Upload Video Screen - Modern User-Friendly Design
class UploadVideoScreen extends StatefulWidget {
  const UploadVideoScreen({Key? key}) : super(key: key);

  @override
  State<UploadVideoScreen> createState() => _UploadVideoScreenState();
}

class _UploadVideoScreenState extends State<UploadVideoScreen> with SingleTickerProviderStateMixin {
  final controller = Get.find<VideosController>();
  final titleController = TextEditingController();
  final descriptionController = TextEditingController();
  final _formKey = GlobalKey<FormState>();
  File? selectedVideo;
  String? selectedFruitTag;
  VideoPlayerController? _previewController;
  String? _videoFileName;
  String? _videoFileSize;
  Duration? _videoDuration;
  bool _isInitializingPreview = false;
  
  AnimationController? _animationController;
  Animation<double>? _fadeAnimation;
  Animation<Offset>? _slideAnimation;

  // Fruit of the Spirit options
  final List<String> _fruitsOfSpirit = [
    'Love',
    'Joy',
    'Peace',
    'Patience',
    'Kindness',
    'Goodness',
    'Faithfulness',
    'Gentleness',
    'Self-Control',
  ];

  @override
  void initState() {
    super.initState();
    _initializeAnimations();
  }
  
  void _initializeAnimations() {
    // Initialize animations
    _animationController = AnimationController(
      vsync: this,
      duration: const Duration(milliseconds: 600),
    );
    
    _fadeAnimation = Tween<double>(begin: 0.0, end: 1.0).animate(
      CurvedAnimation(parent: _animationController!, curve: Curves.easeInOut),
    );
    
    _slideAnimation = Tween<Offset>(
      begin: const Offset(0, 0.1),
      end: Offset.zero,
    ).animate(
      CurvedAnimation(parent: _animationController!, curve: Curves.easeOutCubic),
    );
    
    _animationController!.forward();
  }

  @override
  void dispose() {
    _animationController?.dispose();
    _previewController?.dispose();
    titleController.dispose();
    descriptionController.dispose();
    super.dispose();
  }

  Future<void> _pickVideo() async {
    try {
      final picker = ImagePicker();
      final video = await picker.pickVideo(
        source: ImageSource.gallery,
        maxDuration: const Duration(minutes: 10), // Optional: limit video duration
      );
      
      if (video != null) {
        final file = File(video.path);
        setState(() {
          selectedVideo = file;
          _videoFileName = video.name;
          _isInitializingPreview = true;
        });
        
        // Get file size
        final fileSize = await file.length();
        _videoFileSize = _formatFileSize(fileSize);
        
        // Initialize video preview
        try {
          _previewController?.dispose();
          _previewController = VideoPlayerController.file(file);
          await _previewController!.initialize();
          
          setState(() {
            _videoDuration = _previewController!.value.duration;
            _isInitializingPreview = false;
          });
        } catch (e) {
          print('Error initializing video preview: $e');
          setState(() {
            _isInitializingPreview = false;
          });
        }
      }
    } catch (e) {
      Get.snackbar(
        'Error',
        'Failed to pick video: ${e.toString()}',
        backgroundColor: Colors.red,
        colorText: Colors.white,
      );
    }
  }

  String _formatFileSize(int bytes) {
    if (bytes < 1024) return '$bytes B';
    if (bytes < 1024 * 1024) return '${(bytes / 1024).toStringAsFixed(1)} KB';
    if (bytes < 1024 * 1024 * 1024) return '${(bytes / (1024 * 1024)).toStringAsFixed(1)} MB';
    return '${(bytes / (1024 * 1024 * 1024)).toStringAsFixed(1)} GB';
  }

  String _formatDuration(Duration duration) {
    String twoDigits(int n) => n.toString().padLeft(2, '0');
    final minutes = twoDigits(duration.inMinutes.remainder(60));
    final seconds = twoDigits(duration.inSeconds.remainder(60));
    return '$minutes:$seconds';
  }

  Future<void> _uploadVideo() async {
    if (!_formKey.currentState!.validate()) {
      return;
    }

    if (selectedVideo == null) {
      Get.snackbar(
        'Error',
        'Please select a video',
        backgroundColor: Colors.orange,
        colorText: Colors.white,
        snackPosition: SnackPosition.BOTTOM,
      );
      return;
    }

    final success = await controller.uploadVideo(
      videoFile: selectedVideo!,
      fruitTag: selectedFruitTag,
      title: titleController.text.trim(),
      description: descriptionController.text.trim(),
    );

    if (success) {
      // Clear form
      setState(() {
        titleController.clear();
        descriptionController.clear();
        selectedVideo = null;
        selectedFruitTag = null;
        _videoFileName = null;
        _videoFileSize = null;
        _videoDuration = null;
      });
      
      _previewController?.dispose();
      _previewController = null;
      
      // Show success message
      Get.snackbar(
        'Success',
        controller.message.value,
        backgroundColor: Colors.green,
        colorText: Colors.white,
        snackPosition: SnackPosition.BOTTOM,
        duration: const Duration(seconds: 2),
        icon: const Icon(Icons.check_circle, color: Colors.white),
      );
      
      // Navigate back and refresh
      Get.back();
      Future.delayed(const Duration(milliseconds: 300), () {
        controller.loadVideos(refresh: true, includePending: true);
      });
    } else {
      Get.snackbar(
        'Error',
        controller.message.value,
        backgroundColor: Colors.red,
        colorText: Colors.white,
        snackPosition: SnackPosition.BOTTOM,
        duration: const Duration(seconds: 3),
        icon: const Icon(Icons.error, color: Colors.white),
      );
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.white,
      appBar: PreferredSize(
        preferredSize: Size.fromHeight(
          ResponsiveHelper.appBarHeight(context),
        ),
        child: AppBar(
          backgroundColor: Colors.white,
          elevation: 0,
          leading: Container(
            margin: EdgeInsets.all(ResponsiveHelper.spacing(context, 8)),
            decoration: BoxDecoration(
              color: Colors.grey[100],
              shape: BoxShape.circle,
            ),
            child: IconButton(
              icon: Icon(
                Icons.arrow_back,
                color: const Color(0xFF8B4513),
                size: ResponsiveHelper.iconSize(context, mobile: 24, tablet: 28, desktop: 32),
              ),
              onPressed: () => Get.back(),
            ),
          ),
        title: Row(
          children: [
            Container(
              padding: EdgeInsets.symmetric(
                horizontal: ResponsiveHelper.spacing(context, 12),
                vertical: ResponsiveHelper.spacing(context, 8),
              ),
                    decoration: BoxDecoration(
                      gradient: LinearGradient(
                  colors: [
                    const Color(0xFF8B4513).withOpacity(0.1),
                    const Color(0xFF8B4513).withOpacity(0.05),
                  ],
                      ),
                      borderRadius: BorderRadius.circular(
                  ResponsiveHelper.borderRadius(context, mobile: 20),
                ),
              ),
              child: Row(
                mainAxisSize: MainAxisSize.min,
                            children: [
                              Icon(
                    Icons.video_library_rounded,
                    size: ResponsiveHelper.iconSize(context, mobile: 22),
                    color: const Color(0xFF8B4513),
                  ),
                  SizedBox(width: ResponsiveHelper.spacing(context, 8)),
                              Text(
                    'Upload Video',
                                style: ResponsiveHelper.textStyle(
                                  context,
                      fontSize: ResponsiveHelper.fontSize(context, mobile: 18),
                      fontWeight: FontWeight.bold,
                      color: const Color(0xFF8B4513),
                                ),
                              ),
                            ],
                          ),
                  ),
          ],
        ),
        centerTitle: false,
        bottom: PreferredSize(
          preferredSize: const Size.fromHeight(1),
          child: Container(
            height: 1,
            decoration: BoxDecoration(
              gradient: LinearGradient(
                colors: [
                  Colors.transparent,
                  Colors.grey[300]!,
                  Colors.transparent,
                ],
              ),
            ),
          ),
        ),
        ),
      ),
      body: Obx(() {
        // Ensure animations are initialized
        if (_fadeAnimation == null || _slideAnimation == null) {
          WidgetsBinding.instance.addPostFrameCallback((_) {
            if (mounted) {
              _initializeAnimations();
            }
          });
          return const Center(child: CircularProgressIndicator());
        }
        
        return FadeTransition(
          opacity: _fadeAnimation!,
          child: SlideTransition(
            position: _slideAnimation!,
            child: Form(
              key: _formKey,
              child: Column(
                children: [
                  // Video Selection Card - Takes most of the screen
                  Expanded(
                    flex: 3,
                    child: Container(
                      width: double.infinity,
                      margin: EdgeInsets.all(ResponsiveHelper.spacing(context, 12)),
                      child: _buildVideoSelectionCard(),
                    ),
                  ),
                  
                  // Form Fields - Scrollable
                  Container(
                    constraints: BoxConstraints(
                      maxHeight: ResponsiveHelper.screenHeight(context) * 0.45,
                    ),
                    child: SingleChildScrollView(
                      padding: EdgeInsets.symmetric(
                        horizontal: ResponsiveHelper.spacing(context, 16),
                        vertical: ResponsiveHelper.spacing(context, 12),
                      ),
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.stretch,
                        children: [
                          // Title Input Card
                          _buildInputCard(
                    title: 'Video Title',
                    isRequired: true,
                    child: TextFormField(
              controller: titleController,
                      validator: (value) {
                        if (value == null || value.trim().isEmpty) {
                          return 'Please enter video title';
                        }
                        return null;
                      },
              decoration: InputDecoration(
                        hintText: 'Enter a catchy title for your video',
                        prefixIcon: Icon(
                          Icons.title_rounded,
                          color: const Color(0xFF8B4513).withOpacity(0.6),
                        ),
                border: OutlineInputBorder(
                  borderRadius: BorderRadius.circular(
                    ResponsiveHelper.borderRadius(context, mobile: 16),
                  ),
                          borderSide: BorderSide(color: Colors.grey.withOpacity(0.3)),
                ),
                enabledBorder: OutlineInputBorder(
                  borderRadius: BorderRadius.circular(
                    ResponsiveHelper.borderRadius(context, mobile: 16),
                  ),
                          borderSide: BorderSide(color: Colors.grey.withOpacity(0.3)),
                ),
                focusedBorder: OutlineInputBorder(
                  borderRadius: BorderRadius.circular(
                    ResponsiveHelper.borderRadius(context, mobile: 16),
                  ),
                          borderSide: const BorderSide(color: Color(0xFF8B4513), width: 2),
                ),
                filled: true,
                        fillColor: Colors.grey[50],
                        contentPadding: EdgeInsets.symmetric(
                          horizontal: ResponsiveHelper.spacing(context, 16),
                          vertical: ResponsiveHelper.spacing(context, 16),
                        ),
                      ),
                    ),
                  ),
                  
                  SizedBox(height: ResponsiveHelper.spacing(context, 20)),
                  
                  // Description Input Card
                  _buildInputCard(
                    title: 'Description',
                    isRequired: false,
                    child: TextFormField(
              controller: descriptionController,
              maxLines: 4,
              decoration: InputDecoration(
                        hintText: 'Tell us about your video (optional)',
                        prefixIcon: Padding(
                          padding: EdgeInsets.only(
                            bottom: ResponsiveHelper.spacing(context, 60),
                          ),
                          child: Icon(
                            Icons.description_rounded,
                            color: const Color(0xFF8B4513).withOpacity(0.6),
                          ),
                        ),
                border: OutlineInputBorder(
                  borderRadius: BorderRadius.circular(
                    ResponsiveHelper.borderRadius(context, mobile: 16),
                  ),
                          borderSide: BorderSide(color: Colors.grey.withOpacity(0.3)),
                ),
                enabledBorder: OutlineInputBorder(
                  borderRadius: BorderRadius.circular(
                    ResponsiveHelper.borderRadius(context, mobile: 16),
                  ),
                          borderSide: BorderSide(color: Colors.grey.withOpacity(0.3)),
                ),
                focusedBorder: OutlineInputBorder(
                  borderRadius: BorderRadius.circular(
                    ResponsiveHelper.borderRadius(context, mobile: 16),
                  ),
                          borderSide: const BorderSide(color: Color(0xFF8B4513), width: 2),
                ),
                filled: true,
                        fillColor: Colors.grey[50],
                        contentPadding: EdgeInsets.all(
                          ResponsiveHelper.spacing(context, 16),
                        ),
                      ),
                    ),
                  ),
                  
                  SizedBox(height: ResponsiveHelper.spacing(context, 20)),
                  
                  // Fruit Tag Selection Card
                  _buildInputCard(
                    title: 'Tag with Fruit',
                    isRequired: false,
                    child: DropdownButtonFormField<String>(
              value: selectedFruitTag,
              decoration: InputDecoration(
                        hintText: 'Select a fruit (optional)',
                        prefixIcon: Icon(
                          Icons.local_florist_rounded,
                          color: const Color(0xFF8B4513).withOpacity(0.6),
                        ),
                border: OutlineInputBorder(
                  borderRadius: BorderRadius.circular(
                    ResponsiveHelper.borderRadius(context, mobile: 16),
                  ),
                          borderSide: BorderSide(color: Colors.grey.withOpacity(0.3)),
                ),
                enabledBorder: OutlineInputBorder(
                  borderRadius: BorderRadius.circular(
                    ResponsiveHelper.borderRadius(context, mobile: 16),
                  ),
                          borderSide: BorderSide(color: Colors.grey.withOpacity(0.3)),
                ),
                focusedBorder: OutlineInputBorder(
                  borderRadius: BorderRadius.circular(
                    ResponsiveHelper.borderRadius(context, mobile: 16),
                  ),
                          borderSide: const BorderSide(color: Color(0xFF8B4513), width: 2),
                ),
                filled: true,
                        fillColor: Colors.grey[50],
                        contentPadding: EdgeInsets.symmetric(
                          horizontal: ResponsiveHelper.spacing(context, 16),
                          vertical: ResponsiveHelper.spacing(context, 16),
                        ),
                      ),
                      items: _fruitsOfSpirit.map((fruit) {
                        return DropdownMenuItem(
                        value: fruit,
                          child: Row(
                            children: [
                              Container(
                                width: 8,
                                height: 8,
                                decoration: BoxDecoration(
                                  color: const Color(0xFF8B4513),
                                  shape: BoxShape.circle,
                                ),
                              ),
                              SizedBox(width: ResponsiveHelper.spacing(context, 12)),
                              Text(
                                fruit,
                                style: ResponsiveHelper.textStyle(
                                  context,
                                  fontSize: ResponsiveHelper.fontSize(context, mobile: 15),
                                  color: const Color(0xFF5F4628),
                                ),
                              ),
                            ],
                          ),
                        );
                      }).toList(),
              onChanged: (value) {
                setState(() {
                  selectedFruitTag = value;
                });
              },
            ),
                  ),
                  
                  SizedBox(height: ResponsiveHelper.spacing(context, 32)),
                  
                        // Upload Button
                        _buildUploadButton(),
                        
                        SizedBox(height: ResponsiveHelper.spacing(context, 16)),
                      ],
                    ),
                  ),
                ),
              ],
            ),
          ),
        ),
      );
      }),
    );
  }

  Widget _buildVideoSelectionCard() {
    return Container(
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(
          ResponsiveHelper.borderRadius(context, mobile: 20),
        ),
        boxShadow: [
          BoxShadow(
            color: Colors.black.withOpacity(0.08),
            spreadRadius: 0,
            blurRadius: 20,
            offset: const Offset(0, 4),
          ),
          BoxShadow(
            color: const Color(0xFF8B4513).withOpacity(0.05),
            spreadRadius: 2,
            blurRadius: 10,
            offset: const Offset(0, 2),
          ),
        ],
      ),
      child: Column(
        children: [
          // Header - Compact
          Padding(
            padding: EdgeInsets.all(ResponsiveHelper.spacing(context, 12)),
            child: Row(
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                Icon(
                  Icons.video_library_rounded,
                  size: ResponsiveHelper.iconSize(context, mobile: 20),
                  color: const Color(0xFF8B4513),
                ),
                SizedBox(width: ResponsiveHelper.spacing(context, 8)),
                Text(
                  'Select Video',
                  style: ResponsiveHelper.textStyle(
                    context,
                    fontSize: ResponsiveHelper.fontSize(context, mobile: 16),
                    fontWeight: FontWeight.bold,
                    color: const Color(0xFF5F4628),
                  ),
                ),
              ],
            ),
          ),
          Divider(height: 1, color: Colors.grey[200]),
          
          // Video Selection Area - Full Screen, Centered
          Expanded(
            child: Center(
              child: GestureDetector(
                onTap: _pickVideo,
                child: Container(
                  width: double.infinity,
                  margin: EdgeInsets.all(ResponsiveHelper.spacing(context, 8)),
              decoration: BoxDecoration(
                gradient: selectedVideo != null
                    ? LinearGradient(
                        colors: [
                          const Color(0xFF8B4513).withOpacity(0.1),
                          const Color(0xFF8B4513).withOpacity(0.05),
                        ],
                        begin: Alignment.topLeft,
                        end: Alignment.bottomRight,
                      )
                    : LinearGradient(
                        colors: [
                          Colors.grey[100]!,
                          Colors.grey[50]!,
                        ],
                        begin: Alignment.topLeft,
                        end: Alignment.bottomRight,
                      ),
                borderRadius: BorderRadius.circular(
                  ResponsiveHelper.borderRadius(context, mobile: 16),
                ),
                border: Border.all(
                  color: selectedVideo != null
                      ? const Color(0xFF8B4513).withOpacity(0.3)
                      : Colors.grey[300]!,
                  width: 2,
                ),
              ),
              child: _isInitializingPreview
                  ? Center(
                      child: Column(
                        mainAxisAlignment: MainAxisAlignment.center,
                        children: [
                          CircularProgressIndicator(
                            color: const Color(0xFF8B4513),
                            strokeWidth: 3,
                          ),
                          SizedBox(height: ResponsiveHelper.spacing(context, 12)),
                          Text(
                            'Loading preview...',
                            style: ResponsiveHelper.textStyle(
                              context,
                              fontSize: ResponsiveHelper.fontSize(context, mobile: 14),
                              color: Colors.grey[600],
                            ),
                          ),
                        ],
                      ),
                    )
                  : selectedVideo == null
                      ? Column(
                          mainAxisAlignment: MainAxisAlignment.center,
                          children: [
                            Container(
                              padding: EdgeInsets.all(ResponsiveHelper.spacing(context, 16)),
                              decoration: BoxDecoration(
                                color: Colors.white,
                                shape: BoxShape.circle,
                                boxShadow: [
                                  BoxShadow(
                                    color: Colors.black.withOpacity(0.1),
                                    blurRadius: 10,
                                    offset: const Offset(0, 4),
                                  ),
                                ],
                              ),
                              child: Icon(
                                Icons.video_library_rounded,
                                size: ResponsiveHelper.iconSize(context, mobile: 48),
                                color: const Color(0xFF8B4513),
                              ),
                            ),
                            SizedBox(height: ResponsiveHelper.spacing(context, 16)),
                            Text(
                              'Tap to Select Video',
                              style: ResponsiveHelper.textStyle(
                                context,
                                fontSize: ResponsiveHelper.fontSize(context, mobile: 16),
                                fontWeight: FontWeight.w600,
                                color: const Color(0xFF5F4628),
                              ),
                            ),
                            SizedBox(height: ResponsiveHelper.spacing(context, 4)),
                            Text(
                              'Choose from gallery',
                              style: ResponsiveHelper.textStyle(
                                context,
                                fontSize: ResponsiveHelper.fontSize(context, mobile: 13),
                                color: Colors.grey[600],
                              ),
                            ),
                          ],
                        )
                      : Stack(
                          fit: StackFit.expand,
                          children: [
                            // Video Preview - Full Size
                            ClipRRect(
                              borderRadius: BorderRadius.circular(
                                ResponsiveHelper.borderRadius(context, mobile: 16),
                              ),
                              child: _previewController != null &&
                                      _previewController!.value.isInitialized
                                  ? SizedBox.expand(
                                      child: FittedBox(
                                        fit: BoxFit.cover,
                                        child: SizedBox(
                                          width: _previewController!.value.size.width,
                                          height: _previewController!.value.size.height,
                                          child: VideoPlayer(_previewController!),
                                        ),
                                      ),
                                    )
                                  : Container(
                                      color: Colors.black87,
                                      child: Center(
                                        child: Icon(
                                          Icons.video_library_rounded,
                                          size: ResponsiveHelper.iconSize(context, mobile: 64),
                                          color: Colors.white70,
                                        ),
                                      ),
                                    ),
                            ),
                            
                            // Overlay with video info
                            Positioned(
                              bottom: 0,
                              left: 0,
                              right: 0,
                              child: Container(
                                padding: EdgeInsets.all(ResponsiveHelper.spacing(context, 12)),
                                decoration: BoxDecoration(
                                  gradient: LinearGradient(
                                    begin: Alignment.bottomCenter,
                                    end: Alignment.topCenter,
                                    colors: [
                                      Colors.black.withOpacity(0.8),
                                      Colors.transparent,
                                    ],
                                  ),
                                  borderRadius: BorderRadius.only(
                                    bottomLeft: Radius.circular(
                                      ResponsiveHelper.borderRadius(context, mobile: 16),
                                    ),
                                    bottomRight: Radius.circular(
                                      ResponsiveHelper.borderRadius(context, mobile: 16),
                                    ),
                                  ),
                                ),
                                child: Column(
                                  crossAxisAlignment: CrossAxisAlignment.start,
                                  mainAxisSize: MainAxisSize.min,
                                  children: [
                                    if (_videoFileName != null)
                                      Row(
                                        children: [
                                          Icon(
                                            Icons.video_file_rounded,
                                            size: ResponsiveHelper.iconSize(context, mobile: 16),
                                            color: Colors.white70,
                                          ),
                                          SizedBox(width: ResponsiveHelper.spacing(context, 6)),
                                          Expanded(
                                            child: Text(
                                              _videoFileName!,
                                              style: ResponsiveHelper.textStyle(
                                                context,
                                                fontSize: ResponsiveHelper.fontSize(context, mobile: 12),
                                                color: Colors.white70,
                                              ),
                                              maxLines: 1,
                                              overflow: TextOverflow.ellipsis,
                                            ),
                                          ),
                                        ],
                                      ),
                                    if (_videoFileSize != null || _videoDuration != null)
                                      SizedBox(height: ResponsiveHelper.spacing(context, 4)),
                                    Row(
                                      children: [
                                        if (_videoDuration != null) ...[
                                          Icon(
                                            Icons.timer_rounded,
                                            size: ResponsiveHelper.iconSize(context, mobile: 14),
                                            color: Colors.white70,
                                          ),
                                          SizedBox(width: ResponsiveHelper.spacing(context, 4)),
                                          Text(
                                            _formatDuration(_videoDuration!),
                                            style: ResponsiveHelper.textStyle(
                                              context,
                                              fontSize: ResponsiveHelper.fontSize(context, mobile: 12),
                                              color: Colors.white70,
                                            ),
                                          ),
                                        ],
                                        if (_videoFileSize != null && _videoDuration != null)
                                          Padding(
                                            padding: EdgeInsets.symmetric(
                                              horizontal: ResponsiveHelper.spacing(context, 8),
                                            ),
                                            child: Container(
                                              width: 4,
                                              height: 4,
                                              decoration: BoxDecoration(
                                                color: Colors.white70,
                                                shape: BoxShape.circle,
                                              ),
                                            ),
                                          ),
                                        if (_videoFileSize != null) ...[
                                          Icon(
                                            Icons.storage_rounded,
                                            size: ResponsiveHelper.iconSize(context, mobile: 14),
                                            color: Colors.white70,
                                          ),
                                          SizedBox(width: ResponsiveHelper.spacing(context, 4)),
                                          Text(
                                            _videoFileSize!,
                                            style: ResponsiveHelper.textStyle(
                                              context,
                                              fontSize: ResponsiveHelper.fontSize(context, mobile: 12),
                                              color: Colors.white70,
                                            ),
                                          ),
                                        ],
                                      ],
                                    ),
                                  ],
                                ),
                              ),
                            ),
                            
                            // Change Video Button
                            Positioned(
                              top: ResponsiveHelper.spacing(context, 12),
                              right: ResponsiveHelper.spacing(context, 12),
                              child: GestureDetector(
                                onTap: _pickVideo,
                                child: Container(
                                  padding: EdgeInsets.all(ResponsiveHelper.spacing(context, 8)),
                                  decoration: BoxDecoration(
                                    color: Colors.black.withOpacity(0.6),
                                    shape: BoxShape.circle,
                                  ),
                                  child: Icon(
                                    Icons.edit_rounded,
                                    size: ResponsiveHelper.iconSize(context, mobile: 20),
                                    color: Colors.white,
                                  ),
                                ),
                              ),
                            ),
                          ],
                        ),
                ),
              ),
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildInputCard({
    required String title,
    required bool isRequired,
    required Widget child,
  }) {
    return Container(
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(
          ResponsiveHelper.borderRadius(context, mobile: 20),
        ),
        boxShadow: [
          BoxShadow(
            color: Colors.black.withOpacity(0.08),
            spreadRadius: 0,
            blurRadius: 20,
            offset: const Offset(0, 4),
          ),
          BoxShadow(
            color: const Color(0xFF8B4513).withOpacity(0.05),
            spreadRadius: 2,
            blurRadius: 10,
            offset: const Offset(0, 2),
          ),
        ],
      ),
      child: Padding(
        padding: EdgeInsets.all(ResponsiveHelper.spacing(context, 16)),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Row(
              children: [
                Text(
                  title,
                  style: ResponsiveHelper.textStyle(
                    context,
                    fontSize: ResponsiveHelper.fontSize(context, mobile: 16),
                    fontWeight: FontWeight.bold,
                    color: const Color(0xFF5F4628),
                  ),
                ),
                if (isRequired) ...[
                  SizedBox(width: ResponsiveHelper.spacing(context, 4)),
                  Text(
                    '*',
                    style: ResponsiveHelper.textStyle(
                      context,
                      fontSize: ResponsiveHelper.fontSize(context, mobile: 16),
                      fontWeight: FontWeight.bold,
                      color: Colors.red,
                    ),
                  ),
                ],
              ],
            ),
            SizedBox(height: ResponsiveHelper.spacing(context, 12)),
            child,
          ],
        ),
      ),
    );
  }

  Widget _buildUploadButton() {
    final isLoading = controller.isLoading.value;
    final canUpload = selectedVideo != null && !isLoading;
    
    return Container(
      width: double.infinity,
      height: ResponsiveHelper.buttonHeight(context, mobile: 56),
      decoration: BoxDecoration(
        borderRadius: BorderRadius.circular(
          ResponsiveHelper.borderRadius(context, mobile: 16),
        ),
        boxShadow: canUpload
            ? [
                BoxShadow(
                  color: const Color(0xFF8B4513).withOpacity(0.3),
                  blurRadius: 12,
                  offset: const Offset(0, 6),
                ),
              ]
            : null,
      ),
      child: ElevatedButton(
        onPressed: canUpload ? _uploadVideo : null,
                style: ElevatedButton.styleFrom(
          backgroundColor: canUpload
              ? const Color(0xFF8B4513)
              : Colors.grey[300],
          foregroundColor: Colors.white,
          elevation: canUpload ? 4 : 0,
                  shadowColor: const Color(0xFF8B4513).withOpacity(0.4),
                  shape: RoundedRectangleBorder(
                    borderRadius: BorderRadius.circular(
                      ResponsiveHelper.borderRadius(context, mobile: 16),
                    ),
                  ),
                ),
        child: isLoading
            ? Row(
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  SizedBox(
                    width: ResponsiveHelper.iconSize(context, mobile: 20),
                    height: ResponsiveHelper.iconSize(context, mobile: 20),
                    child: CircularProgressIndicator(
                      strokeWidth: 2.5,
                      valueColor: AlwaysStoppedAnimation<Color>(Colors.white),
                    ),
                  ),
                  SizedBox(width: ResponsiveHelper.spacing(context, 12)),
                  Text(
                    'Uploading...',
                    style: ResponsiveHelper.textStyle(
                      context,
                      fontSize: ResponsiveHelper.fontSize(context, mobile: 16),
                      fontWeight: FontWeight.bold,
                      color: Colors.white,
                    ),
                  ),
                ],
              )
            : Row(
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  Icon(
                    Icons.cloud_upload_rounded,
                    size: ResponsiveHelper.iconSize(context, mobile: 24),
                  ),
                  SizedBox(width: ResponsiveHelper.spacing(context, 8)),
                  Text(
                        'Upload Video',
                        style: ResponsiveHelper.textStyle(
                          context,
                          fontSize: ResponsiveHelper.fontSize(context, mobile: 16),
                          fontWeight: FontWeight.bold,
                          color: Colors.white,
                        ),
                      ),
                ],
              ),
            ),
    );
  }
}
