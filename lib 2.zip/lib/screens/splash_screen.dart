import 'dart:async';

import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:fruitsofspirit/routes/routes.dart';
import 'package:fruitsofspirit/utils/responsive_helper.dart';
import 'package:fruitsofspirit/services/user_storage.dart';
import 'package:fruitsofspirit/services/banners_prefetch_service.dart';
import 'package:fruitsofspirit/services/data_loading_service.dart';
import 'package:fruitsofspirit/services/intro_service.dart';
import 'package:fruitsofspirit/controllers/banners_controller.dart';
import 'package:fruitsofspirit/config/image_config.dart';

import '../utils/app_theme.dart';

class SplashScreen extends StatefulWidget {
  const SplashScreen({Key? key}) : super(key: key);

  @override
  State<SplashScreen> createState() => _SplashScreenState();
}

class _SplashScreenState extends State<SplashScreen> with SingleTickerProviderStateMixin {
  late AnimationController _animationController;
  late Animation<double> _scaleAnimation;


  @override
  void initState() {
    super.initState();

    _animationController = AnimationController(
      vsync: this,
      duration: const Duration(milliseconds: 1200),
    );

    _scaleAnimation = Tween<double>(begin: 0.5, end: 1.0).animate(
      CurvedAnimation(parent: _animationController, curve: Curves.easeOutBack),
    );
    WidgetsBinding.instance.addPostFrameCallback((_) {
      // Precache splash image (handle errors gracefully)
      precacheImage(const AssetImage('assets/images/fruit_of_spirit.jpg'), context)
          .catchError((error) {
        // Image precaching failed, but app will still work
        debugPrint('Warning: Could not precache splash image: $error');
      });
    });
    _initializeApp();
  }

  Future<void> _initializeApp() async {
    try {
      unawaited(IntroService.incrementLaunchCount());
      final bannerWarm = BannersPrefetchService.warmCache();
      final animation = _animationController.forward();

      final hasSeenOnboarding = await Future.wait([
        animation,
        Future<void>.delayed(const Duration(milliseconds: 600)),
        UserStorage.hasSeenOnboarding().timeout(
          const Duration(seconds: 3),
          onTimeout: () => false,
        ).catchError((_) => false),
      ]).then((results) => results[2] as bool);

      if (!mounted) return;

      if (!hasSeenOnboarding) {
        unawaited(bannerWarm);
        Get.offAllNamed(Routes.ONBOARDING);
        return;
      }

      final isLoggedIn = await UserStorage.isLoggedIn().timeout(
        const Duration(seconds: 3),
        onTimeout: () => false,
      ).catchError((_) => false);

      if (!mounted) return;

      if (isLoggedIn) {
        await bannerWarm.timeout(
          const Duration(seconds: 5),
          onTimeout: () {},
        );
        if (Get.isRegistered<BannersController>()) {
          Get.find<BannersController>().bootstrapBanners();
        }
        unawaited(
          DataLoadingService.loadAllHomeData(preferCache: true).catchError((_) {}),
        );
        Get.offAllNamed(Routes.DASHBOARD);
      } else {
        unawaited(bannerWarm);
        Get.offAllNamed(Routes.LOGIN);
      }
    } catch (e) {
      debugPrint('❌ Error in _initializeApp: $e');
      if (mounted) {
        Get.offAllNamed(Routes.LOGIN);
      }
    }
  }

  @override
  void dispose() {
    _animationController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final w = ResponsiveHelper.safeScreenWidth(context);
    final h = ResponsiveHelper.safeScreenHeight(context);

    // Professional responsive sizing for tablets/iPads
    // Mobile: Keep original behavior (don't touch)
    // Tablets: Use max content width and better proportions
    final isTabletDevice = ResponsiveHelper.isTablet(context);
    final isLargeTabletDevice = ResponsiveHelper.isLargeTablet(context);
    // Get max content width for tablets (840px for small tablets, 1200px for large tablets)
    final double maxContentWidth = isTabletDevice
        ? (isLargeTabletDevice ? 1200.0 : 840.0)
        : w;  // Mobile: use full width

    // Calculate image dimensions based on device type
    double imageWidth;
    double containerMaxWidth;
    double containerMaxHeight;
    double containerPadding;

    if (isTabletDevice) {
      // Tablets/iPads: Use larger sizing for better visibility
      if (isLargeTabletDevice) {
        // Large tablets (iPad Pro 12.9"): Bigger image
        imageWidth = (maxContentWidth * 0.75).clamp(600.0, 800.0);  // 75% of max content width
        containerMaxWidth = maxContentWidth * 0.85; // 85% of max content width
        containerMaxHeight = h * 0.7;  // More height
        containerPadding = 40.0;
      } else {
        // Small tablets (iPad Mini, iPad, iPad Air): Bigger image
        imageWidth = (maxContentWidth * 0.8).clamp(500.0, 700.0);  // 80% of max content width
        containerMaxWidth = maxContentWidth * 0.9; // 90% of max content width
        containerMaxHeight = h * 0.65;  // More height
        containerPadding = 32.0;
      }
    } else {
      // Mobile: Keep original behavior (don't touch)
      imageWidth = w * 0.9;
      containerMaxWidth = w * 0.9;
      containerMaxHeight = h * 0.7;
      containerPadding = ResponsiveHelper.spacing(context, 20);
    }

    return Scaffold(
      body: Container(
        color: Colors.white,
        child: SafeArea(
          top: true,
          bottom: true,
          child: ResponsiveHelper.safeScrollable(
            context: context,
            child: Center(
              child: ResponsiveHelper.constrainedContent(
                context: context,
                maxWidth: isTabletDevice ? maxContentWidth : null,
                child: Column(
                  mainAxisAlignment: MainAxisAlignment.center,
                  mainAxisSize: MainAxisSize.max,
                  children: [
                    ScaleTransition(
                      scale: _scaleAnimation,
                      child: Container(
                        // Professional padding: More for tablets, original for mobile
                        padding: EdgeInsets.all(containerPadding),
                        // Constraints: Use max content width for tablets
                        constraints: BoxConstraints(
                          maxWidth: containerMaxWidth,
                          maxHeight: containerMaxHeight,
                        ),
                        child: Image.asset(
                          'assets/images/fruit_of_spirit.jpg',
                          width: imageWidth > containerMaxWidth - (containerPadding * 2)
                              ? containerMaxWidth - (containerPadding * 2)
                              : imageWidth,
                          fit: BoxFit.contain,
                          errorBuilder: (context, error, stackTrace) {
                            // Fallback to old splash image if new one not found
                            return Image.asset(
                              'assets/images/fruit_of_spirit_splash.jpg',
                              width: imageWidth > containerMaxWidth - (containerPadding * 2)
                                  ? containerMaxWidth - (containerPadding * 2)
                                  : imageWidth,
                              fit: BoxFit.contain,
                            );
                          },
                        ),
                      ),
                    ),
                    // ============================================
                    // SCRIPTURE SECTION - John 15:5, 8 (NIV)
                    // To remove/disable: Comment out the entire section below
                    // ============================================
                SizedBox(
                  height: ResponsiveHelper.spacing(context, 4),
                ),

                    Center(
                      child: Container(
                        padding: EdgeInsets.symmetric(
                          horizontal: ResponsiveHelper.spacing(context, 20),
                          vertical: ResponsiveHelper.spacing(context, 16),
                        ),
                        margin: EdgeInsets.symmetric(
                          horizontal: ResponsiveHelper.spacing(context, 16),
                        ),
                        decoration: BoxDecoration(
                          color: AppTheme.themeColor,
                          borderRadius: BorderRadius.circular(
                              ResponsiveHelper.borderRadius(context, mobile: 12, tablet: 14)
                          ),
                          boxShadow: [
                            BoxShadow(
                              color: Colors.black.withOpacity(0.1),
                              blurRadius: 8,
                              offset: const Offset(0, 2),
                              spreadRadius: 1,
                            ),
                          ],
                        ),
                        child: Column(
                          mainAxisSize: MainAxisSize.min,
                          children: [
                            Text(
                              'John 15:5, 8 (NIV)',
                              style: ResponsiveHelper.textStyle(
                                context,
                                fontSize: ResponsiveHelper.fontSize(
                                  context,
                                  mobile: 14,
                                  tablet: 16,
                                ),
                                fontWeight: FontWeight.bold,
                                color: AppTheme.iconscolor,
                              ),
                            ),
                            SizedBox(height: ResponsiveHelper.spacing(context, 12)),
                            Text(
                              '"I am the vine; you are the branches. If you remain in me and I in you, you will bear much fruit; apart from me you can do nothing."',
                              style: ResponsiveHelper.textStyle(
                                context,
                                fontSize: ResponsiveHelper.fontSize(
                                  context,
                                  mobile: 13,
                                  tablet: 15,
                                ),
                                color: Colors.black87,
                                height: 1.5,
                              ).copyWith(fontStyle: FontStyle.italic),
                              textAlign: TextAlign.center,
                            ),
                            SizedBox(height: ResponsiveHelper.spacing(context, 12)),
                            Text(
                              '"This is to my Father\'s glory, that you bear much fruit, showing yourselves to be my disciples."',
                              style: ResponsiveHelper.textStyle(
                                context,
                                fontSize: ResponsiveHelper.fontSize(
                                  context,
                                  mobile: 13,
                                  tablet: 15,
                                ),
                                color: Colors.black87,
                                height: 1.5,
                              ).copyWith(fontStyle: FontStyle.italic),
                              textAlign: TextAlign.center,
                            ),
                          ],
                        ),
                      ),
                    ),
                    // ============================================
                    // END OF SCRIPTURE SECTION
                    // ============================================

                  ],
                ),
              ),
            ),
          ),
        ),
      ),
    );
  }
}
