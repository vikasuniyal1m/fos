import 'dart:io';
import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:image_picker/image_picker.dart';
import 'package:fruitsofspirit/controllers/blogs_controller.dart';
import 'package:fruitsofspirit/utils/responsive_helper.dart';

/// Create Blog Screen (Bloggers Only)
class CreateBlogScreen extends StatefulWidget {
  const CreateBlogScreen({Key? key}) : super(key: key);

  @override
  State<CreateBlogScreen> createState() => _CreateBlogScreenState();
}

class _CreateBlogScreenState extends State<CreateBlogScreen> {
  final BlogsController controller = Get.find<BlogsController>();
  final TextEditingController titleController = TextEditingController();
  final TextEditingController bodyController = TextEditingController();
  
  File? selectedImage;
  String selectedCategory = 'Spiritual';
  String selectedLanguage = 'en';
  
  @override
  void initState() {
    super.initState();
    // Add listener to update character count
    bodyController.addListener(() {
      setState(() {});
    });
  }

  @override
  void dispose() {
    titleController.dispose();
    bodyController.dispose();
    super.dispose();
  }

  Future<void> _pickImage() async {
    final picker = ImagePicker();
    final image = await picker.pickImage(source: ImageSource.gallery);
    if (image != null) {
      setState(() {
        selectedImage = File(image.path);
      });
    }
    return;
  }

  void _removeImage() {
    setState(() {
      selectedImage = null;
    });
  }

  Future<void> _submitBlog() async {
    // Validation
    if (titleController.text.trim().isEmpty) {
      Get.snackbar(
        'Error',
        'Please enter blog title',
        backgroundColor: Colors.red,
        colorText: Colors.white,
        snackPosition: SnackPosition.BOTTOM,
      );
      return;
    }

    if (bodyController.text.trim().isEmpty) {
      Get.snackbar(
        'Error',
        'Please enter blog content',
        backgroundColor: Colors.red,
        colorText: Colors.white,
        snackPosition: SnackPosition.BOTTOM,
      );
      return;
    }

    if (bodyController.text.trim().length < 50) {
      Get.snackbar(
        'Error',
        'Blog content must be at least 50 characters',
        backgroundColor: Colors.red,
        colorText: Colors.white,
        snackPosition: SnackPosition.BOTTOM,
      );
      return;
    }

    final success = await controller.createBlog(
      title: titleController.text.trim(),
      body: bodyController.text.trim(),
      category: selectedCategory,
      language: selectedLanguage,
      image: selectedImage,
    );

    if (success) {
      Get.back();
      Get.snackbar(
        'Success',
        controller.message.value,
        backgroundColor: Colors.green,
        colorText: Colors.white,
        snackPosition: SnackPosition.BOTTOM,
        duration: const Duration(seconds: 3),
      );
    } else {
      Get.snackbar(
        'Error',
        controller.message.value,
        backgroundColor: Colors.red,
        colorText: Colors.white,
        snackPosition: SnackPosition.BOTTOM,
        duration: const Duration(seconds: 3),
      );
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: const Color(0xFFFAF6EC),
      appBar: PreferredSize(
        preferredSize: Size.fromHeight(
          ResponsiveHelper.appBarHeight(context),
        ),
        child: AppBar(
          backgroundColor: const Color(0xFF5F4628),
          elevation: 0,
          leading: IconButton(
            icon: Icon(
              Icons.arrow_back_rounded,
              color: Colors.white,
              size: ResponsiveHelper.iconSize(context, mobile: 24, tablet: 28, desktop: 32),
            ),
            onPressed: () => Get.back(),
          ),
          title: Text(
            'Create New Blog',
            style: ResponsiveHelper.textStyle(
              context,
              fontSize: ResponsiveHelper.fontSize(context, mobile: 20, tablet: 22, desktop: 24),
              fontWeight: FontWeight.bold,
              color: Colors.white,
            ),
          ),
          centerTitle: true,
        ),
      ),
      body: Obx(() {
        if (controller.userRole.value != 'Blogger') {
          return Center(
            child: Padding(
              padding: ResponsiveHelper.padding(context, all: 32),
              child: Column(
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  Container(
                    padding: ResponsiveHelper.padding(context, all: 24),
                    decoration: BoxDecoration(
                      color: Colors.grey[200],
                      shape: BoxShape.circle,
                    ),
                    child: Icon(
                      Icons.lock_outline_rounded,
                      size: ResponsiveHelper.iconSize(context, mobile: 64, tablet: 72, desktop: 80),
                      color: Colors.grey[600],
                    ),
                  ),
                  SizedBox(height: ResponsiveHelper.spacing(context, 24)),
                  Text(
                    'Blogger Access Required',
                    style: ResponsiveHelper.textStyle(
                      context,
                      fontSize: ResponsiveHelper.fontSize(context, mobile: 22, tablet: 24, desktop: 26),
                      fontWeight: FontWeight.bold,
                      color: const Color(0xFF5F4628),
                    ),
                  ),
                  SizedBox(height: ResponsiveHelper.spacing(context, 12)),
                  Text(
                    'Only approved bloggers can create and publish blog posts.',
                    textAlign: TextAlign.center,
                    style: ResponsiveHelper.textStyle(
                      context,
                      fontSize: ResponsiveHelper.fontSize(context, mobile: 16, tablet: 17, desktop: 18),
                      color: Colors.grey[700],
                    ),
                  ),
                ],
              ),
            ),
          );
        }

        return SingleChildScrollView(
          padding: ResponsiveHelper.padding(context, all: 20),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              // Image Selection Section
              Text(
                'Blog Image',
                style: ResponsiveHelper.textStyle(
                  context,
                  fontSize: ResponsiveHelper.fontSize(context, mobile: 18, tablet: 19, desktop: 20),
                  fontWeight: FontWeight.bold,
                  color: const Color(0xFF5F4628),
                ),
              ),
              SizedBox(height: ResponsiveHelper.spacing(context, 8)),
              Text(
                'Add a cover image for your blog (Optional)',
                style: ResponsiveHelper.textStyle(
                  context,
                  fontSize: ResponsiveHelper.fontSize(context, mobile: 14, tablet: 15, desktop: 16),
                  color: Colors.grey[600],
                ),
              ),
              SizedBox(height: ResponsiveHelper.spacing(context, 12)),
              GestureDetector(
                onTap: _pickImage,
                child: Container(
                  height: ResponsiveHelper.imageHeight(context, mobile: 220, tablet: 250, desktop: 280),
                  width: double.infinity,
                  decoration: BoxDecoration(
                    color: Colors.white,
                    borderRadius: BorderRadius.circular(ResponsiveHelper.borderRadius(context, mobile: 16)),
                    border: Border.all(
                      color: const Color(0xFF5F4628).withOpacity(0.2),
                      width: 2,
                    ),
                    boxShadow: [
                      BoxShadow(
                        color: Colors.black.withOpacity(0.05),
                        blurRadius: 10,
                        offset: const Offset(0, 4),
                      ),
                    ],
                  ),
                  child: selectedImage == null
                      ? Column(
                          mainAxisAlignment: MainAxisAlignment.center,
                          children: [
                            Icon(
                              Icons.add_photo_alternate_rounded,
                              size: ResponsiveHelper.iconSize(context, mobile: 56, tablet: 64, desktop: 72),
                              color: const Color(0xFF9F9467),
                            ),
                            SizedBox(height: ResponsiveHelper.spacing(context, 12)),
                            Text(
                              'Tap to select image',
                              style: ResponsiveHelper.textStyle(
                                context,
                                fontSize: ResponsiveHelper.fontSize(context, mobile: 16, tablet: 17, desktop: 18),
                                color: const Color(0xFF5F4628),
                                fontWeight: FontWeight.w500,
                              ),
                            ),
                            SizedBox(height: ResponsiveHelper.spacing(context, 4)),
                            Text(
                              'JPG, PNG, GIF (Max 5MB)',
                              style: ResponsiveHelper.textStyle(
                                context,
                                fontSize: ResponsiveHelper.fontSize(context, mobile: 12, tablet: 13, desktop: 14),
                                color: Colors.grey[600],
                              ),
                            ),
                          ],
                        )
                      : Stack(
                          children: [
                            ClipRRect(
                              borderRadius: BorderRadius.circular(ResponsiveHelper.borderRadius(context, mobile: 16)),
                              child: Image.file(
                                selectedImage!,
                                fit: BoxFit.cover,
                                width: double.infinity,
                                height: double.infinity,
                              ),
                            ),
                            Positioned(
                              top: ResponsiveHelper.spacing(context, 8),
                              right: ResponsiveHelper.spacing(context, 8),
                              child: Container(
                                decoration: BoxDecoration(
                                  color: Colors.red,
                                  shape: BoxShape.circle,
                                  boxShadow: [
                                    BoxShadow(
                                      color: Colors.black.withOpacity(0.3),
                                      blurRadius: 8,
                                      offset: const Offset(0, 2),
                                    ),
                                  ],
                                ),
                                child: IconButton(
                                  icon: Icon(
                                    Icons.close_rounded,
                                    color: Colors.white,
                                    size: ResponsiveHelper.iconSize(context, mobile: 20),
                                  ),
                                  onPressed: _removeImage,
                                ),
                              ),
                            ),
                          ],
                        ),
                ),
              ),
              SizedBox(height: ResponsiveHelper.spacing(context, 32)),

              // Title Section
              Text(
                'Title *',
                style: ResponsiveHelper.textStyle(
                  context,
                  fontSize: ResponsiveHelper.fontSize(context, mobile: 18, tablet: 19, desktop: 20),
                  fontWeight: FontWeight.bold,
                  color: const Color(0xFF5F4628),
                ),
              ),
              SizedBox(height: ResponsiveHelper.spacing(context, 8)),
              TextField(
                controller: titleController,
                style: ResponsiveHelper.textStyle(
                  context,
                  fontSize: ResponsiveHelper.fontSize(context, mobile: 16, tablet: 17, desktop: 18),
                  color: const Color(0xFF5F4628),
                ),
                decoration: InputDecoration(
                  hintText: 'Enter a compelling title for your blog',
                  hintStyle: ResponsiveHelper.textStyle(
                    context,
                    fontSize: ResponsiveHelper.fontSize(context, mobile: 14, tablet: 15, desktop: 16),
                    color: Colors.grey[500],
                  ),
                  border: OutlineInputBorder(
                    borderRadius: BorderRadius.circular(ResponsiveHelper.borderRadius(context, mobile: 12)),
                    borderSide: BorderSide(color: Colors.grey.withOpacity(0.3), width: 1.5),
                  ),
                  enabledBorder: OutlineInputBorder(
                    borderRadius: BorderRadius.circular(ResponsiveHelper.borderRadius(context, mobile: 12)),
                    borderSide: BorderSide(color: Colors.grey.withOpacity(0.3), width: 1.5),
                  ),
                  focusedBorder: OutlineInputBorder(
                    borderRadius: BorderRadius.circular(ResponsiveHelper.borderRadius(context, mobile: 12)),
                    borderSide: const BorderSide(color: Color(0xFF5F4628), width: 2.5),
                  ),
                  filled: true,
                  fillColor: Colors.white,
                  contentPadding: ResponsiveHelper.padding(context, all: 16),
                ),
                maxLength: 200,
              ),
              SizedBox(height: ResponsiveHelper.spacing(context, 24)),

              // Category and Language Row
              Row(
                children: [
                  // Category
                  Expanded(
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Text(
                          'Category *',
                          style: ResponsiveHelper.textStyle(
                            context,
                            fontSize: ResponsiveHelper.fontSize(context, mobile: 18, tablet: 19, desktop: 20),
                            fontWeight: FontWeight.bold,
                            color: const Color(0xFF5F4628),
                          ),
                        ),
                        SizedBox(height: ResponsiveHelper.spacing(context, 8)),
                        Container(
                          decoration: BoxDecoration(
                            color: Colors.white,
                            borderRadius: BorderRadius.circular(ResponsiveHelper.borderRadius(context, mobile: 12)),
                            border: Border.all(
                              color: Colors.grey.withOpacity(0.3),
                              width: 1.5,
                            ),
                          ),
                          child: DropdownButtonFormField<String>(
                            value: selectedCategory,
                            decoration: InputDecoration(
                              border: InputBorder.none,
                              contentPadding: ResponsiveHelper.padding(context, horizontal: 16, vertical: 12),
                            ),
                            style: ResponsiveHelper.textStyle(
                              context,
                              fontSize: ResponsiveHelper.fontSize(context, mobile: 16, tablet: 17, desktop: 18),
                              color: const Color(0xFF5F4628),
                            ),
                            items: ['Spiritual', 'Encouragement', 'Testimony', 'Teaching', 'Other']
                                .map((cat) => DropdownMenuItem(
                                      value: cat,
                                      child: Text(cat),
                                    ))
                                .toList(),
                            onChanged: (value) {
                              setState(() {
                                selectedCategory = value!;
                              });
                            },
                          ),
                        ),
                      ],
                    ),
                  ),
                  SizedBox(width: ResponsiveHelper.spacing(context, 16)),
                  // Language
                  Expanded(
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Text(
                          'Language *',
                          style: ResponsiveHelper.textStyle(
                            context,
                            fontSize: ResponsiveHelper.fontSize(context, mobile: 18, tablet: 19, desktop: 20),
                            fontWeight: FontWeight.bold,
                            color: const Color(0xFF5F4628),
                          ),
                        ),
                        SizedBox(height: ResponsiveHelper.spacing(context, 8)),
                        Container(
                          decoration: BoxDecoration(
                            color: Colors.white,
                            borderRadius: BorderRadius.circular(ResponsiveHelper.borderRadius(context, mobile: 12)),
                            border: Border.all(
                              color: Colors.grey.withOpacity(0.3),
                              width: 1.5,
                            ),
                          ),
                          child: DropdownButtonFormField<String>(
                            value: selectedLanguage,
                            decoration: InputDecoration(
                              border: InputBorder.none,
                              contentPadding: ResponsiveHelper.padding(context, horizontal: 16, vertical: 12),
                            ),
                            style: ResponsiveHelper.textStyle(
                              context,
                              fontSize: ResponsiveHelper.fontSize(context, mobile: 16, tablet: 17, desktop: 18),
                              color: const Color(0xFF5F4628),
                            ),
                            items: [
                              DropdownMenuItem(value: 'en', child: Text('English')),
                              DropdownMenuItem(value: 'es', child: Text('Spanish')),
                              DropdownMenuItem(value: 'fr', child: Text('French')),
                              DropdownMenuItem(value: 'hi', child: Text('Hindi')),
                              DropdownMenuItem(value: 'ar', child: Text('Arabic')),
                            ],
                            onChanged: (value) {
                              setState(() {
                                selectedLanguage = value!;
                              });
                            },
                          ),
                        ),
                      ],
                    ),
                  ),
                ],
              ),
              SizedBox(height: ResponsiveHelper.spacing(context, 24)),

              // Content Section
              Text(
                'Content *',
                style: ResponsiveHelper.textStyle(
                  context,
                  fontSize: ResponsiveHelper.fontSize(context, mobile: 18, tablet: 19, desktop: 20),
                  fontWeight: FontWeight.bold,
                  color: const Color(0xFF5F4628),
                ),
              ),
              SizedBox(height: ResponsiveHelper.spacing(context, 8)),
              Text(
                'Write your blog content (Minimum 50 characters)',
                style: ResponsiveHelper.textStyle(
                  context,
                  fontSize: ResponsiveHelper.fontSize(context, mobile: 14, tablet: 15, desktop: 16),
                  color: Colors.grey[600],
                ),
              ),
              SizedBox(height: ResponsiveHelper.spacing(context, 12)),
              TextField(
                controller: bodyController,
                maxLines: 12,
                style: ResponsiveHelper.textStyle(
                  context,
                  fontSize: ResponsiveHelper.fontSize(context, mobile: 16, tablet: 17, desktop: 18),
                  color: const Color(0xFF5F4628),
                  height: 1.6,
                ),
                decoration: InputDecoration(
                  hintText: 'Share your thoughts, experiences, and insights...',
                  hintStyle: ResponsiveHelper.textStyle(
                    context,
                    fontSize: ResponsiveHelper.fontSize(context, mobile: 14, tablet: 15, desktop: 16),
                    color: Colors.grey[500],
                  ),
                  border: OutlineInputBorder(
                    borderRadius: BorderRadius.circular(ResponsiveHelper.borderRadius(context, mobile: 12)),
                    borderSide: BorderSide(color: Colors.grey.withOpacity(0.3), width: 1.5),
                  ),
                  enabledBorder: OutlineInputBorder(
                    borderRadius: BorderRadius.circular(ResponsiveHelper.borderRadius(context, mobile: 12)),
                    borderSide: BorderSide(color: Colors.grey.withOpacity(0.3), width: 1.5),
                  ),
                  focusedBorder: OutlineInputBorder(
                    borderRadius: BorderRadius.circular(ResponsiveHelper.borderRadius(context, mobile: 12)),
                    borderSide: const BorderSide(color: Color(0xFF5F4628), width: 2.5),
                  ),
                  filled: true,
                  fillColor: Colors.white,
                  contentPadding: ResponsiveHelper.padding(context, all: 16),
                ),
              ),
              SizedBox(height: ResponsiveHelper.spacing(context, 8)),
              Text(
                '${bodyController.text.length} characters',
                style: ResponsiveHelper.textStyle(
                  context,
                  fontSize: ResponsiveHelper.fontSize(context, mobile: 12, tablet: 13, desktop: 14),
                  color: bodyController.text.length < 50 ? Colors.red : Colors.grey[600],
                ),
              ),
              SizedBox(height: ResponsiveHelper.spacing(context, 32)),

              // Submit Button
              SizedBox(
                width: double.infinity,
                height: ResponsiveHelper.buttonHeight(context, mobile: 56, tablet: 60, desktop: 64),
                child: ElevatedButton(
                  onPressed: controller.isLoading.value ? null : _submitBlog,
                  style: ElevatedButton.styleFrom(
                    backgroundColor: const Color(0xFF5F4628),
                    elevation: 6,
                    shadowColor: const Color(0xFF5F4628).withOpacity(0.4),
                    shape: RoundedRectangleBorder(
                      borderRadius: BorderRadius.circular(ResponsiveHelper.borderRadius(context, mobile: 16)),
                    ),
                  ),
                  child: controller.isLoading.value
                      ? SizedBox(
                          height: ResponsiveHelper.iconSize(context, mobile: 24),
                          width: ResponsiveHelper.iconSize(context, mobile: 24),
                          child: const CircularProgressIndicator(
                            color: Colors.white,
                            strokeWidth: 2.5,
                          ),
                        )
                      : Row(
                          mainAxisAlignment: MainAxisAlignment.center,
                          children: [
                            Icon(
                              Icons.publish_rounded,
                              color: Colors.white,
                              size: ResponsiveHelper.iconSize(context, mobile: 22, tablet: 24, desktop: 26),
                            ),
                            SizedBox(width: ResponsiveHelper.spacing(context, 8)),
                            Text(
                              'Publish Blog',
                              style: ResponsiveHelper.textStyle(
                                context,
                                fontSize: ResponsiveHelper.fontSize(context, mobile: 18, tablet: 19, desktop: 20),
                                fontWeight: FontWeight.bold,
                                color: Colors.white,
                              ),
                            ),
                          ],
                        ),
                ),
              ),
              SizedBox(height: ResponsiveHelper.spacing(context, 16)),
              Center(
                child: Text(
                  'Your blog will be reviewed by admin before publishing',
                  textAlign: TextAlign.center,
                  style: ResponsiveHelper.textStyle(
                    context,
                    fontSize: ResponsiveHelper.fontSize(context, mobile: 12, tablet: 13, desktop: 14),
                    color: Colors.grey[600],
                  ).copyWith(fontStyle: FontStyle.italic),
                ),
              ),
            ],
          ),
        );
      }),
    );
  }
}
