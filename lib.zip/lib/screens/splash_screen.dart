import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:fruitsofspirit/routes/app_pages.dart';
import 'package:fruitsofspirit/utils/responsive_helper.dart';
import 'package:fruitsofspirit/services/user_storage.dart';
import 'package:fruitsofspirit/services/data_loading_service.dart';
import 'package:fruitsofspirit/config/image_config.dart';

class SplashScreen extends StatefulWidget {
  const SplashScreen({Key? key}) : super(key: key);

  @override
  State<SplashScreen> createState() => _SplashScreenState();
}

class _SplashScreenState extends State<SplashScreen> with SingleTickerProviderStateMixin {
  late AnimationController _animationController;
  late Animation<double> _scaleAnimation;
  bool _isLoadingData = false;
  String _loadingMessage = 'Loading...';

  @override
  void initState() {
    super.initState();

    _animationController = AnimationController(
      vsync: this,
      duration: const Duration(milliseconds: 1200),
    );

    _scaleAnimation = Tween<double>(begin: 0.5, end: 1.0).animate(
      CurvedAnimation(parent: _animationController, curve: Curves.easeOutBack),
    );
    WidgetsBinding.instance.addPostFrameCallback((_) {
      // Precache splash image (handle errors gracefully)
      precacheImage(const AssetImage('assets/images/fruit_of_spirit.jpg'), context)
          .catchError((error) {
        // Image precaching failed, but app will still work
        debugPrint('Warning: Could not precache splash image: $error');
      });
    });
    _initializeApp();
  }

  Future<void> _initializeApp() async {
    _animationController.forward();

    await Future.delayed(const Duration(milliseconds: 1200));

    if (!mounted) return;

    // Check if user is logged in
    final isLoggedIn = await UserStorage.isLoggedIn();
    
    if (!mounted) return;

    if (isLoggedIn) {
      Get.offAllNamed(Routes.HOME);
      Future(() => DataLoadingService.loadAllHomeData());
    } else {
      // User is not logged in, go to login page
      Get.offAllNamed(Routes.LOGIN);
    }
  }

  @override
  void dispose() {
    _animationController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final w = ResponsiveHelper.safeScreenWidth(context);
    final h = ResponsiveHelper.safeScreenHeight(context);
    
    // Professional responsive sizing for tablets/iPads
    // Mobile: Keep original behavior (don't touch)
    // Tablets: Use max content width and better proportions
    final isTabletDevice = ResponsiveHelper.isTablet(context);
    final isLargeTabletDevice = ResponsiveHelper.isLargeTablet(context);
    // Get max content width for tablets (840px for small tablets, 1200px for large tablets)
    final double maxContentWidth = isTabletDevice 
        ? (isLargeTabletDevice ? 1200.0 : 840.0)
        : w;  // Mobile: use full width
    
    // Calculate image dimensions based on device type
    double imageWidth;
    double containerMaxWidth;
    double containerMaxHeight;
    double containerPadding;
    
    if (isTabletDevice) {
      // Tablets/iPads: Use larger sizing for better visibility
      if (isLargeTabletDevice) {
        // Large tablets (iPad Pro 12.9"): Bigger image
        imageWidth = (maxContentWidth * 0.75).clamp(600.0, 800.0);  // 75% of max content width
        containerMaxWidth = maxContentWidth * 0.85; // 85% of max content width
        containerMaxHeight = h * 0.7;  // More height
        containerPadding = 40.0;
      } else {
        // Small tablets (iPad Mini, iPad, iPad Air): Bigger image
        imageWidth = (maxContentWidth * 0.8).clamp(500.0, 700.0);  // 80% of max content width
        containerMaxWidth = maxContentWidth * 0.9; // 90% of max content width
        containerMaxHeight = h * 0.65;  // More height
        containerPadding = 32.0;
      }
    } else {
      // Mobile: Keep original behavior (don't touch)
      imageWidth = w * 0.9;
      containerMaxWidth = w * 0.9;
      containerMaxHeight = h * 0.7;
      containerPadding = ResponsiveHelper.spacing(context, 20);
    }
    
    return Scaffold(
      body: Container(
        color: Colors.white,
        child: SafeArea(
          top: true,
          bottom: true,
          child: ResponsiveHelper.safeScrollable(
            context: context,
            child: Center(
              child: ResponsiveHelper.constrainedContent(
                context: context,
                maxWidth: isTabletDevice ? maxContentWidth : null,
                child: Column(
                  mainAxisAlignment: MainAxisAlignment.center,
                  mainAxisSize: MainAxisSize.min,
                  children: [
                    ScaleTransition(
                      scale: _scaleAnimation,
                      child: Container(
                        // Professional padding: More for tablets, original for mobile
                        padding: EdgeInsets.all(containerPadding),
                        // Constraints: Use max content width for tablets
                        constraints: BoxConstraints(
                          maxWidth: containerMaxWidth,
                          maxHeight: containerMaxHeight,
                        ),
                        child: Image.asset(
                          'assets/images/fruit_of_spirit.jpg',
                          width: imageWidth > containerMaxWidth - (containerPadding * 2)
                              ? containerMaxWidth - (containerPadding * 2)
                              : imageWidth,
                          fit: BoxFit.contain,
                          errorBuilder: (context, error, stackTrace) {
                            // Fallback to old splash image if new one not found
                            return Image.asset(
                              'assets/images/fruit_of_spirit_splash.jpg',
                              width: imageWidth > containerMaxWidth - (containerPadding * 2)
                                  ? containerMaxWidth - (containerPadding * 2)
                                  : imageWidth,
                              fit: BoxFit.contain,
                            );
                          },
                        ),
                      ),
                    ),
                    if (_isLoadingData) ...[
                      SizedBox(height: ResponsiveHelper.spacing(
                        context, 
                        isTabletDevice ? 40 : 30  // More spacing for tablets
                      )),
                      CircularProgressIndicator(
                        color: const Color(0xFF8B4513),
                        strokeWidth: isTabletDevice ? 3.0 : 2.0,  // Thicker for tablets
                      ),
                      SizedBox(height: ResponsiveHelper.spacing(
                        context, 
                        isTabletDevice ? 20 : 16  // More spacing for tablets
                      )),
                      Text(
                        _loadingMessage,
                        style: ResponsiveHelper.textStyle(
                          context,
                          fontSize: ResponsiveHelper.fontSize(
                            context, 
                            mobile: 16,
                            tablet: 18,  // Larger text for tablets
                          ),
                          color: const Color(0xFF8B4513),
                        ),
                      ),
                    ],
                  ],
                ),
              ),
            ),
          ),
        ),
      ),
    );
  }
}
