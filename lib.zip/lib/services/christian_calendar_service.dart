import 'dart:convert';
import 'package:http/http.dart' as http;
import '../config/api_config.dart';

/// Christian Calendar Service
/// Fetches liturgical events and civil holidays from the backend
class ChristianCalendarService {
  /// Fetch upcoming Christian and secular events
  /// 
  /// [limit] - Number of events to fetch (default: 80)
  /// Returns list of upcoming events with dates
  static Future<List<Map<String, dynamic>>> getUpcomingEvents({int limit = 80}) async {
    try {
      final response = await http.get(
        Uri.parse('${ApiConfig.christianCalendar}?upcoming=1&limit=$limit'),
        headers: ApiConfig.headers,
      ).timeout(ApiConfig.timeout);

      if (response.statusCode == 200) {
        final data = jsonDecode(response.body);
        if (data['success'] == true) {
          return List<Map<String, dynamic>>.from(data['data'] ?? []);
        }
      }
      return [];
    } catch (e) {
      print('Error fetching upcoming events: $e');
      return [];
    }
  }

  /// Fetch events for a specific month
  /// 
  /// [year] - Year (e.g., 2026)
  /// [month] - Month (1-12)
  /// Returns map of day number to list of events
  static Future<Map<int, List<Map<String, dynamic>>>> getMonthEvents(int year, int month) async {
    try {
      final response = await http.get(
        Uri.parse('${ApiConfig.christianCalendar}?y=$year&m=$month'),
        headers: ApiConfig.headers,
      ).timeout(ApiConfig.timeout);

      if (response.statusCode == 200) {
        final data = jsonDecode(response.body);
        if (data['success'] == true) {
          final Map<int, List<Map<String, dynamic>>> result = {};
          final monthData = data['data'] as Map<String, dynamic>;
          
          monthData.forEach((dayStr, events) {
            final day = int.tryParse(dayStr) ?? 0;
            if (day > 0 && events is List) {
              result[day] = List<Map<String, dynamic>>.from(
                events.map((e) => Map<String, dynamic>.from(e)),
              );
            }
          });
          
          return result;
        }
      }
      return {};
    } catch (e) {
      print('Error fetching month events: $e');
      return {};
    }
  }

  /// Fetch all events for a year
  /// 
  /// [year] - Year (e.g., 2026)
  /// Returns map of date (YYYY-MM-DD) to list of events
  static Future<Map<String, List<Map<String, dynamic>>>> getYearEvents(int year) async {
    try {
      final response = await http.get(
        Uri.parse('${ApiConfig.christianCalendar}?y=$year'),
        headers: ApiConfig.headers,
      ).timeout(ApiConfig.timeout);

      if (response.statusCode == 200) {
        final data = jsonDecode(response.body);
        if (data['success'] == true) {
          final Map<String, List<Map<String, dynamic>>> result = {};
          final yearData = data['data'] as Map<String, dynamic>;
          
          yearData.forEach((date, events) {
            if (events is List) {
              result[date] = List<Map<String, dynamic>>.from(
                events.map((e) => Map<String, dynamic>.from(e)),
              );
            }
          });
          
          return result;
        }
      }
      return {};
    } catch (e) {
      print('Error fetching year events: $e');
      return {};
    }
  }

  /// Check if a specific date has events
  /// 
  /// [date] - Date in format YYYY-MM-DD
  static Future<List<Map<String, dynamic>>> getEventsForDate(String date) async {
    try {
      final parts = date.split('-');
      if (parts.length != 3) return [];
      
      final year = int.parse(parts[0]);
      final month = int.parse(parts[1]);
      final day = int.parse(parts[2]);
      
      final monthEvents = await getMonthEvents(year, month);
      return monthEvents[day] ?? [];
    } catch (e) {
      print('Error fetching events for date: $e');
      return [];
    }
  }

  /// Get event category icon
  static String getEventIcon(String category) {
    return category == 'christian' ? '✝' : '🎉';
  }

  /// Get event category color
  static int getEventColor(String category) {
    return category == 'christian' ? 0xFFE57373 : 0xFFFFB74D; // Red for Christian, Gold for secular
  }
}
