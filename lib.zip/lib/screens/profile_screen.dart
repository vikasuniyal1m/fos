import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:fruitsofspirit/controllers/profile_controller.dart';
import 'package:fruitsofspirit/controllers/prayers_controller.dart';
import 'package:fruitsofspirit/controllers/blogs_controller.dart';
import 'package:fruitsofspirit/controllers/gallery_controller.dart';
import 'package:fruitsofspirit/routes/routes.dart';
import 'package:fruitsofspirit/utils/localization_helper.dart';
import 'package:fruitsofspirit/utils/responsive_helper.dart';
import 'package:fruitsofspirit/services/user_storage.dart';
import 'package:fruitsofspirit/services/cache_service.dart';
import 'package:easy_localization/easy_localization.dart';

/// Profile Screen
/// Displays user profile information with professional UI
class ProfileScreen extends GetView<ProfileController> {
  const ProfileScreen({Key? key}) : super(key: key);

  /// Get ImageProvider for profile photo (handles both network and assets)
  ImageProvider? _getImageProvider(String? photoUrl) {
    if (photoUrl == null || photoUrl.isEmpty) {
      return null;
    }
    
    // Check if it's a local asset path
    if (photoUrl.startsWith('assets/') || photoUrl.startsWith('assets/images/')) {
      return AssetImage(photoUrl);
    }
    
    // Check if it's already a full URL
    if (photoUrl.startsWith('http://') || photoUrl.startsWith('https://')) {
      return NetworkImage(photoUrl);
    }
    
    // Check if it's a file:// URL (invalid)
    if (photoUrl.startsWith('file://')) {
      return null;
    }
    
    // If it's a relative path, construct full URL
    return NetworkImage('https://fruitofthespirit.templateforwebsites.com/$photoUrl');
  }

  @override
  Widget build(BuildContext context) {
    // Professional responsive design for tablets/iPads
    final isTabletDevice = ResponsiveHelper.isTablet(context);
    final double? maxContentWidthValue = isTabletDevice 
        ? (ResponsiveHelper.isLargeTablet(context) ? 1200.0 : 840.0)
        : null;
    
    return Scaffold(
      backgroundColor: const Color(0xFFFAF6EC), // Light beige/cream background
      appBar: PreferredSize(
        preferredSize: Size.fromHeight(
          ResponsiveHelper.appBarHeight(context)
        ),
        child: AppBar(
          backgroundColor: const Color(0xFF5F4628), // Dark brown background
          elevation: 0,
          leading: IconButton(
            icon: Icon(Icons.arrow_back, color: Colors.white,
              size: ResponsiveHelper.iconSize(
                context,mobile: 24,tablet: 28,desktop: 32)
            ),
            onPressed: () => Get.back(),
          ),
          title: Text(
            LocalizationHelper.tr('profile'),
            style: ResponsiveHelper.textStyle(
              context,
              fontSize: ResponsiveHelper.fontSize(context, mobile: 18, tablet: 22, desktop: 26),
              fontWeight: FontWeight.bold,
              color: Colors.white,
            ),
          ),
          centerTitle: true,
        ),
      ),
      body: Obx(() {
        if (controller.isLoading.value && controller.profile.isEmpty) {
          return Center(
            child: CircularProgressIndicator(
              color: const Color(0xFF5F4628),
            ),
          );
        }

        if (controller.profile.isEmpty) {
          return Center(
            child: Column(
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                Icon(
                  Icons.person_outline,
                  size: ResponsiveHelper.iconSize(context, mobile: 64),
                  color: Colors.grey,
                ),
                SizedBox(height: ResponsiveHelper.spacing(context, 16)),
                Text(
                  LocalizationHelper.tr('no_profile_data'),
                  style: ResponsiveHelper.textStyle(
                    context,
                    fontSize: ResponsiveHelper.fontSize(context, mobile: 15, tablet: 16, desktop: 17),
                    color: Colors.grey,
                  ),
                ),
                SizedBox(height: ResponsiveHelper.spacing(context, 16)),
                ElevatedButton(
                  onPressed: () => controller.refresh(),
                  style: ElevatedButton.styleFrom(
                    backgroundColor: const Color(0xFF5F4628),
                    foregroundColor: Colors.white,
                  ),
                  child: Text(LocalizationHelper.tr('retry')),
                ),
              ],
            ),
          );
        }

        final profile = controller.profile;
        final stats = profile['stats'] as Map<String, dynamic>? ?? {};
        final fruits = profile['fruits'] as List<dynamic>? ?? [];
        final baseUrl = 'https://fruitofthespirit.templateforwebsites.com/';
        final profilePhoto = profile['profile_photo'] != null
            ? baseUrl + (profile['profile_photo'] as String)
            : null;

        return RefreshIndicator(
          onRefresh: () => controller.refresh(),
          color: const Color(0xFF5F4628),
          child: Center(
            child: ResponsiveHelper.constrainedContent(
              context: context,
              maxWidth: maxContentWidthValue,
              child: SingleChildScrollView(
                child: Column(
                  children: [
                // Header Section with Profile Picture
                Container(
                  width: double.infinity,
                  decoration: BoxDecoration(
                    color: const Color(0xFF5F4628),
                    borderRadius: BorderRadius.only(
                      bottomLeft: Radius.circular(ResponsiveHelper.borderRadius(context, mobile: 30)),
                      bottomRight: Radius.circular(ResponsiveHelper.borderRadius(context, mobile: 30)),
                    ),
                  ),
                  padding: ResponsiveHelper.padding(
                    context,
                    top: ResponsiveHelper.isMobile(context) ? 16 : 20,
                    bottom: ResponsiveHelper.isMobile(context) ? 70 : 80,
                    left: ResponsiveHelper.isMobile(context) ? 14 : 16,
                    right: ResponsiveHelper.isMobile(context) ? 14 : 16,
                  ),
                  child: Column(
                    children: [
                      // Profile Picture with white border
                      Container(
                        decoration: BoxDecoration(
                          shape: BoxShape.circle,
                          border: Border.all(
                            color: Colors.white,
                            width: ResponsiveHelper.isMobile(context) ? 3 : 4,
                          ),
                        ),
                        child: CircleAvatar(
                          radius: ResponsiveHelper.isMobile(context) ? 50 : ResponsiveHelper.isTablet(context) ? 55 : 60,
                          backgroundColor: const Color(0xFFFEECE2),
                          backgroundImage: profilePhoto != null
                              ? _getImageProvider(profilePhoto)
                              : null,
                          child: profilePhoto == null
                              ? Icon(
                                  Icons.person,
                                  size: ResponsiveHelper.isMobile(context) ? 50 : ResponsiveHelper.isTablet(context) ? 55 : 60,
                                  color: const Color(0xFF5F4628),
                                )
                              : null,
                        ),
                      ),
                      SizedBox(height: ResponsiveHelper.spacing(context, 16)),
                      // Name
                      Text(
                        profile['name'] as String? ?? 'Anonymous',
                        style: ResponsiveHelper.textStyle(
                          context,
                          fontSize: ResponsiveHelper.fontSize(context, mobile: 22, tablet: 24, desktop: 26),
                          fontWeight: FontWeight.bold,
                          color: Colors.white,
                        ),
                        maxLines: 1,
                        overflow: TextOverflow.ellipsis,
                      ),
                      SizedBox(height: ResponsiveHelper.spacing(context, ResponsiveHelper.isMobile(context) ? 6 : 8)),
                      // Email
                      if (profile['email'] != null)
                        Text(
                          profile['email'] as String,
                          style: ResponsiveHelper.textStyle(
                            context,
                            fontSize: ResponsiveHelper.fontSize(context, mobile: 13, tablet: 14, desktop: 15),
                            color: Colors.white.withOpacity(0.9),
                          ),
                          maxLines: 1,
                          overflow: TextOverflow.ellipsis,
                        ),
                    ],
                  ),
                ),
                
                // Content Section
                Transform.translate(
                  offset: Offset(0, ResponsiveHelper.isMobile(context) ? -35 : -40),
                  child: Container(
                    width: double.infinity,
                    padding: ResponsiveHelper.padding(
                      context,
                      horizontal: ResponsiveHelper.isMobile(context) ? 14 : 16,
                    ),
                    child: Column(
                      children: [
                        // Stats Cards
                        Row(
                          children: [
                            Expanded(
                              child: _buildStatCard(
                                context,
                                'Prayers',
                                '${stats['prayers'] ?? 0}',
                                Icons.favorite,
                                Colors.red,
                                onTap: () {
                                  final currentUserId = controller.userId.value;
                                  if (currentUserId > 0) {
                                    // Set filter before navigation
                                    try {
                                      final prayersController = Get.find<PrayersController>();
                                      prayersController.filterUserId.value = currentUserId;
                                    } catch (e) {
                                      // Controller doesn't exist yet, create it with filter
                                      final prayersController = Get.put(PrayersController());
                                      prayersController.filterUserId.value = currentUserId;
                                    }
                                    // Navigate and reload immediately after
                                    final result = Get.toNamed(Routes.PRAYER_REQUESTS);
                                    result?.then((_) {
                                      // Use a small delay to ensure controller is ready
                                      Future.delayed(Duration(milliseconds: 50), () {
                                        try {
                                          final prayersController = Get.find<PrayersController>();
                                          prayersController.filterUserId.value = currentUserId;
                                          // Performance: Only load if data doesn't exist
                                          if (prayersController.prayers.isEmpty) {
                                            prayersController.loadPrayers(refresh: true);
                                          }
                                        } catch (e) {
                                          // Controller will be created by route binding
                                          // Try again after a bit more delay
                                          Future.delayed(Duration(milliseconds: 100), () {
                                            try {
                                              final prayersController = Get.find<PrayersController>();
                                              prayersController.filterUserId.value = currentUserId;
                                              // Performance: Only load if data doesn't exist
                                              if (prayersController.prayers.isEmpty) {
                                                prayersController.loadPrayers(refresh: true);
                                              }
                                            } catch (e2) {
                                              print('Error setting prayers filter: $e2');
                                            }
                                          });
                                        }
                                      });
                                    });
                                  } else {
                                    Get.toNamed(Routes.PRAYER_REQUESTS);
                                  }
                                },
                              ),
                            ),
                            SizedBox(width: ResponsiveHelper.spacing(context, 12)),
                            Expanded(
                              child: _buildStatCard(
                                context,
                                'Blogs',
                                '${stats['blogs'] ?? 0}',
                                Icons.article,
                                Colors.blue,
                                onTap: () {
                                  final currentUserId = controller.userId.value;
                                  if (currentUserId > 0) {
                                    // Set filter before navigation
                                    try {
                                      final blogsController = Get.find<BlogsController>();
                                      blogsController.filterUserId.value = currentUserId;
                                    } catch (e) {
                                      // Controller doesn't exist yet, create it with filter
                                      final blogsController = Get.put(BlogsController());
                                      blogsController.filterUserId.value = currentUserId;
                                    }
                                    // Navigate and reload immediately after
                                    final result = Get.toNamed(Routes.BLOGS);
                                    result?.then((_) {
                                      // Use a small delay to ensure controller is ready
                                      Future.delayed(Duration(milliseconds: 50), () {
                                        try {
                                          final blogsController = Get.find<BlogsController>();
                                          blogsController.filterUserId.value = currentUserId;
                                          blogsController.loadBlogs(refresh: true);
                                        } catch (e) {
                                          // Controller will be created by route binding
                                          // Try again after a bit more delay
                                          Future.delayed(Duration(milliseconds: 100), () {
                                            try {
                                              final blogsController = Get.find<BlogsController>();
                                              blogsController.filterUserId.value = currentUserId;
                                              blogsController.loadBlogs(refresh: true);
                                            } catch (e2) {
                                              print('Error setting blogs filter: $e2');
                                            }
                                          });
                                        }
                                      });
                                    });
                                  } else {
                                    Get.toNamed(Routes.BLOGS);
                                  }
                                },
                              ),
                            ),
                            SizedBox(width: ResponsiveHelper.spacing(context, 12)),
                            Expanded(
                              child: _buildStatCard(
                                context,
                                'Media',
                                '${stats['media'] ?? 0}',
                                Icons.photo_library,
                                Colors.purple,
                                onTap: () {
                                  final currentUserId = controller.userId.value;
                                  if (currentUserId > 0) {
                                    // Set filter before navigation
                                    try {
                                      final galleryController = Get.find<GalleryController>();
                                      galleryController.filterUserId.value = currentUserId;
                                    } catch (e) {
                                      // Controller doesn't exist yet, create it with filter
                                      final galleryController = Get.put(GalleryController());
                                      galleryController.filterUserId.value = currentUserId;
                                    }
                                    // Navigate and reload immediately after
                                    final result = Get.toNamed(Routes.GALLERY);
                                    result?.then((_) {
                                      // Use a small delay to ensure controller is ready
                                      Future.delayed(Duration(milliseconds: 50), () {
                                        try {
                                          final galleryController = Get.find<GalleryController>();
                                          galleryController.filterUserId.value = currentUserId;
                                          galleryController.loadPhotos(refresh: true);
                                        } catch (e) {
                                          // Controller will be created by route binding
                                          // Try again after a bit more delay
                                          Future.delayed(Duration(milliseconds: 100), () {
                                            try {
                                              final galleryController = Get.find<GalleryController>();
                                              galleryController.filterUserId.value = currentUserId;
                                              galleryController.loadPhotos(refresh: true);
                                            } catch (e2) {
                                              print('Error setting gallery filter: $e2');
                                            }
                                          });
                                        }
                                      });
                                    });
                                  } else {
                                    Get.toNamed(Routes.GALLERY);
                                  }
                                },
                              ),
                            ),
                          ],
                        ),
                        SizedBox(height: ResponsiveHelper.spacing(context, 24)),
                        
                        // Personal Information Card
                        _buildInfoCard(
                          context,
                          'Personal Information',
                          [
                            _buildInfoRow(
                              context,
                              Icons.person,
                              'Full Name',
                              profile['name'] as String? ?? 'Not provided',
                            ),
                            if (profile['email'] != null)
                              _buildInfoRow(
                                context,
                                Icons.email,
                                'Email',
                                profile['email'] as String,
                              ),
                            if (profile['phone'] != null)
                              _buildInfoRow(
                                context,
                                Icons.phone,
                                'Phone',
                                profile['phone'] as String,
                              ),
                            if (profile['fruit_category'] != null)
                              _buildInfoRow(
                                context,
                                Icons.apple,
                                'Primary Fruit',
                                profile['fruit_category'] as String,
                              ),
                          ],
                        ),
                        SizedBox(height: ResponsiveHelper.spacing(context, 16)),
                        
                        // Selected Fruits Card
                        if (fruits.isNotEmpty)
                          _buildFruitsCard(context, fruits),
                        
                        SizedBox(height: ResponsiveHelper.spacing(context, 16)),
                        
                        // Settings Card
                        _buildSettingsCard(context),
                        
                        SizedBox(height: ResponsiveHelper.spacing(context, 24)),
                      ],
                    ),
                  ),
                ),
              ],
                ),
              ),
            ),
          ),
        );
      }),
    );
  }

  Widget _buildStatCard(BuildContext context, String label, String value, IconData icon, Color color, {VoidCallback? onTap}) {
    return InkWell(
      onTap: onTap,
      borderRadius: BorderRadius.circular(ResponsiveHelper.borderRadius(context, mobile: 12)),
      child: Container(
        padding: ResponsiveHelper.padding(
          context,
          all: ResponsiveHelper.isMobile(context) ? 14 : 16,
        ),
        decoration: BoxDecoration(
          color: Colors.white,
          borderRadius: BorderRadius.circular(ResponsiveHelper.borderRadius(context, mobile: 12)),
          boxShadow: [
            BoxShadow(
              color: Colors.black.withOpacity(0.05),
              blurRadius: 10,
              offset: Offset(0, 2),
            ),
          ],
        ),
        child: Column(
          children: [
            Container(
              padding: ResponsiveHelper.padding(
                context,
                all: ResponsiveHelper.isMobile(context) ? 10 : 12,
              ),
              decoration: BoxDecoration(
                color: color.withOpacity(0.1),
                shape: BoxShape.circle,
              ),
              child: Icon(
                icon,
                color: color,
                size: ResponsiveHelper.iconSize(context, mobile: 22, tablet: 24, desktop: 26),
              ),
            ),
                SizedBox(height: ResponsiveHelper.spacing(context, ResponsiveHelper.isMobile(context) ? 10 : 12)),
            Text(
              value,
              style: ResponsiveHelper.textStyle(
                context,
                fontSize: ResponsiveHelper.fontSize(context, mobile: 22, tablet: 24, desktop: 26),
                fontWeight: FontWeight.bold,
                color: const Color(0xFF5F4628),
              ),
            ),
            SizedBox(height: ResponsiveHelper.spacing(context, 4)),
            Text(
              label,
              style: ResponsiveHelper.textStyle(
                context,
                fontSize: ResponsiveHelper.fontSize(context, mobile: 11, tablet: 12, desktop: 13),
                color: Colors.grey[600],
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildInfoCard(BuildContext context, String title, List<Widget> children) {
    return Container(
      width: double.infinity,
      padding: ResponsiveHelper.padding(
        context,
        all: ResponsiveHelper.isMobile(context) ? 16 : 20,
      ),
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(ResponsiveHelper.borderRadius(context, mobile: 16)),
        boxShadow: [
          BoxShadow(
            color: Colors.black.withOpacity(0.05),
            blurRadius: 10,
            offset: Offset(0, 2),
          ),
        ],
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text(
            title,
            style: ResponsiveHelper.textStyle(
              context,
              fontSize: ResponsiveHelper.fontSize(context, mobile: 17, tablet: 18, desktop: 20),
              fontWeight: FontWeight.bold,
              color: const Color(0xFF5F4628),
            ),
          ),
          SizedBox(height: ResponsiveHelper.spacing(context, ResponsiveHelper.isMobile(context) ? 14 : 16)),
          ...children,
        ],
      ),
    );
  }

  Widget _buildInfoRow(BuildContext context, IconData icon, String label, String value) {
    return Padding(
      padding: EdgeInsets.only(bottom: ResponsiveHelper.spacing(context, 16)),
      child: Row(
        children: [
          Container(
            padding: ResponsiveHelper.padding(context, all: 8),
            decoration: BoxDecoration(
              color: const Color(0xFF5F4628).withOpacity(0.1),
              borderRadius: BorderRadius.circular(ResponsiveHelper.borderRadius(context, mobile: 8)),
            ),
            child: Icon(
              icon,
              color: const Color(0xFF5F4628),
              size: ResponsiveHelper.iconSize(context, mobile: 20),
            ),
          ),
          SizedBox(width: ResponsiveHelper.spacing(context, 12)),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  label,
                  style: ResponsiveHelper.textStyle(
                    context,
                    fontSize: 12,
                    color: Colors.grey[600],
                  ),
                ),
                SizedBox(height: ResponsiveHelper.spacing(context, 4)),
                Text(
                  value,
                  style: ResponsiveHelper.textStyle(
                    context,
                    fontSize: 16,
                    fontWeight: FontWeight.w500,
                    color: Colors.black87,
                  ),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildFruitsCard(BuildContext context, List<dynamic> fruits) {
    return Container(
      width: double.infinity,
      padding: ResponsiveHelper.padding(
        context,
        all: ResponsiveHelper.isMobile(context) ? 16 : 20,
      ),
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(ResponsiveHelper.borderRadius(context, mobile: 16)),
        boxShadow: [
          BoxShadow(
            color: Colors.black.withOpacity(0.05),
            blurRadius: 10,
            offset: Offset(0, 2),
          ),
        ],
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text(
            'Selected Fruits',
            style: ResponsiveHelper.textStyle(
              context,
              fontSize: ResponsiveHelper.fontSize(context, mobile: 17, tablet: 18, desktop: 20),
              fontWeight: FontWeight.bold,
              color: const Color(0xFF5F4628),
            ),
          ),
          SizedBox(height: ResponsiveHelper.spacing(context, ResponsiveHelper.isMobile(context) ? 14 : 16)),
          Wrap(
            spacing: ResponsiveHelper.spacing(context, ResponsiveHelper.isMobile(context) ? 6 : 8),
            runSpacing: ResponsiveHelper.spacing(context, ResponsiveHelper.isMobile(context) ? 6 : 8),
            children: fruits.map((fruit) {
              final fruitName = fruit['name'] as String? ?? 'Unknown';
              return Container(
                padding: ResponsiveHelper.padding(
                  context,
                  horizontal: ResponsiveHelper.isMobile(context) ? 14 : 16,
                  vertical: ResponsiveHelper.isMobile(context) ? 6 : 8,
                ),
                decoration: BoxDecoration(
                  color: const Color(0xFFE3F2FD),
                  borderRadius: BorderRadius.circular(ResponsiveHelper.borderRadius(context, mobile: 20)),
                  border: Border.all(
                    color: const Color(0xFF5F4628).withOpacity(0.2),
                    width: 1,
                  ),
                ),
                child: Row(
                  mainAxisSize: MainAxisSize.min,
                  children: [
                    Icon(
                      Icons.apple,
                      size: ResponsiveHelper.iconSize(context, mobile: 15, tablet: 16, desktop: 17),
                      color: const Color(0xFF5F4628),
                    ),
                    SizedBox(width: ResponsiveHelper.spacing(context, 6)),
                    Flexible(
                      child: Text(
                        fruitName,
                        style: ResponsiveHelper.textStyle(
                          context,
                          fontSize: ResponsiveHelper.fontSize(context, mobile: 13, tablet: 14, desktop: 15),
                          fontWeight: FontWeight.w500,
                          color: const Color(0xFF5F4628),
                        ),
                        maxLines: 1,
                        overflow: TextOverflow.ellipsis,
                      ),
                    ),
                  ],
                ),
              );
            }).toList(),
          ),
        ],
      ),
    );
  }

  Widget _buildSettingsCard(BuildContext context) {
    return Container(
      width: double.infinity,
      padding: ResponsiveHelper.padding(
        context,
        all: ResponsiveHelper.isMobile(context) ? 16 : 20,
      ),
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(ResponsiveHelper.borderRadius(context, mobile: 16)),
        boxShadow: [
          BoxShadow(
            color: Colors.black.withOpacity(0.05),
            blurRadius: 10,
            offset: Offset(0, 2),
          ),
        ],
      ),
      child: Column(
        children: [
          _buildSettingTile(
            context,
            Icons.language,
            'Change Language',
            'Select app interface language',
            context.locale.languageCode.toUpperCase(),
            () => _showLanguageSelector(context),
          ),
          Divider(height: ResponsiveHelper.spacing(context, ResponsiveHelper.isMobile(context) ? 24 : 32)),
          _buildSettingTile(
            context,
            Icons.edit,
            'Edit Profile',
            'Update your profile information',
            null,
            () => Get.toNamed(Routes.EDIT_PROFILE),
          ),
          Divider(height: ResponsiveHelper.spacing(context, ResponsiveHelper.isMobile(context) ? 24 : 32)),
          _buildSettingTile(
            context,
            Icons.logout,
            'Logout',
            'Sign out from your account',
            null,
            () => _showLogoutDialog(context),
          ),
        ],
      ),
    );
  }

  void _showLogoutDialog(BuildContext context) {
    showDialog(
      context: context,
      builder: (BuildContext context) {
        return AlertDialog(
          shape: RoundedRectangleBorder(
            borderRadius: BorderRadius.circular(ResponsiveHelper.borderRadius(context, mobile: 20)),
          ),
          title: Text(
            'Logout',
            style: ResponsiveHelper.textStyle(
              context,
              fontSize: ResponsiveHelper.fontSize(context, mobile: 18, tablet: 20, desktop: 22),
              fontWeight: FontWeight.bold,
              color: const Color(0xFF5F4628),
            ),
          ),
          content: Text(
            'Are you sure you want to logout?',
            style: ResponsiveHelper.textStyle(
              context,
              fontSize: ResponsiveHelper.fontSize(context, mobile: 15, tablet: 16, desktop: 17),
              color: Colors.black87,
            ),
          ),
          actions: [
            TextButton(
              onPressed: () => Navigator.of(context).pop(),
              child: Text(
                'Cancel',
                style: TextStyle(
                  color: Colors.grey[600],
                  fontWeight: FontWeight.w500,
                ),
              ),
            ),
            ElevatedButton(
              onPressed: () async {
                Navigator.of(context).pop();
                await _logout();
              },
              style: ElevatedButton.styleFrom(
                backgroundColor: const Color(0xFF9F9467),
                shape: RoundedRectangleBorder(
                  borderRadius: BorderRadius.circular(ResponsiveHelper.borderRadius(context, mobile: 12)),
                ),
                padding: ResponsiveHelper.padding(
                  context,
                  horizontal: ResponsiveHelper.isMobile(context) ? 20 : 24,
                  vertical: ResponsiveHelper.isMobile(context) ? 10 : 12,
                ),
              ),
              child: Text(
                'Logout',
                style: ResponsiveHelper.textStyle(
                  context,
                  fontSize: ResponsiveHelper.fontSize(context, mobile: 15, tablet: 16, desktop: 17),
                  color: Colors.white,
                  fontWeight: FontWeight.bold,
                ),
              ),
            ),
          ],
        );
      },
    );
  }

  Future<void> _logout() async {
    try {
      final context = Get.context!;
      // Show loading
      Get.dialog(
        Center(
          child: Container(
            padding: ResponsiveHelper.padding(
              context,
              all: ResponsiveHelper.isMobile(context) ? 16 : 20,
            ),
            decoration: BoxDecoration(
              color: Colors.white,
              borderRadius: BorderRadius.circular(ResponsiveHelper.borderRadius(context, mobile: 16)),
            ),
            child: Column(
              mainAxisSize: MainAxisSize.min,
              children: [
                const CircularProgressIndicator(
                  color: Color(0xFF9F9467),
                ),
                SizedBox(height: ResponsiveHelper.spacing(context, ResponsiveHelper.isMobile(context) ? 14 : 16)),
                Text(
                  'Logging out...',
                  style: ResponsiveHelper.textStyle(
                    context,
                    fontSize: ResponsiveHelper.fontSize(context, mobile: 13, tablet: 14, desktop: 15),
                    color: Colors.grey[600],
                  ),
                ),
              ],
            ),
          ),
        ),
        barrierDismissible: false,
      );

      // Clear user data
      await UserStorage.clearUser();
      
      // Clear cache
      await CacheService.clearAllCache();
      
      // Close dialog
      Get.back();
      
      // Navigate to login page
      Get.offAllNamed(Routes.LOGIN);
      
      // Show success message
      Get.snackbar(
        'Logged Out',
        'You have been successfully logged out',
        snackPosition: SnackPosition.BOTTOM,
        backgroundColor: Colors.green.withOpacity(0.8),
        colorText: Colors.white,
        duration: const Duration(seconds: 2),
        icon: const Icon(Icons.check_circle, color: Colors.white),
      );
    } catch (e) {
      // Close loading dialog if open
      if (Get.isDialogOpen ?? false) {
        Get.back();
      }
      
      Get.snackbar(
        'Error',
        'Failed to logout: ${e.toString()}',
        snackPosition: SnackPosition.BOTTOM,
        backgroundColor: Colors.red.withOpacity(0.8),
        colorText: Colors.white,
        duration: const Duration(seconds: 2),
        icon: const Icon(Icons.error, color: Colors.white),
      );
    }
  }

  Widget _buildSettingTile(
    BuildContext context,
    IconData icon,
    String title,
    String subtitle,
    String? trailing,
    VoidCallback onTap,
  ) {
    return InkWell(
      onTap: onTap,
      borderRadius: BorderRadius.circular(ResponsiveHelper.borderRadius(context, mobile: 12)),
      child: Padding(
        padding: ResponsiveHelper.padding(
          context,
          vertical: ResponsiveHelper.isMobile(context) ? 6 : 8,
        ),
        child: Row(
          children: [
            Container(
              padding: ResponsiveHelper.padding(
                context,
                all: ResponsiveHelper.isMobile(context) ? 8 : 10,
              ),
              decoration: BoxDecoration(
                color: const Color(0xFF5F4628).withOpacity(0.1),
                borderRadius: BorderRadius.circular(ResponsiveHelper.borderRadius(context, mobile: 10)),
              ),
              child: Icon(
                icon,
                color: const Color(0xFF5F4628),
                size: ResponsiveHelper.iconSize(context, mobile: 22, tablet: 24, desktop: 26),
              ),
            ),
            SizedBox(width: ResponsiveHelper.spacing(context, ResponsiveHelper.isMobile(context) ? 14 : 16)),
            Expanded(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(
                    title,
                    style: ResponsiveHelper.textStyle(
                      context,
                      fontSize: ResponsiveHelper.fontSize(context, mobile: 15, tablet: 16, desktop: 17),
                      fontWeight: FontWeight.bold,
                      color: const Color(0xFF5F4628),
                    ),
                    maxLines: 1,
                    overflow: TextOverflow.ellipsis,
                  ),
                  SizedBox(height: ResponsiveHelper.spacing(context, 4)),
                  Text(
                    subtitle,
                    style: ResponsiveHelper.textStyle(
                      context,
                      fontSize: ResponsiveHelper.fontSize(context, mobile: 11, tablet: 12, desktop: 13),
                      color: Colors.grey[600],
                    ),
                    maxLines: 1,
                    overflow: TextOverflow.ellipsis,
                  ),
                ],
              ),
            ),
            if (trailing != null)
              Container(
                padding: ResponsiveHelper.padding(
                  context,
                  horizontal: ResponsiveHelper.isMobile(context) ? 10 : 12,
                  vertical: ResponsiveHelper.isMobile(context) ? 5 : 6,
                ),
                decoration: BoxDecoration(
                  color: const Color(0xFF5F4628).withOpacity(0.1),
                  borderRadius: BorderRadius.circular(ResponsiveHelper.borderRadius(context, mobile: 8)),
                ),
                child: Text(
                  trailing,
                  style: ResponsiveHelper.textStyle(
                    context,
                    fontSize: ResponsiveHelper.fontSize(context, mobile: 11, tablet: 12, desktop: 13),
                    fontWeight: FontWeight.bold,
                    color: const Color(0xFF5F4628),
                  ),
                ),
              ),
            SizedBox(width: ResponsiveHelper.spacing(context, ResponsiveHelper.isMobile(context) ? 6 : 8)),
            Icon(
              Icons.arrow_forward_ios,
              size: ResponsiveHelper.iconSize(context, mobile: 14, tablet: 16, desktop: 18),
              color: Colors.grey[400],
            ),
          ],
        ),
      ),
    );
  }

  void _showLanguageSelector(BuildContext context) {
    final currentLocale = context.locale;
    
    showModalBottomSheet(
      context: context,
      backgroundColor: Colors.transparent,
      builder: (context) => Container(
        decoration: BoxDecoration(
          color: Colors.white,
          borderRadius: BorderRadius.vertical(
            top: Radius.circular(ResponsiveHelper.borderRadius(context, mobile: 20)),
          ),
        ),
        padding: ResponsiveHelper.padding(
          context,
          all: ResponsiveHelper.isMobile(context) ? 16 : 20,
        ),
        child: Column(
          mainAxisSize: MainAxisSize.min,
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text(
              'Select Language',
              style: ResponsiveHelper.textStyle(
                context,
                fontSize: ResponsiveHelper.fontSize(context, mobile: 18, tablet: 20, desktop: 22),
                fontWeight: FontWeight.bold,
                color: const Color(0xFF5F4628),
              ),
            ),
            SizedBox(height: ResponsiveHelper.spacing(context, ResponsiveHelper.isMobile(context) ? 16 : 20)),
            _buildLanguageOption(
              context,
              'English',
              'EN',
              currentLocale.languageCode == 'en',
              () async {
                await EasyLocalization.of(context)!.setLocale(const Locale('en'));
                if (context.mounted) {
                  Navigator.pop(context);
                  Get.forceAppUpdate();
                  await Future.delayed(const Duration(milliseconds: 100));
                  Get.snackbar(
                    'Language Changed',
                    'App language changed to English',
                    snackPosition: SnackPosition.BOTTOM,
                    backgroundColor: Colors.green.withOpacity(0.8),
                    colorText: Colors.white,
                    duration: Duration(seconds: 2),
                  );
                }
              },
            ),
                SizedBox(height: ResponsiveHelper.spacing(context, 12)),
            _buildLanguageOption(
              context,
              'Spanish (Español)',
              'ES',
              currentLocale.languageCode == 'es',
              () async {
                await EasyLocalization.of(context)!.setLocale(const Locale('es'));
                if (context.mounted) {
                  Navigator.pop(context);
                  Get.forceAppUpdate();
                  await Future.delayed(const Duration(milliseconds: 100));
                  Get.snackbar(
                    'Language Changed',
                    'App language changed to Spanish',
                    snackPosition: SnackPosition.BOTTOM,
                    backgroundColor: Colors.green.withOpacity(0.8),
                    colorText: Colors.white,
                    duration: Duration(seconds: 2),
                  );
                }
              },
            ),
            SizedBox(height: ResponsiveHelper.spacing(context, ResponsiveHelper.isMobile(context) ? 16 : 20)),
          ],
        ),
      ),
    );
  }

  Widget _buildLanguageOption(
    BuildContext context,
    String title,
    String code,
    bool isSelected,
    VoidCallback onTap,
  ) {
    return InkWell(
      onTap: onTap,
      borderRadius: BorderRadius.circular(ResponsiveHelper.borderRadius(context, mobile: 12)),
      child: Container(
        padding: ResponsiveHelper.padding(
          context,
          all: ResponsiveHelper.isMobile(context) ? 14 : 16,
        ),
        decoration: BoxDecoration(
          color: isSelected
              ? const Color(0xFF5F4628).withOpacity(0.1)
              : Colors.grey.withOpacity(0.05),
          borderRadius: BorderRadius.circular(ResponsiveHelper.borderRadius(context, mobile: 12)),
          border: Border.all(
            color: isSelected
                ? const Color(0xFF5F4628)
                : Colors.transparent,
            width: ResponsiveHelper.isMobile(context) ? 1.5 : 2,
          ),
        ),
        child: Row(
          children: [
            Container(
              padding: ResponsiveHelper.padding(
                context,
                all: ResponsiveHelper.isMobile(context) ? 6 : 8,
              ),
              decoration: BoxDecoration(
                color: const Color(0xFF5F4628).withOpacity(0.1),
                borderRadius: BorderRadius.circular(ResponsiveHelper.borderRadius(context, mobile: 8)),
              ),
              child: Icon(
                Icons.language,
                color: const Color(0xFF5F4628),
                size: ResponsiveHelper.iconSize(context, mobile: 18, tablet: 20, desktop: 22),
              ),
            ),
            SizedBox(width: ResponsiveHelper.spacing(context, ResponsiveHelper.isMobile(context) ? 14 : 16)),
            Expanded(
              child: Text(
                title,
                style: ResponsiveHelper.textStyle(
                  context,
                  fontSize: ResponsiveHelper.fontSize(context, mobile: 15, tablet: 16, desktop: 17),
                  fontWeight: FontWeight.w500,
                  color: const Color(0xFF5F4628),
                ),
                maxLines: 1,
                overflow: TextOverflow.ellipsis,
              ),
            ),
            if (isSelected)
              Icon(
                Icons.check_circle,
                color: Colors.green,
                size: ResponsiveHelper.iconSize(context, mobile: 22, tablet: 24, desktop: 26),
              ),
          ],
        ),
      ),
    );
  }
}

