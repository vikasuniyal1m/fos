import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:fruitsofspirit/controllers/shorts_controller.dart';
import 'package:fruitsofspirit/services/emojis_service.dart';
import 'package:fruitsofspirit/services/sticker_service.dart';
import 'package:fruitsofspirit/services/user_storage.dart';
import 'package:fruitsofspirit/utils/sticker_emoji_helper.dart';
import 'package:fruitsofspirit/utils/responsive_helper.dart';

/// Instagram-style comments bottom sheet for Shorts
class ShortCommentsSheet extends StatefulWidget {
  final int shortId;
  final int feedIndex;
  final ShortsController controller;

  const ShortCommentsSheet({
    Key? key,
    required this.shortId,
    required this.feedIndex,
    required this.controller,
  }) : super(key: key);

  @override
  State<ShortCommentsSheet> createState() => _ShortCommentsSheetState();
}

class _ShortCommentsSheetState extends State<ShortCommentsSheet> {
  final _textController = TextEditingController();
  var _emojis = <Map<String, dynamic>>[];
  var _stickers = <Sticker>[];
  var _isSending = false;

  @override
  void initState() {
    super.initState();
    widget.controller.loadComments(widget.shortId);
    _loadPickerData();
  }

  Future<void> _loadPickerData() async {
    try {
      final emojis = await EmojisService.getPickerEmojis();
      final userId = await UserStorage.getUserId() ?? 0;
      var stickers = StickerService.getPickerStickersSync() ?? <Sticker>[];
      if (stickers.isEmpty && userId > 0) {
        stickers = await StickerService.getPickerStickers(userId);
      }
      if (mounted) {
        setState(() {
          _emojis = emojis.take(30).toList();
          _stickers = stickers.take(20).toList();
        });
      }
    } catch (_) {}
  }

  Future<void> _sendComment() async {
    final text = _textController.text.trim();
    if (text.isEmpty || _isSending) return;
    setState(() => _isSending = true);
    final ok = await widget.controller.addComment(
      widget.shortId,
      text,
      widget.feedIndex,
    );
    if (ok) _textController.clear();
    if (mounted) setState(() => _isSending = false);
  }

  void _appendToComment(String value) {
    _textController.text = '${_textController.text}$value';
    _textController.selection = TextSelection.fromPosition(
      TextPosition(offset: _textController.text.length),
    );
  }

  @override
  void dispose() {
    _textController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final height = MediaQuery.of(context).size.height * 0.75;

    return Container(
      height: height,
      decoration: const BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.vertical(top: Radius.circular(16)),
      ),
      child: Column(
        children: [
          Container(
            margin: const EdgeInsets.only(top: 8),
            width: 40,
            height: 4,
            decoration: BoxDecoration(
              color: Colors.grey.shade300,
              borderRadius: BorderRadius.circular(2),
            ),
          ),
          Padding(
            padding: const EdgeInsets.all(16),
            child: Text(
              'Comments',
              style: ResponsiveHelper.textStyle(context, fontSize: 18, fontWeight: FontWeight.bold),
            ),
          ),
          const Divider(height: 1),
          Expanded(
            child: Obx(() {
              final list = widget.controller.comments;
              if (list.isEmpty) {
                return const Center(child: Text('No comments yet'));
              }
              return ListView.builder(
                padding: const EdgeInsets.symmetric(horizontal: 16),
                itemCount: list.length,
                itemBuilder: (context, i) {
                  final c = list[i];
                  return ListTile(
                    contentPadding: EdgeInsets.zero,
                    leading: CircleAvatar(
                      child: Text((c['user_name']?.toString() ?? 'U')[0].toUpperCase()),
                    ),
                    title: Text(c['user_name']?.toString() ?? 'User'),
                    subtitle: Text(c['comment']?.toString() ?? ''),
                  );
                },
              );
            }),
          ),
          if (_stickers.isNotEmpty) ...[
            const Divider(height: 1),
            SizedBox(
              height: 56,
              child: ListView.builder(
                scrollDirection: Axis.horizontal,
                padding: const EdgeInsets.symmetric(horizontal: 8),
                itemCount: _stickers.length,
                itemBuilder: (context, i) {
                  final sticker = _stickers[i];
                  return GestureDetector(
                    onTap: () => _appendToComment(sticker.emojiCode),
                    child: Padding(
                      padding: const EdgeInsets.all(4),
                      child: StickerEmojiHelper.buildStickerWidget(sticker.emojiCode, size: 40),
                    ),
                  );
                },
              ),
            ),
          ],
          if (_emojis.isNotEmpty) ...[
            const Divider(height: 1),
            SizedBox(
              height: 44,
              child: ListView.builder(
                scrollDirection: Axis.horizontal,
                padding: const EdgeInsets.symmetric(horizontal: 8),
                itemCount: _emojis.length,
                itemBuilder: (context, i) {
                  final emoji = _emojis[i]['emoji']?.toString() ?? '❤️';
                  return IconButton(
                    icon: Text(emoji, style: const TextStyle(fontSize: 24)),
                    onPressed: () => _appendToComment(emoji),
                  );
                },
              ),
            ),
          ],
          const Divider(height: 1),
          SafeArea(
            top: false,
            child: Padding(
              padding: const EdgeInsets.all(12),
              child: Row(
                children: [
                  Expanded(
                    child: TextField(
                      controller: _textController,
                      decoration: InputDecoration(
                        hintText: 'Add a comment...',
                        border: OutlineInputBorder(borderRadius: BorderRadius.circular(24)),
                        contentPadding: const EdgeInsets.symmetric(horizontal: 16, vertical: 8),
                      ),
                    ),
                  ),
                  const SizedBox(width: 8),
                  IconButton(
                    onPressed: _isSending ? null : _sendComment,
                    icon: _isSending
                        ? const SizedBox(width: 20, height: 20, child: CircularProgressIndicator(strokeWidth: 2))
                        : const Icon(Icons.send, color: Color(0xFFD4AF37)),
                  ),
                ],
              ),
            ),
          ),
        ],
      ),
    );
  }
}
