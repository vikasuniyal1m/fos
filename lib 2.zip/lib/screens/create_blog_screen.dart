import 'package:fruitsofspirit/routes/routes.dart';
import 'package:image_cropper/image_cropper.dart';
import 'dart:io';
import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:image_picker/image_picker.dart';
import 'package:fruitsofspirit/controllers/blogs_controller.dart';
import 'package:fruitsofspirit/utils/responsive_helper.dart';
import 'package:fruitsofspirit/utils/app_theme.dart';
import 'package:fruitsofspirit/widgets/standard_app_bar.dart';
import '../controllers/main_dashboard_controller.dart';
import '../services/terms_service.dart';
import '../services/user_storage.dart' as us;
import 'terms_acceptance_screen.dart';
import 'package:fruitsofspirit/utils/role_access_helper.dart';

/// Create Blog Screen (Bloggers Only)
class CreateBlogScreen extends StatefulWidget {
  const CreateBlogScreen({Key? key}) : super(key: key);

  @override
  State<CreateBlogScreen> createState() => _CreateBlogScreenState();
}

class _CreateBlogScreenState extends State<CreateBlogScreen> {
  final BlogsController controller = Get.find<BlogsController>();
  final TextEditingController titleController = TextEditingController();
  final TextEditingController bodyController = TextEditingController();
  
  // Initialize pickers once in state
  final ImagePicker _picker = ImagePicker();
  final ImageCropper _cropper = ImageCropper();
  
  File? selectedImage;
  String selectedCategory = 'Spiritual';
  String selectedLanguage = 'en';
  Map<String, dynamic>? _userData;
  bool _isLoadingUserData = true;
  
  @override
  void initState() {
    super.initState();
    // Add listener to update character count
    bodyController.addListener(() {
      setState(() {});
    });
    // Check user access
    _checkUserAccess();
  }

  Future<void> _checkUserAccess() async {
    setState(() {
      _isLoadingUserData = true;
    });
    
    try {
      final userData = await RoleAccessHelper.getCurrentUserData();
      setState(() {
        _userData = userData;
        _isLoadingUserData = false;
      });
      
      // Check if user can create blogs
      if (!(await RoleAccessHelper.canCreateBlog())) {
        WidgetsBinding.instance.addPostFrameCallback((_) {
          if (mounted) {
            _showAccessDeniedDialog();
          }
        });
      }
    } catch (e) {
      setState(() {
        _isLoadingUserData = false;
      });
    }
  }

  void _showAccessDeniedDialog() {
    showDialog(
      context: context,
      barrierDismissible: false,
      builder: (BuildContext context) {
        return AlertDialog(
          title: const Text(
            '📝 Access Restricted',
            style: TextStyle(
              fontSize: 18,
              fontWeight: FontWeight.bold,
            ),
          ),
          content: Column(
            mainAxisSize: MainAxisSize.min,
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              const Text(
                'Creating blogs is only available for approved Blogger users.',
                style: TextStyle(
                  fontSize: 16,
                  fontWeight: FontWeight.w600,
                ),
              ),
              const SizedBox(height: 12),
              Container(
                padding: const EdgeInsets.all(12),
                decoration: BoxDecoration(
                  color: Colors.blue.withOpacity(0.1),
                  borderRadius: BorderRadius.circular(8),
                  border: Border.all(color: Colors.blue.withOpacity(0.3)),
                ),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(
                      'Current Status: ${RoleAccessHelper.getRoleDisplayText(_userData)}',
                      style: const TextStyle(
                        fontSize: 14,
                        fontWeight: FontWeight.w600,
                        color: Colors.blue,
                      ),
                    ),
                    const SizedBox(height: 8),
                    if (RoleAccessHelper.isPendingBlogger(_userData))
                      const Text(
                        'Your Blogger account is pending admin approval. You will be able to create blogs once approved.',
                        style: TextStyle(
                          fontSize: 12,
                          color: Colors.grey,
                        ),
                      ),
                  ],
                ),
              ),
            ],
          ),
          actions: [
            TextButton(
              onPressed: () {
                Navigator.of(context).pop();
                Get.offAllNamed(Routes.DASHBOARD);
              },
              child: const Text(
                'Go to Dashboard',
                style: TextStyle(
                  color: AppTheme.iconscolor,
                  fontWeight: FontWeight.bold,
                ),
              ),
            ),
          ],
        );
      },
    );
  }

  @override
  void dispose() {
    titleController.dispose();
    bodyController.dispose();
    super.dispose();
  }

  Future<void> _pickImage() async {
    // Open gallery first - this is the critical part that needs to be fast
    final pickedFile = await _picker.pickImage(source: ImageSource.gallery);

    if (pickedFile != null) {
      // Only initialize cropper if we have an image - reduces initial delay
      final croppedFile = await _cropper.cropImage(
        sourcePath: pickedFile.path,
        // Simplified UI settings to essential options only
        uiSettings: [
          AndroidUiSettings(
            toolbarTitle: 'Crop Image',
            toolbarColor: AppTheme.iconscolor,
            toolbarWidgetColor: Colors.white,
            initAspectRatio: CropAspectRatioPreset.original,
            lockAspectRatio: false,
            // Removed unnecessary settings
          ),
          IOSUiSettings(
            title: 'Crop Image',
            aspectRatioLockEnabled: false,
            doneButtonTitle: 'Done',
            cancelButtonTitle: 'Cancel',
            // Removed unnecessary settings
          ),
        ],
      );

      if (croppedFile != null) {
        setState(() {
          selectedImage = File(croppedFile.path);
        });
      }
    }
  }

  void _removeImage() {
    setState(() {
      selectedImage = null;
    });
  }

  /// Show a custom snackbar using ScaffoldMessenger
  void _showCustomSnackbar(BuildContext context, String title, String message, {bool isError = false, Color? backgroundColor, Color? textColor, Icon? icon, Duration? duration}) {
    if (!mounted) return;
    ScaffoldMessenger.of(context).hideCurrentSnackBar();
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(
        content: Row(
          children: [
            if (icon != null)
              Padding(
                padding: const EdgeInsets.only(right: 12),
                child: icon,
              ),
            Expanded(
              child: Column(
                mainAxisSize: MainAxisSize.min,
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(title, style: TextStyle(fontWeight: FontWeight.bold, color: textColor ?? Colors.white)),
                  Text(message, style: TextStyle(color: textColor ?? Colors.white)),
                ],
              ),
            ),
          ],
        ),
        backgroundColor: backgroundColor ?? (isError ? Colors.red : AppTheme.iconscolor),
        duration: duration ?? const Duration(seconds: 3),
        behavior: SnackBarBehavior.floating,
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
        margin: const EdgeInsets.all(16),
      ),
    );
  }

  Future<void> _submitBlog() async {
    print('[_submitBlog] function called.');

    // Check for terms acceptance
    final hasAcceptedFactors = await TermsService.hasAcceptedTerms();
    if (!hasAcceptedFactors) {
      Get.to(() => TermsAcceptanceScreen(
        onAccepted: () {
          Get.back(); // Pop the terms screen
          _submitBlog(); // Retry submission
        },
      ));
      return;
    }
    // Validation
    if (titleController.text.trim().isEmpty) {
      _showCustomSnackbar(
        context,
        'Suggestion',
        'Please enter blog title',
        backgroundColor: Colors.orange.shade300,
        textColor: Colors.black,
      );
      return;
    }

    if (bodyController.text.trim().isEmpty) {
      _showCustomSnackbar(
        context,
        'Suggestion',
        'Please enter blog content',
        backgroundColor: Colors.orange.shade300,
        textColor: Colors.black,
      );
      return;
    }

    if (bodyController.text.trim().length < 50) {
      _showCustomSnackbar(
        context,
        'Suggestion',
        'Blog content must be at least 50 characters long.',
        backgroundColor: Colors.orange.shade300,
        textColor: Colors.black,
      );
      return;
    }

    final success = await controller.createBlog(
      title: titleController.text.trim(),
      body: bodyController.text.trim(),
      category: selectedCategory,
      language: selectedLanguage,
      image: selectedImage,
    );

  if (success) {
      print('Blog creation successful. Mounted: $mounted');

      // Show success message
      if (mounted) {
        _showCustomSnackbar(
          context,
          'Success',
          controller.message.value.isNotEmpty
              ? controller.message.value
              : 'Blog created successfully! Waiting for approval.',
          backgroundColor: AppTheme.iconscolor,
          textColor: Colors.black,
          duration: const Duration(seconds: 2),
          icon: const Icon(Icons.check_circle, color: Colors.white),
        );
      }
      
      // Update Dashboard Tab if available
      if (Get.isRegistered<MainDashboardController>()) {
        try {
          Get.find<MainDashboardController>().changeIndex(0); // Switch to Home tab
        } catch (e) {
          print('Error changing dashboard index: $e');
        }
      }
      
      // Wait briefly for snackbar
      await Future.delayed(const Duration(milliseconds: 1500));
      
      // STRONG NAVIGATION: Clear stack until Dashboard
      Get.offNamedUntil(Routes.DASHBOARD, (route) => false);
    } 
    else {
      print('Blog creation failed.');
      // Show error message
      if (mounted) {
        WidgetsBinding.instance.addPostFrameCallback((_) {
          if (mounted) {
            final errorMsg = controller.message.value;
            final isModeration = errorMsg.contains('community guidelines');

            _showCustomSnackbar(
              context,
              isModeration ? 'Community Standard' : 'Community Suggestion',
              errorMsg.isNotEmpty 
                  ? errorMsg 
                  : 'Action could not be completed. Please try again.',
              backgroundColor: isModeration ? const Color(0xFF5D4037) : Colors.orange.shade300,
              textColor: isModeration ? Colors.white : Colors.black,
              icon: Icon(
                isModeration ? Icons.security_rounded : Icons.tips_and_updates_outlined,
                color: isModeration ? const Color(0xFFC79211) : Colors.black,
                size: 28,
              ),
            );
          }
        });
      }
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: AppTheme.themeColor, // Match other pages - beige background
      appBar: PreferredSize(
        preferredSize: Size.fromHeight(
          ResponsiveHelper.appBarHeight(context),
        ),
        child: AppBar(
          backgroundColor: Colors.white,
          elevation: 0,
          leading: Container(
            margin: EdgeInsets.all(ResponsiveHelper.spacing(context, 8)),
            decoration: BoxDecoration(
              color: Colors.grey[100],
              shape: BoxShape.circle,
            ),
            child: IconButton(
              icon: Icon(
                Icons.arrow_back,
                color: AppTheme.iconscolor,
                size: ResponsiveHelper.iconSize(context, mobile: 24, tablet: 28, desktop: 32),
              ),
              onPressed: () => Get.back(),
            ),
          ),
          title: Text(
            'Create New Blog',
            style: ResponsiveHelper.textStyle(
              context,
              fontSize: ResponsiveHelper.fontSize(context, mobile: 18, tablet: 20, desktop: 22),
              fontWeight: FontWeight.bold,
              color: AppTheme.textPrimary,
            ),
          ),
          centerTitle: true,
        ),
      ),
      body: Obx(() {
        if (controller.userRole.value != 'Blogger') {
          return Center(
            child: Padding(
              padding: ResponsiveHelper.padding(context, all: 32),
              child: Column(
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  Container(
                    padding: ResponsiveHelper.padding(context, all: 24),
                    decoration: BoxDecoration(
                      color: Colors.grey[200],
                      shape: BoxShape.circle,
                    ),
                    child: Icon(
                      Icons.lock_outline_rounded,
                      size: ResponsiveHelper.iconSize(context, mobile: 64, tablet: 72, desktop: 80),
                      color: Colors.grey[600],
                    ),
                  ),
                  SizedBox(height: ResponsiveHelper.spacing(context, 24)),
                  Text(
                    'Blogger Access Required',
                    style: ResponsiveHelper.textStyle(
                      context,
                      fontSize: ResponsiveHelper.fontSize(context, mobile: 22, tablet: 24, desktop: 26),
                      fontWeight: FontWeight.bold,
                      color: AppTheme.textPrimary,
                    ),
                  ),
                  SizedBox(height: ResponsiveHelper.spacing(context, 12)),
                  Text(
                    'Only approved bloggers can create and publish blog posts.',
                    textAlign: TextAlign.center,
                    style: ResponsiveHelper.textStyle(
                      context,
                      fontSize: ResponsiveHelper.fontSize(context, mobile: 16, tablet: 17, desktop: 18),
                      color: Colors.grey[700],
                    ),
                  ),
                ],
              ),
            ),
          );
        }

        return SingleChildScrollView(
          padding: ResponsiveHelper.padding(context, all: 20),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              // Image Selection Section
              Text(
                'Blog Image',
                style: ResponsiveHelper.textStyle(
                  context,
                  fontSize: ResponsiveHelper.fontSize(context, mobile: 18, tablet: 19, desktop: 20),
                  fontWeight: FontWeight.bold,
                  color: AppTheme.textPrimary,
                ),
              ),
              SizedBox(height: ResponsiveHelper.spacing(context, 8)),
              Text(
                'Add a cover image for your blog (Optional)',
                style: ResponsiveHelper.textStyle(
                  context,
                  fontSize: ResponsiveHelper.fontSize(context, mobile: 14, tablet: 15, desktop: 16),
                  color: Colors.grey[600],
                ),
              ),
              SizedBox(height: ResponsiveHelper.spacing(context, 12)),
              GestureDetector(
                onTap: _pickImage,
                child: Container(
                  height: ResponsiveHelper.imageHeight(context, mobile: 220, tablet: 250, desktop: 280),
                  width: double.infinity,
                  decoration: BoxDecoration(
                    color: Colors.white,
                    borderRadius: BorderRadius.circular(ResponsiveHelper.borderRadius(context, mobile: 16)),
                    border: Border.all(
                      color: AppTheme.iconscolor.withOpacity(0.2),
                      width: 2,
                    ),
                    boxShadow: [
                      BoxShadow(
                        color: Colors.black.withOpacity(0.05),
                        blurRadius: 10,
                        offset: const Offset(0, 4),
                      ),
                    ],
                  ),
                  child: selectedImage == null
                      ? Column(
                          mainAxisAlignment: MainAxisAlignment.center,
                          children: [
                            Icon(
                              Icons.add_photo_alternate_rounded,
                              size: ResponsiveHelper.iconSize(context, mobile: 56, tablet: 64, desktop: 72),
                              color: AppTheme.iconscolor,
                            ),
                            SizedBox(height: ResponsiveHelper.spacing(context, 12)),
                            Text(
                              'Tap to select image',
                              style: ResponsiveHelper.textStyle(
                                context,
                                fontSize: ResponsiveHelper.fontSize(context, mobile: 16, tablet: 17, desktop: 18),
                                color: AppTheme.textPrimary,
                                fontWeight: FontWeight.w500,
                              ),
                            ),
                            SizedBox(height: ResponsiveHelper.spacing(context, 4)),
                            Text(
                              'JPG, PNG, GIF (Max 5MB)',
                              style: ResponsiveHelper.textStyle(
                                context,
                                fontSize: ResponsiveHelper.fontSize(context, mobile: 12, tablet: 13, desktop: 14),
                                color: Colors.grey[600],
                              ),
                            ),
                          ],
                        )
                      : Stack(
                          children: [
                            ClipRRect(
                              borderRadius: BorderRadius.circular(ResponsiveHelper.borderRadius(context, mobile: 16)),
                              child: Image.file(
                                selectedImage!,
                                fit: BoxFit.contain,
                                width: double.infinity,
                                height: double.infinity,
                              ),
                            ),
                            Positioned(
                              top: ResponsiveHelper.spacing(context, 8),
                              right: ResponsiveHelper.spacing(context, 8),
                              child: Container(
                                decoration: BoxDecoration(
                                  color: Colors.red,
                                  shape: BoxShape.circle,
                                  boxShadow: [
                                    BoxShadow(
                                      color: Colors.black.withOpacity(0.3),
                                      blurRadius: 8,
                                      offset: const Offset(0, 2),
                                    ),
                                  ],
                                ),
                                child: IconButton(
                                  icon: Icon(
                                    Icons.close_rounded,
                                    color: Colors.white,
                                    size: ResponsiveHelper.iconSize(context, mobile: 20),
                                  ),
                                  onPressed: _removeImage,
                                ),
                              ),
                            ),
                          ],
                        ),
                ),
              ),
              SizedBox(height: ResponsiveHelper.spacing(context, 32)),

              // Title Section
              Text(
                'Title *',
                style: ResponsiveHelper.textStyle(
                  context,
                  fontSize: ResponsiveHelper.fontSize(context, mobile: 18, tablet: 19, desktop: 20),
                  fontWeight: FontWeight.bold,
                  color: AppTheme.textPrimary,
                ),
              ),
              SizedBox(height: ResponsiveHelper.spacing(context, 8)),
              TextField(
                controller: titleController,
                style: ResponsiveHelper.textStyle(
                  context,
                  fontSize: ResponsiveHelper.fontSize(context, mobile: 16, tablet: 17, desktop: 18),
                  color: AppTheme.textPrimary,
                ),
                decoration: InputDecoration(
                  hintText: 'Enter a compelling title for your blog',
                  hintStyle: ResponsiveHelper.textStyle(
                    context,
                    fontSize: ResponsiveHelper.fontSize(context, mobile: 14, tablet: 15, desktop: 16),
                    color: Colors.grey[500],
                  ),
                  border: OutlineInputBorder(
                    borderRadius: BorderRadius.circular(ResponsiveHelper.borderRadius(context, mobile: 12)),
                    borderSide: BorderSide(color: Colors.grey.withOpacity(0.3), width: 1.5),
                  ),
                  enabledBorder: OutlineInputBorder(
                    borderRadius: BorderRadius.circular(ResponsiveHelper.borderRadius(context, mobile: 12)),
                    borderSide: BorderSide(color: Colors.grey.withOpacity(0.3), width: 1.5),
                  ),
                  focusedBorder: OutlineInputBorder(
                    borderRadius: BorderRadius.circular(ResponsiveHelper.borderRadius(context, mobile: 12)),
                    borderSide: BorderSide(color: AppTheme.iconscolor, width: 2.5),
                  ),
                  filled: true,
                  fillColor: Colors.white,
                  contentPadding: ResponsiveHelper.padding(context, all: 16),
                ),
                maxLength: 200,
                textInputAction: TextInputAction.done,
                onSubmitted: (_) {
                  // Dismiss keyboard when Done is pressed
                  FocusManager.instance.primaryFocus?.unfocus();
                },
              ),
              SizedBox(height: ResponsiveHelper.spacing(context, 24)),

              // Category and Language Row
              Row(
                children: [
                  // Category
                  Expanded(
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Text(
                          'Category *',
                          style: ResponsiveHelper.textStyle(
                            context,
                            fontSize: ResponsiveHelper.fontSize(context, mobile: 18, tablet: 19, desktop: 20),
                            fontWeight: FontWeight.bold,
                            color: AppTheme.textPrimary,
                          ),
                        ),
                        SizedBox(height: ResponsiveHelper.spacing(context, 8)),
                        Container(
                          decoration: BoxDecoration(
                            color: Colors.white,
                            borderRadius: BorderRadius.circular(ResponsiveHelper.borderRadius(context, mobile: 12)),
                            border: Border.all(
                              color: Colors.grey.withOpacity(0.3),
                              width: 1.5,
                            ),
                          ),
                          child: DropdownButtonFormField<String>(
                            isExpanded: true,
                            value: selectedCategory,
                            decoration: InputDecoration(
                              border: InputBorder.none,
                              contentPadding: ResponsiveHelper.padding(context, horizontal: 16, vertical: 12),
                            ),
                            style: ResponsiveHelper.textStyle(
                              context,
                              fontSize: ResponsiveHelper.fontSize(context, mobile: 16, tablet: 17, desktop: 18),
                              color: AppTheme.textPrimary,
                            ),
                            items: ['Spiritual', 'Encouragement', 'Testimony', 'Teaching', 'Other']
                                .map((cat) => DropdownMenuItem(
                                      value: cat,
                                      child: Text(cat),
                                    ))
                                .toList(),
                            onChanged: (value) {
                              setState(() {
                                selectedCategory = value!;
                              });
                            },
                          ),
                        ),
                      ],
                    ),
                  ),
                  SizedBox(width: ResponsiveHelper.spacing(context, 16)),
                  // Language
                  Expanded(
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Text(
                          'Language *',
                          style: ResponsiveHelper.textStyle(
                            context,
                            fontSize: ResponsiveHelper.fontSize(context, mobile: 18, tablet: 19, desktop: 20),
                            fontWeight: FontWeight.bold,
                            color: AppTheme.textPrimary,
                          ),
                        ),
                        SizedBox(height: ResponsiveHelper.spacing(context, 8)),
                        Container(
                          decoration: BoxDecoration(
                            color: Colors.white,
                            borderRadius: BorderRadius.circular(ResponsiveHelper.borderRadius(context, mobile: 12)),
                            border: Border.all(
                              color: Colors.grey.withOpacity(0.3),
                              width: 1.5,
                            ),
                          ),
                          child: DropdownButtonFormField<String>(
                            isExpanded: true,
                            value: selectedLanguage,
                            decoration: InputDecoration(
                              border: InputBorder.none,
                              contentPadding: ResponsiveHelper.padding(context, horizontal: 16, vertical: 12),
                            ),
                            style: ResponsiveHelper.textStyle(
                              context,
                              fontSize: ResponsiveHelper.fontSize(context, mobile: 16, tablet: 17, desktop: 18),
                              color: AppTheme.textPrimary,
                            ),
                            items: [
                              DropdownMenuItem(value: 'en', child: Text('English')),
                              DropdownMenuItem(value: 'es', child: Text('Spanish')),
                              DropdownMenuItem(value: 'fr', child: Text('French')),
                              DropdownMenuItem(value: 'hi', child: Text('Hindi')),
                              DropdownMenuItem(value: 'ar', child: Text('Arabic')),
                            ],
                            onChanged: (value) {
                              setState(() {
                                selectedLanguage = value!;
                              });
                            },
                          ),
                        ),
                      ],
                    ),
                  ),
                ],
              ),
              SizedBox(height: ResponsiveHelper.spacing(context, 24)),

              // Content Section
              Text(
                'Content *',
                style: ResponsiveHelper.textStyle(
                  context,
                  fontSize: ResponsiveHelper.fontSize(context, mobile: 18, tablet: 19, desktop: 20),
                  fontWeight: FontWeight.bold,
                  color: AppTheme.textPrimary,
                ),
              ),
              SizedBox(height: ResponsiveHelper.spacing(context, 8)),
              Text(
                'Write your blog content (Minimum 50 characters)',
                style: ResponsiveHelper.textStyle(
                  context,
                  fontSize: ResponsiveHelper.fontSize(context, mobile: 14, tablet: 15, desktop: 16),
                  color: Colors.grey[600],
                ),
              ),
              SizedBox(height: ResponsiveHelper.spacing(context, 12)),
              TextField(
                controller: bodyController,
                maxLines: 12,
                style: ResponsiveHelper.textStyle(
                  context,
                  fontSize: ResponsiveHelper.fontSize(context, mobile: 16, tablet: 17, desktop: 18),
                  color: AppTheme.textPrimary,
                  height: 1.6,
                ),
                decoration: InputDecoration(
                  hintText: 'Share your thoughts, experiences, and insights...',
                  hintStyle: ResponsiveHelper.textStyle(
                    context,
                    fontSize: ResponsiveHelper.fontSize(context, mobile: 14, tablet: 15, desktop: 16),
                    color: Colors.grey[500],
                  ),
                  border: OutlineInputBorder(
                    borderRadius: BorderRadius.circular(ResponsiveHelper.borderRadius(context, mobile: 12)),
                    borderSide: BorderSide(color: Colors.grey.withOpacity(0.3), width: 1.5),
                  ),
                  enabledBorder: OutlineInputBorder(
                    borderRadius: BorderRadius.circular(ResponsiveHelper.borderRadius(context, mobile: 12)),
                    borderSide: BorderSide(color: Colors.grey.withOpacity(0.3), width: 1.5),
                  ),
                  focusedBorder: OutlineInputBorder(
                    borderRadius: BorderRadius.circular(ResponsiveHelper.borderRadius(context, mobile: 12)),
                    borderSide: BorderSide(color: AppTheme.iconscolor, width: 2.5),
                  ),
                  filled: true,
                  fillColor: Colors.white,
                  contentPadding: ResponsiveHelper.padding(context, all: 16),
                ),
                textInputAction: TextInputAction.done,
                onSubmitted: (_) {
                  // Dismiss keyboard when Done is pressed
                  FocusManager.instance.primaryFocus?.unfocus();
                },
              ),
              SizedBox(height: ResponsiveHelper.spacing(context, 8)),
              if (bodyController.text.trim().length < 50)
                Text(
                  'Minimum 50 characters required',
                  style: ResponsiveHelper.textStyle(
                    context,
                    fontSize: ResponsiveHelper.fontSize(context, mobile: 12, tablet: 13, desktop: 14),
                    color: AppTheme.iconscolor, // Changed to theme color for suggestion
                  ),
                ),
              SizedBox(height: ResponsiveHelper.spacing(context, 32)),

              // Submit Button
              SizedBox(
                width: double.infinity,
                height: ResponsiveHelper.buttonHeight(context, mobile: 56, tablet: 60, desktop: 64),
                child: ElevatedButton(
                  onPressed: controller.isLoading.value ? null : _submitBlog,
                  style: ElevatedButton.styleFrom(
                    backgroundColor: AppTheme.iconscolor,
                    elevation: 6,
                    shadowColor: AppTheme.iconscolor.withOpacity(0.4),
                    shape: RoundedRectangleBorder(
                      borderRadius: BorderRadius.circular(ResponsiveHelper.borderRadius(context, mobile: 16)),
                    ),
                  ),
                  child: controller.isLoading.value
                      ? SizedBox(
                          height: ResponsiveHelper.iconSize(context, mobile: 24),
                          width: ResponsiveHelper.iconSize(context, mobile: 24),
                          child: const CircularProgressIndicator(
                            color: Colors.white,
                            strokeWidth: 2.5,
                          ),
                        )
                      : Row(
                          mainAxisAlignment: MainAxisAlignment.center,
                          children: [
                            Icon(
                              Icons.publish_rounded,
                              color: Colors.white,
                              size: ResponsiveHelper.iconSize(context, mobile: 22, tablet: 24, desktop: 26),
                            ),
                            SizedBox(width: ResponsiveHelper.spacing(context, 8)),
                            Text(
                              'Publish Blog',
                              style: ResponsiveHelper.textStyle(
                                context,
                                fontSize: ResponsiveHelper.fontSize(context, mobile: 18, tablet: 19, desktop: 20),
                                fontWeight: FontWeight.bold,
                                color: Colors.white,
                              ),
                            ),
                          ],
                        ),
                ),
              ),
              SizedBox(height: ResponsiveHelper.spacing(context, 16)),
              Center(
                child: Text(
                  'Your blog will be reviewed by admin before publishing',
                  textAlign: TextAlign.center,
                  style: ResponsiveHelper.textStyle(
                    context,
                    fontSize: ResponsiveHelper.fontSize(context, mobile: 12, tablet: 13, desktop: 14),
                    color: Colors.grey[600],
                  ).copyWith(fontStyle: FontStyle.italic),
                ),
              ),
            ],
          ),
        );
      }),
    );
  }
}
