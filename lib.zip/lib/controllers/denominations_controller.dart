import 'package:get/get.dart';
import '../services/denominations_service.dart';

class DenominationsController extends GetxController {
  var isLoading = true.obs;
  var denominations = <Map<String, dynamic>>[].obs;
  var filteredDenominations = <Map<String, dynamic>>[].obs;

  @override
  void onInit() {
    super.onInit();
    fetchDenominations();
  }

  void fetchDenominations() async {
    try {
      isLoading(true);
      var result = await DenominationsService.getAllDenominations();
      denominations.assignAll(result);
      filteredDenominations.assignAll(result);
    } catch (e) {
      Get.snackbar('Error', 'Failed to load denominations: $e',
          snackPosition: SnackPosition.BOTTOM);
    } finally {
      isLoading(false);
    }
  }

  void filterDenominations(String query) {
    if (query.isEmpty) {
      filteredDenominations.assignAll(denominations);
    } else {
      filteredDenominations.assignAll(denominations.where((d) =>
          d['name'].toString().toLowerCase().contains(query.toLowerCase())));
    }
  }
}
