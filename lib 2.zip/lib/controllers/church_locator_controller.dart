import 'dart:async';
import 'package:flutter/material.dart';
import 'package:flutter/widgets.dart';
import 'dart:ui' as ui;
import 'package:get/get.dart';
import 'package:google_maps_flutter/google_maps_flutter.dart';
import 'package:geolocator/geolocator.dart';
import '../config/api_config.dart';
import '../services/places_service.dart';
import 'package:url_launcher/url_launcher.dart';

class ChurchLocatorController extends GetxController {
  var isLoading = true.obs; 
  var loadingMessage = 'Finding your location...'.obs;
  var isFilterLoading = false.obs;
  final markers = <Marker>[].obs;
  final polylines = <Polyline>[].obs;
  var currentPosition = Rxn<Position>();
  var places = <Map<String, dynamic>>[].obs;
  final hqQuery = RxnString();
  final autoSearch = false.obs;
  final cameraTarget = Rxn<LatLng>();
  final locationServiceEnabled = false.obs;
  final lastPermission = Rxn<LocationPermission>();
  bool _fetchInProgress = false;
  double? _lastCameraZoom;
  final currentCity = '—'.obs;
  final currentTime = ''.obs;
  Timer? _clockTimer;
  LatLng? _lastCityCenter;
  bool _labelMode = false;
  final suggestions = <Map<String, dynamic>>[].obs;
  Timer? _searchDebounce;
  final Map<String, BitmapDescriptor> _labelIconCache = {};
  final searchController = TextEditingController();
  final routeSummary = RxnString();
  final routeSteps = <Map<String, dynamic>>[].obs;
  final allRoutesData = <Map<String, dynamic>>[].obs;
  final selectedRouteIndex = 0.obs;
  final routeLabelMarkers = <Marker>[].obs;

  final LatLng defaultLocation = const LatLng(30.7333, 76.7794);
  final selectedDenomination = RxnString();
  RxBool isBottomSheetExpanded = false.obs;
  RxDouble currentZoom = 14.0.obs;
  RxBool isMapReady = false.obs;
  GoogleMapController? mapController;

  @override
  void onInit() {
    super.onInit();
    _startClock();
  }

  @override
  void onReady() {
    super.onReady();
    _determinePosition();
    Future.delayed(const Duration(milliseconds: 500), () {
      if (places.isEmpty && !isLoading.value) {
        searchChurchesAt(defaultLocation, silent: true);
      }
    });
  }

  void toggleBottomSheet() {
    isBottomSheetExpanded.value = !isBottomSheetExpanded.value;
  }

  void zoomIn() {
    currentZoom.value = (currentZoom.value + 0.5).clamp(3.0, 20.0);
    mapController?.animateCamera(CameraUpdate.zoomIn());
  }

  void zoomOut() {
    currentZoom.value = (currentZoom.value - 0.5).clamp(3.0, 20.0);
    mapController?.animateCamera(CameraUpdate.zoomOut());
  }

  void goToMyLocation() async {
    if (currentPosition.value != null) {
      mapController?.animateCamera(CameraUpdate.newCameraPosition(
        CameraPosition(
          target: LatLng(currentPosition.value!.latitude, currentPosition.value!.longitude),
          zoom: 15.0,
        ),
      ));
    } else {
      await _determinePosition();
      if (currentPosition.value != null) {
        mapController?.animateCamera(CameraUpdate.newCameraPosition(
          CameraPosition(
            target: LatLng(currentPosition.value!.latitude, currentPosition.value!.longitude),
            zoom: 15.0,
          ),
        ));
      }
    }
  }

  void onCameraMoveStarted() {
    FocusManager.instance.primaryFocus?.unfocus();
  }

  Future<void> _determinePosition() async {
    bool serviceEnabled;
    LocationPermission permission;

    serviceEnabled = await Geolocator.isLocationServiceEnabled();
    locationServiceEnabled.value = serviceEnabled;

    if (!serviceEnabled) {
      _showSnackSafe('Location', 'Location services are off');
      isLoading(false);
      // Don't search at default location if location services are off
      return;
    }

    permission = await Geolocator.checkPermission();
    if (permission == LocationPermission.denied) {
      permission = await Geolocator.requestPermission();
      if (permission == LocationPermission.denied) {
        _showSnackSafe('Location', 'Permission denied');
        isLoading(false);
        return;
      }
    }

    if (permission == LocationPermission.deniedForever) {
      _showSnackSafe('Location', 'Permission denied forever');
      isLoading(false);
      return;
    }

    isLoading(true);
    loadingMessage.value = 'Determining your location...';

    // Try multiple times to get accurate location
    Position? pos;
    int attempts = 0;
    const maxAttempts = 3;
    
    while (attempts < maxAttempts && pos == null) {
      attempts++;
      try {
        print('DEBUG: Location fetch attempt $attempts/$maxAttempts');
        pos = await Geolocator.getCurrentPosition(
          desiredAccuracy: LocationAccuracy.high,
          timeLimit: const Duration(seconds: 15),
        ).timeout(const Duration(seconds: 20));
        
        if (pos != null) {
          print('DEBUG: Got location: ${pos.latitude}, ${pos.longitude}');
          
          // Check if this is a default/hardcoded location (San Francisco Bay Area)
          final isDefaultLocation = pos.latitude >= 37.6 && pos.latitude <= 37.9 &&
                                    pos.longitude >= -122.5 && pos.longitude <= -122.3;
          
          if (isDefaultLocation) {
            print('DEBUG: Got default SF location, rejecting');
            pos = null;
          }
        }
      } catch (e) {
        print('DEBUG: Location fetch attempt $attempts failed: $e');
        if (attempts < maxAttempts) {
          await Future.delayed(const Duration(seconds: 1));
        }
      }
    }

    // If still null after retries, try getLastKnownPosition as fallback
    if (pos == null) {
      try {
        print('DEBUG: Trying getLastKnownPosition as fallback...');
        pos = await Geolocator.getLastKnownPosition();
        if (pos != null) {
          print('DEBUG: Got last known position: ${pos.latitude}, ${pos.longitude}');
          
          // Still check if it's default location
          final isDefaultLocation = pos.latitude >= 37.6 && pos.latitude <= 37.9 &&
                                    pos.longitude >= -122.5 && pos.longitude <= -122.3;
          
          if (isDefaultLocation) {
            print('DEBUG: Last known position is also default SF location, rejecting');
            pos = null;
          }
        }
      } catch (e) {
        print('DEBUG: getLastKnownPosition failed: $e');
      }
    }

    if (pos != null) {
      currentPosition.value = pos;
      await _refreshCity(LatLng(pos.latitude, pos.longitude));
      if ((hqQuery.value == null || hqQuery.value!.isEmpty) && places.isEmpty) {
        searchChurches();
      }
    } else {
      print('DEBUG: Failed to get real location after $maxAttempts attempts');
      _showSnackSafe('Location', 'Could not determine your location');
      // Only search at default location as last resort
      if (places.isEmpty) {
        searchChurchesAt(defaultLocation, silent: true);
      }
    }
    
    isLoading(false);
  }

  void onMapCreated(GoogleMapController controller) {
    print('DEBUG: [ChurchLocator] Google Map Created successfully');
    mapController = controller;
    isMapReady.value = true;
    if (currentPosition.value != null) {
      print('DEBUG: [ChurchLocator] Animating to current position: ${currentPosition.value!.latitude}, ${currentPosition.value!.longitude}');
      mapController?.animateCamera(CameraUpdate.newCameraPosition(
        CameraPosition(
          target: LatLng(currentPosition.value!.latitude, currentPosition.value!.longitude),
          zoom: 13.0,
        ),
      ));
    } else {
      print('DEBUG: [ChurchLocator] No current position yet, map created at default');
    }
  }

  void searchChurches({bool forceGlobal = false}) async {
    if (currentPosition.value == null) {
      await searchChurchesAt(defaultLocation);
      return;
    }

    if (forceGlobal || places.isEmpty) {
      isLoading(true);
      loadingMessage.value = 'Searching for churches nearby...';
    }
    try {
      LatLng center = cameraTarget.value ?? (currentPosition.value != null 
          ? LatLng(currentPosition.value!.latitude, currentPosition.value!.longitude) 
          : defaultLocation);
      
      print('DEBUG: [ChurchLocator] Searching churches at $center with key: ${ApiConfig.googleMapsApiKey.substring(0, 8)}...');
      
      final results = await PlacesService.searchChurches(location: center, denomination: selectedDenomination.value, radius: 15000);
      print('DEBUG: [ChurchLocator] Found ${results.length} churches');

      for (var p in results) {
        final plat = p['geometry']?['location']?['lat'];
        final plng = p['geometry']?['location']?['lng'];
        if (plat != null && plng != null) {
          final d = Geolocator.distanceBetween(center.latitude, center.longitude, plat, plng);
          p['distance'] = (d / 1000).toStringAsFixed(1);
        } else {
          p['distance'] = '—';
        }
        // Extract denomination
        p['denomination'] = _parseDenomination(p['name'] ?? '');
      }

      if (results.isEmpty) {
        final defaultResults = await PlacesService.searchChurches(location: defaultLocation, denomination: selectedDenomination.value, radius: 15000);
        places.assignAll(defaultResults);
      } else {
        places.assignAll(results);
      }

      // Incremental loading: Show first 4 markers immediately, then load rest in batches
      await _loadMarkersIncrementally(places.toList());
    } catch (e) {
      _showSnackSafe('Error', 'Failed to find churches');
    } finally {
      isLoading(false);
    }
  }

  Future<void> _loadMarkersIncrementally(List<Map<String, dynamic>> allPlaces) async {
    if (allPlaces.isEmpty) return;

    // Show first 4 markers immediately
    final initialBatch = allPlaces.take(4).toList();
    markers.assignAll(await _markersFromPlaces(initialBatch));
    fitAllMarkers();
    print('DEBUG: [ChurchLocator] Loaded first ${initialBatch.length} markers quickly');

    // Load remaining markers in batches of 6 with delay for smoothness
    final remaining = allPlaces.skip(4).toList();
    for (int i = 0; i < remaining.length; i += 6) {
      final batch = remaining.skip(i).take(6).toList();
      await Future.delayed(const Duration(milliseconds: 200));
      final currentMarkers = await _markersFromPlaces(allPlaces.take(4 + i + batch.length).toList());
      markers.assignAll(currentMarkers);
      print('DEBUG: [ChurchLocator] Loaded batch ${i ~/ 6 + 1}, total markers: ${currentMarkers.length}');
    }

    print('DEBUG: [ChurchLocator] All ${allPlaces.length} markers loaded');
  }

  Future<void> searchChurchesAt(LatLng center, {bool silent = false}) async {
    if (_fetchInProgress) return;
    _fetchInProgress = true;
    if (!silent) isLoading(true);
    try {
      final results = await PlacesService.searchChurches(location: center, denomination: selectedDenomination.value, radius: 15000);
      final myPos = currentPosition.value;
      for (var p in results) {
        if (myPos != null) {
          final plat = p['geometry']?['location']?['lat'];
          final plng = p['geometry']?['location']?['lng'];
          if (plat != null && plng != null) {
            final d = Geolocator.distanceBetween(myPos.latitude, myPos.longitude, plat, plng);
            p['distance'] = (d / 1000).toStringAsFixed(1);
          } else {
            p['distance'] = '—';
          }
        } else {
          p['distance'] = '—';
        }
        p['denomination'] = _parseDenomination(p['name'] ?? '');
      }
      places.assignAll(results);

      // Use incremental loading for smooth display
      await _loadMarkersIncrementally(results);

      if (!silent && mapController != null && results.isEmpty) {
        mapController?.animateCamera(CameraUpdate.newCameraPosition(
          CameraPosition(target: center, zoom: 13.0),
        ));
      }
    } catch (e) {
      if (!silent) _showSnackSafe('Error', 'Failed to find churches');
    } finally {
      if (!silent) isLoading(false);
      _fetchInProgress = false;
    }
  }


  Future<void> searchByTextQuery(String query) async {
    isLoading(true);
    loadingMessage.value = 'Searching for "$query"...';
    try {
      final center = currentPosition.value != null
          ? LatLng(currentPosition.value!.latitude, currentPosition.value!.longitude)
          : defaultLocation;
      
      final results = await PlacesService.searchByQuery(
        query: query,
        location: center,
      );
      
      // Add distance and denomination to each result
      for (var p in results) {
        final plat = p['geometry']?['location']?['lat'];
        final plng = p['geometry']?['location']?['lng'];
        if (plat != null && plng != null && currentPosition.value != null) {
          final d = Geolocator.distanceBetween(
            currentPosition.value!.latitude,
            currentPosition.value!.longitude,
            plat,
            plng
          );
          p['distance'] = (d / 1000).toStringAsFixed(1);
        } else {
          p['distance'] = '—';
        }
        p['denomination'] = _parseDenomination(p['name'] ?? '');
      }
      
      places.assignAll(results);
      markers.assignAll(await _markersFromPlaces(results));
      
      if (results.isNotEmpty) {
        final loc = results.first['geometry']['location'];
        mapController?.animateCamera(CameraUpdate.newCameraPosition(
          CameraPosition(target: LatLng(loc['lat'], loc['lng']), zoom: 14.0),
        ));
      }
    } catch (e) {
      _showSnackSafe('Error', 'Search failed');
    } finally {
      isLoading(false);
    }
  }

  void onCameraMove(CameraPosition position) {
    cameraTarget.value = position.target;
    _lastCameraZoom = position.zoom;
    currentZoom.value = position.zoom;
    final newLabelMode = position.zoom >= 13.5;
    if (newLabelMode != _labelMode) {
      _labelMode = newLabelMode;
      _applyMarkersForCurrentPlaces();
    }
  }

  void onCameraIdle() {
    if (hqQuery.value != null && hqQuery.value!.isNotEmpty) return;
    if (cameraTarget.value != null && (_lastCityCenter == null ||
        Geolocator.distanceBetween(
          _lastCityCenter!.latitude,
          _lastCityCenter!.longitude,
          cameraTarget.value!.latitude,
          cameraTarget.value!.longitude,
        ) > 3000)) {
      _refreshCity(cameraTarget.value!);
    }
  }

  void retryLocation() {
    _determinePosition();
  }

  void _showSnackSafe(String title, String message) {
    // Controller has no BuildContext — only log here.
    // The screen layer should handle user-facing messages.
    print('ChurchLocator [$title]: $message');
  }

  void _startClock() {
    void tick() {
      final now = DateTime.now();
      final h = now.hour % 12 == 0 ? 12 : now.hour % 12;
      final m = now.minute.toString().padLeft(2, '0');
      final ap = now.hour >= 12 ? 'PM' : 'AM';
      currentTime.value = '$h:$m $ap';
    }
    tick();
    _clockTimer?.cancel();
    _clockTimer = Timer.periodic(const Duration(seconds: 30), (_) => tick());
  }

  Future<void> _refreshCity(LatLng center) async {
    _lastCityCenter = center;
    try {
      final name = await PlacesService.reverseGeocodeCity(location: center);
      currentCity.value = name;
    } catch (_) {}
  }

  @override
  void onClose() {
    _clockTimer?.cancel();
    _searchDebounce?.cancel();
    clearRoute();
    searchController.dispose();
    super.onClose();
  }

  Future<List<Marker>> _markersFromPlaces(List<Map<String, dynamic>> items) async {
    final List<Marker> list = [];
    Set<String> labelIds = {};
    final zoom = _lastCameraZoom ?? 13.0;
    
    if (_labelMode && items.isNotEmpty) {
      final center = cameraTarget.value ?? (currentPosition.value != null ? LatLng(currentPosition.value!.latitude, currentPosition.value!.longitude) : defaultLocation);
      final scored = <MapEntry<String, double>>[];
      for (final p in items) {
        final loc = p['geometry']?['location'];
        if (loc == null) continue;
        final d = Geolocator.distanceBetween(center.latitude, center.longitude, loc['lat'], loc['lng']);
        scored.add(MapEntry(p['place_id'], d));
      }
      scored.sort((a, b) => a.value.compareTo(b.value));
      int maxLabels = zoom >= 17 ? 60 : (zoom >= 16 ? 40 : (zoom >= 15 ? 25 : 15));
      labelIds = scored.take(maxLabels).map((e) => e.key).toSet();
    }

    for (final p in items) {
      final loc = p['geometry']['location'];
      final rawName = p['name'] ?? '';
      final placeId = p['place_id'];
      final shouldLabel = _labelMode && labelIds.contains(placeId);
      final displayText = shouldLabel ? _compactName(rawName) : rawName;

      BitmapDescriptor? markerIcon;
      Offset? markerAnchor;

      try {
        final iconData = await _labelIcon(displayText, showText: shouldLabel);
        markerIcon = iconData.icon;
        markerAnchor = iconData.anchor;
      } catch (e) {
        print('Error generating custom marker icon for $rawName: $e');
        // Fallback to default marker
        markerIcon = BitmapDescriptor.defaultMarkerWithHue(BitmapDescriptor.hueRed);
        markerAnchor = const Offset(0.5, 1.0);
      }

      list.add(Marker(
        markerId: MarkerId(placeId),
        position: LatLng(loc['lat'], loc['lng']),
        icon: markerIcon,
        anchor: markerAnchor,
        infoWindow: InfoWindow(title: rawName, snippet: p['vicinity'] ?? ''),
        onTap: () {
          clearRoute();
          routeToInApp(LatLng(loc['lat'], loc['lng']), rawName);
        },
      ));
    }
    print('DEBUG: Created ${list.length} markers from ${items.length} places');
    return list;
  }

  Future<void> _applyMarkersForCurrentPlaces() async {
    if (places.isEmpty) return;
    markers.assignAll(await _markersFromPlaces(places));
  }

  Future<MarkerIconData> _labelIcon(String text, {bool showText = true}) async {
    final recorder = ui.PictureRecorder();
    final canvas = ui.Canvas(recorder);
    final pinSize = 80.0;
    final innerCircleSize = 58.0;
    
    TextPainter? tp;
    if (showText) {
      tp = TextPainter(
        text: TextSpan(
          text: text,
          style: TextStyle(color: const Color(0xFF333333), fontSize: 24.0, fontWeight: FontWeight.w900, shadows: [ui.Shadow(blurRadius: 4.0, color: Colors.white)]),
        ),
        textDirection: TextDirection.ltr,
        maxLines: 2,
      );
      tp.layout(maxWidth: 300);
    }

    final w = pinSize + (tp != null ? (tp.width + 12) : 6);
    final h = (tp != null && tp.height > pinSize ? (tp.height + 10) : pinSize) + 15;

    final shadowPaint = Paint()..color = Colors.black.withOpacity(0.2)..maskFilter = const MaskFilter.blur(ui.BlurStyle.normal, 3);
    canvas.drawCircle(Offset(pinSize / 2, pinSize / 2 + 2), pinSize / 2, shadowPaint);

    final outerPaint = Paint()..color = Colors.white;
    canvas.drawCircle(Offset(pinSize / 2, pinSize / 2), pinSize / 2, outerPaint);
    
    final pointerPath = ui.Path();
    pointerPath.moveTo(pinSize * 0.15, pinSize * 0.75);
    pointerPath.lineTo(pinSize * 0.5, pinSize * 1.05);
    pointerPath.lineTo(pinSize * 0.85, pinSize * 0.75);
    pointerPath.close();
    canvas.drawPath(pointerPath, outerPaint);

    final innerPaint = Paint()..color = const Color(0xFFE53935);
    canvas.drawCircle(Offset(pinSize / 2, pinSize / 2), innerCircleSize / 2, innerPaint);

    final crossPaint = Paint()..color = Colors.white..strokeWidth = 5.0..strokeCap = ui.StrokeCap.round;
    canvas.drawLine(Offset(pinSize / 2, pinSize / 2 - 14), Offset(pinSize / 2, pinSize / 2 + 14), crossPaint);
    canvas.drawLine(Offset(pinSize / 2 - 10, pinSize / 2 - 4), Offset(pinSize / 2 + 10, pinSize / 2 - 4), crossPaint);

    if (tp != null) {
      tp.paint(canvas, ui.Offset(pinSize + 6, (pinSize/2 - tp.height/2).clamp(0, h)));
    }

    final img = await recorder.endRecording().toImage(w.ceil(), h.ceil());
    final bytes = await img.toByteData(format: ui.ImageByteFormat.png);
    return MarkerIconData(icon: BitmapDescriptor.fromBytes(bytes!.buffer.asUint8List()), anchor: Offset((pinSize * 0.5) / w, (pinSize * 1.05) / h));
  }

  String _compactName(String name) {
    if (name.length > 35) return '${name.substring(0, 35)}…';
    return name;
  }

  void updateDenomination(String? d) {
    selectedDenomination.value = (d == 'All') ? null : d;
    // Clear old data so map is definitely empty behind the white screen
    places.clear();
    markers.clear();
    searchChurches(forceGlobal: true);
  }

  void focusPlace(Map<String, dynamic> place) {
    final loc = place['geometry']?['location'];
    if (loc == null) return;
    final latlng = LatLng(loc['lat'], loc['lng']);
    cameraTarget.value = latlng;
    mapController?.animateCamera(CameraUpdate.newCameraPosition(
      CameraPosition(target: latlng, zoom: 15.0),
    ));
  }

  String _parseDenomination(String name) {
    name = name.toLowerCase();
    if (name.contains('catholic')) return 'Catholic';
    if (name.contains('baptist')) return 'Baptist';
    if (name.contains('pentecost')) return 'Pentecostal';
    if (name.contains('lutheran')) return 'Lutheran';
    if (name.contains('anglican')) return 'Anglican';
    if (name.contains('protestant')) return 'Protestant';
    if (name.contains('orthodox')) return 'Orthodox';
    if (name.contains('methodist')) return 'Methodist';
    if (name.contains('presbyterian')) return 'Presbyterian';
    if (name.contains('adventist')) return 'Adventist';
    return 'Church';
  }

  Future<void> onSearchInputChanged(String v) async {
    _searchDebounce?.cancel();
    _searchDebounce = Timer(const Duration(milliseconds: 350), () async {
      if (v.trim().isEmpty) {
        suggestions.clear();
        return;
      }
      final bias = currentPosition.value != null ? LatLng(currentPosition.value!.latitude, currentPosition.value!.longitude) : null;
      suggestions.assignAll(await PlacesService.autocomplete(input: v.trim(), locationBias: bias));
    });
  }

  Future<void> selectPrediction(Map<String, dynamic> pred) async {
    final placeId = pred['place_id'];
    if (placeId == null) return;
    isLoading(true);
    try {
      final details = await PlacesService.placeDetails(placeId: placeId);
      if (details != null) {
        final loc = details['geometry']['location'];
        final center = LatLng(loc['lat'], loc['lng']);
        suggestions.clear();
        hqQuery.value = details['name'] ?? '';
        mapController?.animateCamera(CameraUpdate.newCameraPosition(CameraPosition(target: center, zoom: 14.0)));
        
        // Add the selected church to the places list first
        final selectedChurch = {
          'place_id': placeId,
          'name': details['name'] ?? '',
          'vicinity': details['formatted_address'] ?? details['vicinity'] ?? '',
          'formatted_address': details['formatted_address'] ?? '',
          'geometry': details['geometry'],
          'distance': '0.0',
          'denomination': _parseDenomination(details['name'] ?? ''),
        };
        
        // Clear existing places and add the selected church
        places.clear();
        places.add(selectedChurch);
        markers.assignAll(await _markersFromPlaces([selectedChurch]));
        
        // Then search for nearby churches
        await searchChurchesAt(center, silent: true);
        
        // Ensure the selected church is still at the top
        if (places.isNotEmpty && places.first['place_id'] != placeId) {
          places.removeWhere((p) => p['place_id'] == placeId);
          places.insert(0, selectedChurch);
          markers.assignAll(await _markersFromPlaces(places));
        }
      }
    } finally {
      isLoading(false);
    }
  }

  // Update the routeToInApp method with better error handling and debugging
  Future<void> routeToInApp(LatLng dest, String name) async {
    try {
      print('DEBUG: routeToInApp started for $name');
      isLoading(true);
      loadingMessage.value = 'Finding best routes to $name...';

      if (currentPosition.value == null) {
        print('DEBUG: currentPosition is null, fetching...');
        Position? pos;
        try {
          pos = await Geolocator.getCurrentPosition(
            desiredAccuracy: LocationAccuracy.high,
            timeLimit: const Duration(seconds: 10),
          );
        } catch (e) {
          print('DEBUG: Geolocator error: $e');
        }
        if (pos != null) currentPosition.value = pos;
      }

      if (currentPosition.value == null) {
        print('DEBUG: Location still null after fetch');
        _showSnackSafe('Location', 'Please enable location to see routes');
        isLoading(false);
        // Just focus on the destination without routing
        mapController?.animateCamera(CameraUpdate.newCameraPosition(
          CameraPosition(target: dest, zoom: 15.0),
        ));
        return;
      }

      final origin = LatLng(currentPosition.value!.latitude, currentPosition.value!.longitude);
      
      // Check if current position is a default/hardcoded location (San Francisco Bay Area)
      // Use more lenient check to catch any SF coordinates (37.7-37.8, -122.4 to -122.5)
      final isDefaultLocation = origin.latitude >= 37.6 && origin.latitude <= 37.9 &&
                                origin.longitude >= -122.5 && origin.longitude <= -122.3;
      
      if (isDefaultLocation) {
        print('DEBUG: Current position appears to be default location ($origin), trying to fetch real location');
        Position? pos;
        try {
          pos = await Geolocator.getCurrentPosition(
            desiredAccuracy: LocationAccuracy.high,
            timeLimit: const Duration(seconds: 10),
          );
        } catch (e) {
          print('DEBUG: Geolocator error when fetching real location: $e');
        }
        if (pos != null) {
          currentPosition.value = pos;
          print('DEBUG: Updated to real position: ${pos.latitude}, ${pos.longitude}');
        }
      }

      // Recalculate origin after potentially updating position
      final finalOrigin = LatLng(currentPosition.value!.latitude, currentPosition.value!.longitude);
      print('DEBUG: Requesting directions from $finalOrigin to $dest');

      // Calculate distance to check if routing is feasible
      final distance = Geolocator.distanceBetween(
        finalOrigin.latitude, finalOrigin.longitude,
        dest.latitude, dest.longitude
      );
      print('DEBUG: Distance to destination: ${(distance / 1000).toStringAsFixed(1)} km');

      // If distance is too large (> 5000 km), skip routing and just show destination
      if (distance > 5000000) {
        print('DEBUG: Distance too large for routing, showing destination only');
        _showSnackSafe('Route', 'Distance too far for route calculation');
        isLoading(false);
        mapController?.animateCamera(CameraUpdate.newCameraPosition(
          CameraPosition(target: dest, zoom: 15.0),
        ));
        return;
      }

      // Clear previous routes first
      clearRoute();

      final results = await PlacesService.directions(
          origin: finalOrigin,
          destination: dest,
          mode: 'driving'
      );

      if (results == null || results.isEmpty) {
        print('DEBUG: No results from PlacesService.directions');
        _showSnackSafe('Route', 'No routes found to $name');
        isLoading(false);
        // Still focus on the destination
        mapController?.animateCamera(CameraUpdate.newCameraPosition(
          CameraPosition(target: dest, zoom: 15.0),
        ));
        return;
      }

      print('DEBUG: Found ${results.length} routes. Checking points...');

      // Verify each route has points
      for (int i = 0; i < results.length; i++) {
        final points = results[i]['points'] as List?;
        print('DEBUG: Route $i has ${points?.length ?? 0} points');
        if (points == null || points.isEmpty) {
          print('DEBUG: WARNING - Route $i has no points!');
        }
      }

      allRoutesData.assignAll(results);
      selectedRouteIndex.value = 0;
      await _updateRouteVisuals();

      // Force a rebuild by updating markers
      markers.refresh();

      if (results.isNotEmpty && results.first['points'].isNotEmpty) {
        final bounds = _getBounds(List<LatLng>.from(results.first['points']));
        print('DEBUG: Animating camera to bounds: $bounds');
        await mapController?.animateCamera(CameraUpdate.newLatLngBounds(bounds, 80));
      } else {
        print('DEBUG: No points in first route, just focusing on destination');
        mapController?.animateCamera(CameraUpdate.newCameraPosition(
          CameraPosition(target: dest, zoom: 15.0),
        ));
      }
    } catch (e, stack) {
      print('DEBUG: routeToInApp ERROR: $e');
      print(stack);
      _showSnackSafe('Route', 'Could not get directions');
      // Still focus on destination even on error
      mapController?.animateCamera(CameraUpdate.newCameraPosition(
        CameraPosition(target: dest, zoom: 15.0),
      ));
    } finally {
      isLoading(false);
    }
  }

// Update _updateRouteVisuals method with more robust error handling
  Future<void> _updateRouteVisuals() async {
    if (allRoutesData.isEmpty) {
      print('DEBUG: _updateRouteVisuals aborted - no route data');
      return;
    }

    final List<Polyline> newPolylines = [];
    final List<Marker> newLabels = [];

    for (int i = 0; i < allRoutesData.length; i++) {
      final isSelected = i == selectedRouteIndex.value;
      final route = allRoutesData[i];
      final points = route['points'] as List?;

      if (points == null || points.isEmpty) {
        print('DEBUG: Route $i has 0 points - skipping');
        continue;
      }

      // Convert points to LatLng if they aren't already
      final List<LatLng> latLngPoints = [];
      for (var point in points) {
        if (point is LatLng) {
          latLngPoints.add(point);
        } else if (point is Map) {
          // If points are stored as maps with lat/lng
          latLngPoints.add(LatLng(point['lat'], point['lng']));
        }
      }

      if (latLngPoints.isEmpty) {
        print('DEBUG: Route $i has no valid LatLng points');
        continue;
      }

      print('DEBUG: Adding polyline for route $i with ${latLngPoints.length} points');

      newPolylines.add(Polyline(
        polylineId: PolylineId('route_$i'),
        points: latLngPoints,
        color: isSelected ? const Color(0xFF2196F3) : const Color(0xFF90CAF9),
        width: isSelected ? 10 : 8,
        zIndex: isSelected ? 100 : 50,
        consumeTapEvents: true,
        onTap: () => selectRoute(i),
        jointType: JointType.round,
        startCap: Cap.roundCap,
        endCap: Cap.roundCap,
        patterns: isSelected ? [] : [PatternItem.dash(20), PatternItem.gap(10)], // Dotted look for alternates
      ));

      // Add floating label at 40%
      final labelPos = latLngPoints[(latLngPoints.length * 0.4).floor()];
      final labelIcon = await _createRouteLabel(
          route['durationText'] ?? '',
          route['distanceText'] ?? '',
          isSelected: isSelected
      );

      newLabels.add(Marker(
        markerId: MarkerId('label_$i'),
        position: labelPos,
        icon: labelIcon,
        anchor: const Offset(0.5, 1.0),
        onTap: () => selectRoute(i),
        zIndex: isSelected ? 101 : 51,
        visible: true, // Explicitly set visible
      ));
    }

    print('DEBUG: Updating polylines (${newPolylines.length}) and label markers (${newLabels.length})');
    polylines.assignAll(newPolylines);
    routeLabelMarkers.assignAll(newLabels);

    if (allRoutesData.isNotEmpty && selectedRouteIndex.value < allRoutesData.length) {
      final selected = allRoutesData[selectedRouteIndex.value];
      routeSummary.value = '${selected['durationText']} • ${selected['distanceText']}';
      routeSteps.assignAll(List<Map<String, dynamic>>.from(selected['steps'] ?? []));
      print('DEBUG: _updateRouteVisuals completed. Summary: ${routeSummary.value}');
    }
  }

// Add clearRoute method if not present
  void clearRoute() {
    polylines.clear();
    routeLabelMarkers.clear();
    allRoutesData.clear();
    routeSummary.value = null;
    routeSteps.clear();
  }

  void selectRoute(int index) {
    if (index == selectedRouteIndex.value) return;
    selectedRouteIndex.value = index;
    _updateRouteVisuals();
  }

  void fitAllMarkers() {
    if (places.isEmpty || mapController == null) return;
    
    final List<LatLng> coords = [];
    for (var p in places) {
      final loc = p['geometry']?['location'];
      if (loc != null) {
        coords.add(LatLng(loc['lat'], loc['lng']));
      }
    }
    
    if (coords.isEmpty) return;
    
    // Also include user position in bounds if available
    if (currentPosition.value != null) {
      coords.add(LatLng(currentPosition.value!.latitude, currentPosition.value!.longitude));
    }

    final bounds = _getBounds(coords);
    mapController?.animateCamera(CameraUpdate.newLatLngBounds(bounds, 60));
  }

  LatLngBounds _getBounds(List<LatLng> points) {
    double minLat = 90, maxLat = -90, minLng = 180, maxLng = -180;
    for (final p in points) {
      if (p.latitude < minLat) minLat = p.latitude;
      if (p.latitude > maxLat) maxLat = p.latitude;
      if (p.longitude < minLng) minLng = p.longitude;
      if (p.longitude > maxLng) maxLng = p.longitude;
    }
    return LatLngBounds(southwest: LatLng(minLat, minLng), northeast: LatLng(maxLat, maxLng));
  }

  Future<BitmapDescriptor> _createRouteLabel(String time, String dist, {required bool isSelected}) async {
    final ui.PictureRecorder recorder = ui.PictureRecorder();
    final Canvas canvas = Canvas(recorder);
    const double width = 140.0;
    const double height = 80.0;
    const double arrowSize = 12.0;

    final Paint paint = Paint()
      ..color = Colors.white
      ..style = PaintingStyle.fill;

    final shadowPaint = Paint()
      ..color = Colors.black.withOpacity(0.2)
      ..maskFilter = const MaskFilter.blur(BlurStyle.normal, 4);

    // Draw shadow
    canvas.drawRRect(RRect.fromLTRBR(4, 4, width - 4, height - arrowSize - 2, const Radius.circular(12)), shadowPaint);

    // Draw bubble
    canvas.drawRRect(RRect.fromLTRBR(0, 0, width, height - arrowSize, const Radius.circular(12)), paint);
    
    // Draw arrow
    final Path path = Path();
    path.moveTo(width / 2 - arrowSize, height - arrowSize);
    path.lineTo(width / 2, height);
    path.lineTo(width / 2 + arrowSize, height - arrowSize);
    path.close();
    canvas.drawPath(path, paint);

    // Draw Texts
    final timePainter = TextPainter(
      text: TextSpan(
        text: time,
        style: TextStyle(
          color: isSelected ? const Color(0xFF2E7D32) : Colors.black87,
          fontSize: 22,
          fontWeight: FontWeight.bold,
        ),
      ),
      textDirection: TextDirection.ltr,
    )..layout();

    final distPainter = TextPainter(
      text: TextSpan(
        text: dist,
        style: const TextStyle(
          color: Colors.black54,
          fontSize: 18,
          fontWeight: FontWeight.w500,
        ),
      ),
      textDirection: TextDirection.ltr,
    )..layout();

    timePainter.paint(canvas, Offset((width - timePainter.width) / 2, 8));
    distPainter.paint(canvas, Offset((width - distPainter.width) / 2, 36));

    final img = await recorder.endRecording().toImage(width.toInt(), height.toInt());
    final bytes = await img.toByteData(format: ui.ImageByteFormat.png);
    return BitmapDescriptor.fromBytes(bytes!.buffer.asUint8List());
  }

}

class MarkerIconData {
  final BitmapDescriptor icon;
  final Offset anchor;
  MarkerIconData({required this.icon, required this.anchor});
}