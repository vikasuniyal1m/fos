import 'package:fruitsofspirit/utils/url_helper.dart';import 'package:fruitsofspirit/config/environment_config.dart';

/// URL Helper Utility
/// Centralized URL construction for all media files
class URLHelper {
  /// Construct full URL for media files
  /// Handles uploads/ prefix removal and slash addition consistently
  static String constructMediaUrl(String? relativePath) {
    if (relativePath == null || relativePath.isEmpty) {
      return '';
    }
    
    // If already a full URL, return as-is
    if (relativePath.startsWith('http://') || relativePath.startsWith('https://')) {
      return relativePath;
    }
    
    // Handle malformed URLs with multiple uploads prefixes
    String cleanPath = relativePath;
    
    // Fix double uploads: uploadsuploads/... → uploads/...
    if (cleanPath.startsWith('uploadsuploads/')) {
      cleanPath = cleanPath.substring('uploads'.length); // Remove first 'uploads'
    }
    
    // Fix missing slash after uploads: uploadsblog_... → uploads/blog_...
    else if (cleanPath.startsWith('uploads') && !cleanPath.startsWith('uploads/')) {
      // Find where 'uploads' ends and add slash
      cleanPath = 'uploads/' + cleanPath.substring('uploads'.length);
    }
    
    // Remove 'uploads/' prefix if it exists to avoid duplication
    else if (cleanPath.startsWith('uploads/')) {
      cleanPath = cleanPath.substring('uploads/'.length);
    }
    
    // Add slash if needed
    if (cleanPath.isNotEmpty && !cleanPath.startsWith('/')) {
      cleanPath = '/$cleanPath';
    }
    
    final finalUrl = '${URLHelper.constructMediaUrl}$cleanPath';
    print('🔧 URLHelper: $relativePath → $finalUrl');
    return finalUrl;
  }
  
  /// Construct full URL for blog images specifically
  static String constructBlogImageUrl(String? imagePath) {
    return constructMediaUrl(imagePath);
  }
  
  /// Construct full URL for profile photos specifically
  static String constructProfileImageUrl(String? imagePath) {
    return constructMediaUrl(imagePath);
  }
  
  /// Construct full URL for group images specifically
  static String constructGroupImageUrl(String? imagePath) {
    return constructMediaUrl(imagePath);
  }
  
  /// Construct full URL for gallery photos specifically
  static String constructGalleryImageUrl(String? imagePath) {
    return constructMediaUrl(imagePath);
  }
  
  /// Construct full URL for video files specifically
  static String constructVideoUrl(String? videoPath) {
    return constructMediaUrl(videoPath);
  }
  
  /// Construct full URL for banner images specifically
  static String constructBannerImageUrl(String? imagePath) {
    return constructMediaUrl(imagePath);
  }
  
  /// Construct full URL for emoji images specifically
  static String constructEmojiImageUrl(String? imagePath) {
    return constructMediaUrl(imagePath);
  }
}
