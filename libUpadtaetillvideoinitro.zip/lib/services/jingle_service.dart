import 'dart:async';
import 'package:audioplayers/audioplayers.dart';
import 'package:get/get.dart';
import 'package:hive_flutter/hive_flutter.dart';
import 'package:flutter_cache_manager/flutter_cache_manager.dart';
import 'package:fruitsofspirit/services/user_storage.dart';
import 'package:fruitsofspirit/config/image_config.dart';
import 'package:fruitsofspirit/config/api_config.dart';

/// Jingle Service
/// Handles voice over playback for group categories
class JingleService extends GetxService {
  static final JingleService _instance = JingleService._internal();
  factory JingleService() => _instance;
  JingleService._internal();

  late AudioPlayer _audioPlayer;
  bool _isPlaying = false;
  bool _isInitialized = false;
  final Map<String, String> _cachedFiles = {};

  // Observable to notify listeners when a jingle finishes
  final RxString lastFinishedCategory = ''.obs;

  @override
  void onInit() {
    super.onInit();
    initialize();
  }

  /// Initialize audio player and pre-cache jingles
  void initialize() {
    if (!_isInitialized) {
      _audioPlayer = AudioPlayer();
      _audioPlayer.setPlayerMode(PlayerMode.mediaPlayer);
      _isInitialized = true;
      print('✅ JingleService: AudioPlayer initialized');
      _preCacheAllJingles();
    }
  }

  void _preCacheAllJingles() {
    for (var category in _categoryToJingle.keys) {
      _preCacheJingle(category);
    }
  }

  Future<void> _preCacheJingle(String category) async {
    final url = _getJingleUrl(category);
    if (url.isEmpty) return;
    try {
      final fileInfo = await DefaultCacheManager().getFileFromCache(url);
      if (fileInfo != null) {
        _cachedFiles[category] = fileInfo.file.path;
      } else {
        final file = await DefaultCacheManager().getSingleFile(url);
        _cachedFiles[category] = file.path;
      }
    } catch (e) {
      print('⚠️ Error pre-caching jingle for $category: $e');
    }
  }

  static const Map<String, String> _categoryToJingle = {};

  static const String _keyJinglePlayCount = 'jingle_play_count_';
  static const String _keyJingleDisabled = 'jingle_disabled_';
  static const int _maxPlaysBeforeOption = 3;

  String _getJingleUrl(String category) {
    final jingleFileName = _categoryToJingle[category];
    if (jingleFileName == null) return '';
    final encodedFileName = Uri.encodeComponent(jingleFileName);
    final baseDomain = ApiConfig.baseUrl.split('/api').first;
    return '$baseDomain/uploads/jingle/$encodedFileName';
  }

  Future<Box> _getBox() async {
    if (!Hive.isBoxOpen('user_storage')) {
      await UserStorage.init();
      return await Hive.openBox('user_storage');
    }
    return Hive.box('user_storage');
  }

  Future<int> _getPlayCount(String category) async {
    try {
      final box = await _getBox();
      final key = '$_keyJinglePlayCount$category';
      final count = box.get(key);
      return count is int ? count : 0;
    } catch (e) {
      return 0;
    }
  }

  Future<void> _incrementPlayCount(String category) async {
    try {
      final box = await _getBox();
      final key = '$_keyJinglePlayCount$category';
      final currentCount = await _getPlayCount(category);
      await box.put(key, currentCount + 1);
    } catch (e) {}
  }

  Future<bool> _isJingleDisabled(String category) async {
    try {
      final box = await _getBox();
      final key = '$_keyJingleDisabled$category';
      final disabled = box.get(key);
      return disabled is bool ? disabled : false;
    } catch (e) {
      return false;
    }
  }

  Future<void> disableJingle(String category) async {
    try {
      final box = await _getBox();
      final key = '$_keyJingleDisabled$category';
      await box.put(key, true);
      // Trigger update
      lastFinishedCategory.refresh();
    } catch (e) {}
  }

  Future<void> enableJingle(String category) async {
    try {
      final box = await _getBox();
      final key = '$_keyJingleDisabled$category';
      await box.delete(key);
      // Trigger update
      lastFinishedCategory.refresh();
    } catch (e) {}
  }

  Future<Map<String, dynamic>> getJingleStatus(String category) async {
    final isDisabled = await _isJingleDisabled(category);
    final playCount = await _getPlayCount(category);
    final shouldShow = playCount >= _maxPlaysBeforeOption;
    return {
      'isDisabled': isDisabled,
      'playCount': playCount,
      'shouldShowOption': shouldShow,
    };
  }

  Future<void> stopJingle() async {
    try {
      await _audioPlayer.stop();
      _isPlaying = false;
    } catch (e) {}
  }

  Future<bool> startJingle(String category) async {
    initialize();
    if (category.isEmpty) return false;

    final isDisabled = await _isJingleDisabled(category);
    if (isDisabled || _isPlaying) return false;

    String jinglePath = _cachedFiles[category] ?? _getJingleUrl(category);
    if (jinglePath.isEmpty) return false;

    try {
      _isPlaying = true;
      final isLocal = !jinglePath.startsWith('http');
      if (isLocal) {
        await _audioPlayer.setSource(DeviceFileSource(jinglePath));
      } else {
        await _audioPlayer.setSource(UrlSource(jinglePath));
      }
      await _audioPlayer.resume();
      
      // Listen for completion
      _audioPlayer.onPlayerComplete.first.then((_) async {
        _isPlaying = false;
        await _incrementPlayCount(category);
        // Update observable to notify screen
        lastFinishedCategory.value = category;
        lastFinishedCategory.refresh();
      });

      return true;
    } catch (e) {
      _isPlaying = false;
      return false;
    }
  }

  @override
  void onClose() {
    _audioPlayer.dispose();
    super.onClose();
  }
}
