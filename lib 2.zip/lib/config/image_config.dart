class ImageConfig {
  // Base URL for images on Hostinger
  // Direct uploads folder (all images directly in uploads/)
  static const String baseUrl = 'http://admin.fosmessenger.com/uploads/';
  
  // App Images - Network URLs (with proper URL encoding for spaces)
  static String notification = '${baseUrl}images/notification.png';
  static String pray = '${baseUrl}images/Pray.png';
  static String userGroups = '${baseUrl}images/User%20Groups.png'; // URL encoded for spaces
  static String strawberry = '${baseUrl}images/Strawberry.png';
  static String dove = '${baseUrl}images/dove.png';
  // static String logo = '${baseUrl}images/logo%201.png'; // URL encoded for space
  static String logo = '${baseUrl}images/logo_png.png'; // URL encoded for space
  static String onboardingFirst = '${baseUrl}images/onboardingfirst.png';
  static String onboardingThird = '${baseUrl}images/onboardingthird.png';
  static String onboardingFourth = '${baseUrl}images/onboardingfourth.png';
  static String splash = '${baseUrl}images/splash1.png';
  static String grow = '${baseUrl}images/grow.png';
  static String videoThumbnail = '${baseUrl}images/videothumbnail.png';
  
  // Fruits of the Spirit Images Base URL
  // Original URL provided by user
  static const String fruitsBaseUrl = 'http://admin.fosmessenger.com/uploads/fruitofspirit/';
  
  // Helper method to get fruit image URL based on fruit name
  // DEPRECATED: Now using completely dynamic loading from backend database
  // This method is kept for compatibility but should not be used
  // All emoji data should come from database via EmojisService
  static String getFruitImageUrl(String fruitName) {
    print('⚠️ getFruitImageUrl is deprecated - use database emojis instead');
    // Return fallback URL for compatibility
    return '${fruitsBaseUrl}pineapple-01.png';
  }
  
  // Helper method to get physical fruit name for display
  // Based on website reference mapping
  static String getPhysicalFruitName(String spiritualFruitName) {
    final normalizedName = spiritualFruitName.trim().toLowerCase();
    final physicalFruitMap = {
      'love': 'Strawberry',
      'joy': 'Pineapple',
      'peace': 'Watermelon',
      'patience': 'Banana',
      'kindness': 'Orange',
      'goodness': 'Kiwi',
      'faithfulness': 'Cherry',
      'gentleness': 'Grapes',
      'meekness': 'Grapes',
      'self-control': 'Apple',
      'self control': 'Apple',
      'discipline': 'Apple',
    };
    return physicalFruitMap[normalizedName] ?? 'Fruit';
  }
  
  // Helper method to get image URL with error handling
  // For images in uploads/images/ folder
  static String getImageUrl(String imageName) {
    // Replace spaces with %20 for URL encoding
    String encodedName = imageName.replaceAll(' ', '%20');
    return '${baseUrl}images/$encodedName';
  }
  
  // Helper method to convert asset path to network URL
  // Converts: assets/images/notification.png -> uploads/images/notification.png
  static String assetPathToNetworkUrl(String assetPath) {
    // Remove 'assets/images/' prefix and convert to network URL
    String imageName = assetPath.replaceAll('assets/images/', '');
    // Add 'images/' prefix to match server structure
    return '${baseUrl}images/$imageName';
  }
  
  // Helper method to get image URL from filename (for direct server images)
  // For images in uploads/images/ folder
  static String getServerImageUrl(String imageName) {
    // Replace spaces with %20 for URL encoding
    String encodedName = imageName.replaceAll(' ', '%20');
    return '${baseUrl}images/$encodedName';
  }
  
  // Fallback to asset if network image fails
  static String getAssetPath(String imageName) {
    return 'assets/images/$imageName';
  }

  // PHP endpoint for emoji images (from uploads/emojis folder)
  static const String emojiImageApiUrl = 'http://admin.fosmessenger.com/api/get-emoji-image.php';

  // Fruit reaction images base URLs (from uploads/images/128-128 and 256-256) - DEPRECATED
  // Now using PHP endpoint from uploads/emojis folder
  static const String fruitReactions128Url = '${baseUrl}images/128-128/';
  static const String fruitReactions256Url = '${baseUrl}images/256-256/';

  /// Get fruit reaction image URL from emoji character
  /// DEPRECATED: Now using completely dynamic loading from backend database
  /// This method is kept for compatibility but should not be used
  /// All emoji data should come from database via EmojisService
  static String? getFruitReactionImageUrl(String emojiChar, {double? size, int variant = 1}) {
    print('⚠️ getFruitReactionImageUrl is deprecated - use database emojis instead');
    // Return null to force dynamic loading from database
    return null;
  }

  /// Get fruit reaction image URL from fruit name
  /// DEPRECATED: Now using completely dynamic loading from backend database
  /// This method is kept for compatibility but should not be used
  /// All emoji data should come from database via EmojisService
  static String? getFruitReactionImageUrlByName(String fruitName, {double? size, int variant = 1}) {
    print('⚠️ getFruitReactionImageUrlByName is deprecated - use database emojis instead');
    // Return null to force dynamic loading from database
    return null;
  }
}

