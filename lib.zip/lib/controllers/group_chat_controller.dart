import 'dart:io';
import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:fruitsofspirit/services/group_chat_service.dart';
import 'package:fruitsofspirit/services/user_storage.dart';

/// Group Chat Controller
/// Manages real-time chat messages
class GroupChatController extends GetxController {
  var messages = <Map<String, dynamic>>[].obs;
  var isLoading = false.obs;
  var isSending = false.obs;
  var message = ''.obs;
  var userId = 0.obs;
  var hasMore = true.obs;
  
  int? currentGroupId;
  int? lastMessageId;

  @override
  void onInit() {
    super.onInit();
    _loadUserId();
  }

  Future<void> _loadUserId() async {
    final id = await UserStorage.getUserId();
    if (id != null) {
      userId.value = id;
    }
  }

  /// Load chat messages
  Future<void> loadMessages(int groupId, {bool refresh = false}) async {
    if (userId.value == 0) {
      await _loadUserId();
    }

    if (userId.value == 0) {
      message.value = 'Please login first';
      return;
    }

    // If switching to a different group, clear messages and reset
    if (currentGroupId != null && currentGroupId != groupId) {
      print('🔄 Switching groups: $currentGroupId -> $groupId');
      messages.clear();
      lastMessageId = null;
      hasMore.value = true;
    }

    if (isLoading.value && !refresh) return;

    isLoading.value = true;
    currentGroupId = groupId;
    message.value = '';

    try {
      final chatMessages = await GroupChatService.getChatMessages(
        groupId: groupId,
        userId: userId.value,
        limit: 50,
        offset: refresh ? 0 : messages.length,
        lastMessageId: refresh ? null : lastMessageId,
      );

      // Ensure all messages have the correct group_id
      final filteredMessages = chatMessages.map((msg) {
        msg['group_id'] = groupId; // Ensure group_id is set
        return msg;
      }).toList();

      if (refresh) {
        messages.value = filteredMessages;
      } else {
        messages.insertAll(0, filteredMessages);
      }

      if (filteredMessages.isNotEmpty) {
        lastMessageId = filteredMessages.first['id'] as int?;
      }

      hasMore.value = filteredMessages.length >= 50;
      
      print('✅ Loaded ${filteredMessages.length} messages for group $groupId');
    } catch (e) {
      message.value = 'Error: ${e.toString().replaceAll('Exception: ', '')}';
      print('Error loading messages: $e');
    } finally {
      isLoading.value = false;
    }
  }

  /// Send message
  Future<bool> sendMessage({
    required int groupId,
    required String text,
    File? file,
    String messageType = 'text',
  }) async {
    if (userId.value == 0) {
      await _loadUserId();
    }

    if (userId.value == 0) {
      message.value = 'Please login first';
      print('❌ Cannot send message: User not logged in');
      return false;
    }

    if (text.trim().isEmpty && file == null) {
      message.value = 'Message cannot be empty';
      print('❌ Cannot send message: Message is empty and no file provided');
      return false;
    }

    print('📤 Sending message: groupId=$groupId, userId=${userId.value}, messageType=$messageType');
    print('   Text: ${text.trim().substring(0, text.trim().length > 50 ? 50 : text.trim().length)}...');
    print('   File: ${file != null ? file.path : "none"}');

    isSending.value = true;
    message.value = '';

    try {
      final sentMessage = await GroupChatService.sendMessage(
        userId: userId.value,
        groupId: groupId,
        message: text.trim(),
        messageType: messageType,
        file: file,
      );

      print('✅ Message sent successfully: id=${sentMessage['id']}');
      
      // Ensure sent message has correct group_id
      sentMessage['group_id'] = groupId;
      sentMessage['user_id'] = userId.value;
      
      // Add to messages list only if it's for the current group
      if (currentGroupId == groupId) {
        messages.add(sentMessage);
        print('✅ Message added to UI for group $groupId');
      } else {
        print('⚠️ Message sent but not added to UI (different group: current=$currentGroupId, sent=$groupId)');
      }
      
      // Scroll to bottom
      Future.delayed(const Duration(milliseconds: 100), () {
        // Scroll will be handled by UI
      });

      return true;
    } catch (e) {
      message.value = 'Error: ${e.toString().replaceAll('Exception: ', '')}';
      print('❌ Error sending message: $e');
      print('❌ Error type: ${e.runtimeType}');
      print('❌ Error details: ${e.toString()}');
      Get.snackbar(
        'Error',
        'Failed to send message: ${e.toString().replaceAll('Exception: ', '')}',
        backgroundColor: Colors.red,
        colorText: Colors.white,
        duration: const Duration(seconds: 3),
      );
      return false;
    } finally {
      isSending.value = false;
    }
  }

  /// Refresh messages
  Future<void> refresh() async {
    if (currentGroupId != null) {
      lastMessageId = null;
      await loadMessages(currentGroupId!, refresh: true);
    }
  }

  /// Load more messages (pagination)
  Future<void> loadMore() async {
    if (currentGroupId != null && hasMore.value && !isLoading.value) {
      await loadMessages(currentGroupId!, refresh: false);
    }
  }
}

