/// Environment Configuration
/// Central place to manage environment settings
class EnvironmentConfig {
  // Environment switch - set to true for testing, false for production
  static const bool isTestingEnvironment = true;
  
  // API Base URLs
  static const String productionApiBaseUrl = 'https://admin.fosmessenger.com/api';
  static const String testingApiBaseUrl = 'https://fruitofthespirit.templateforwebsites.com/api'; // Matches reference project
  
  // Image Base URLs  
  static const String productionImageBaseUrl = 'https://admin.fosmessenger.com/uploads';
  static const String testingImageBaseUrl = 'https://fruitofthespirit.templateforwebsites.com/uploads'; // Current testing URL
  
  // Obfuscated URLs for production builds (hidden in release mode)
  static String get _obfuscatedApiBaseUrl {
    if (isTestingEnvironment) {
      return testingApiBaseUrl;
    }
    // Production: use obfuscated URL that's harder to find in reverse engineering
    final part1 = String.fromCharCodes([104, 116, 116, 112, 115, 58, 47, 47]); // "https://"
    final part2 = String.fromCharCodes([97, 100, 109, 105, 110, 46]); // "admin."
    final part3 = String.fromCharCodes([102, 111, 115, 109, 101, 115, 115, 101, 110, 103, 101, 114]); // "fosmessenger"
    final part4 = String.fromCharCodes([46, 99, 111, 109, 47, 97, 112, 105]); // ".com/api"
    return part1 + part2 + part3 + part4;
  }
  
  static String get _obfuscatedImageBaseUrl {
    if (isTestingEnvironment) {
      return testingImageBaseUrl;
    }
    // Production: use obfuscated URL that's harder to find in reverse engineering
    final part1 = String.fromCharCodes([104, 116, 116, 112, 115, 58, 47, 47]); // "https://"
    final part2 = String.fromCharCodes([97, 100, 109, 105, 110, 46]); // "admin."
    final part3 = String.fromCharCodes([102, 111, 115, 109, 101, 115, 115, 101, 110, 103, 101, 114]); // "fosmessenger"
    final part4 = String.fromCharCodes([46, 99, 111, 109, 47, 117, 112, 108, 111, 97, 100, 115]); // ".com/uploads"
    return part1 + part2 + part3 + part4;
  }
  
  // Helper method to get current API base URL
  static String get currentApiBaseUrl => isTestingEnvironment ? testingApiBaseUrl : _obfuscatedApiBaseUrl;
  
  // Helper method to get current image base URL
  static String get currentImageBaseUrl => isTestingEnvironment ? testingImageBaseUrl : _obfuscatedImageBaseUrl;
  
  // Print current environment (for debugging)
  static void printCurrentEnvironment() {
    print('=== Environment Settings ===');
    print('Environment: ${isTestingEnvironment ? "TESTING" : "PRODUCTION"}');
    print('API Base URL: $currentApiBaseUrl');
    print('Image Base URL: $currentImageBaseUrl');
    print('========================');
  }
}
