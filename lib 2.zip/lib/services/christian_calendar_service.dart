import 'dart:convert';
import 'package:http/http.dart' as http;
import '../config/api_config.dart';

/// Christian Calendar Service
/// Fetches liturgical events and civil holidays from the backend
class ChristianCalendarService {
  /// Fetch upcoming Christian and secular events
  /// 
  /// [limit] - Number of events to fetch (default: 80)
  /// Returns list of upcoming events with dates
  static Future<List<Map<String, dynamic>>> getUpcomingEvents({int limit = 80}) async {
    try {
      final url = '${ApiConfig.christianCalender}?upcoming=1&limit=$limit';
      print('=== Christian Calendar API Call ===');
      print('URL: $url');
      print('Headers: ${ApiConfig.headers}');

      final response = await http.get(
        Uri.parse(url),
        headers: ApiConfig.headers,
      ).timeout(ApiConfig.timeout);

      print('Status Code: ${response.statusCode}');
      print('Response Body: ${response.body}');

      if (response.statusCode == 200) {
        final data = jsonDecode(response.body);
        print('Parsed Data: $data');

        if (data['success'] == true) {
          final events = List<Map<String, dynamic>>.from(data['data'] ?? []);
          print('Total Events: ${events.length}');

          // Map 'cat' to 'category' for consistency
          final mappedEvents = events.map((event) {
            final mapped = Map<String, dynamic>.from(event);
            if (mapped.containsKey('cat')) {
              mapped['category'] = mapped['cat'];
            }
            return mapped;
          }).toList();

          if (mappedEvents.isNotEmpty) {
            print('First Event: ${mappedEvents.first}');
            print('Last Event: ${mappedEvents.last}');
          }
          return mappedEvents;
        } else {
          print('API returned success=false');
        }
      } else {
        print('API returned non-200 status');
      }
      return [];
    } catch (e) {
      print('Error fetching upcoming events: $e');
      return [];
    }
  }

  /// Fetch events for a specific month
  /// 
  /// [year] - Year (e.g., 2026)
  /// [month] - Month (1-12)
  /// Returns map of day number to list of events
  static Future<Map<int, List<Map<String, dynamic>>>> getMonthEvents(int year, int month) async {
    try {
      final response = await http.get(
        Uri.parse('${ApiConfig.christianCalender}?y=$year&m=$month'),
        headers: ApiConfig.headers,
      ).timeout(ApiConfig.timeout);

      if (response.statusCode == 200) {
        final data = jsonDecode(response.body);
        if (data['success'] == true) {
          final Map<int, List<Map<String, dynamic>>> result = {};
          final monthData = data['data'] as Map<String, dynamic>;
          
          monthData.forEach((dayStr, events) {
            final day = int.tryParse(dayStr) ?? 0;
            if (day > 0 && events is List) {
              result[day] = List<Map<String, dynamic>>.from(
                events.map((e) {
                  final mapped = Map<String, dynamic>.from(e);
                  if (mapped.containsKey('cat')) {
                    mapped['category'] = mapped['cat'];
                  }
                  return mapped;
                }),
              );
            }
          });
          
          return result;
        }
      }
      return {};
    } catch (e) {
      print('Error fetching month events: $e');
      return {};
    }
  }

  /// Fetch all events for a year
  /// 
  /// [year] - Year (e.g., 2026)
  /// Returns map of date (YYYY-MM-DD) to list of events
  static Future<Map<String, List<Map<String, dynamic>>>> getYearEvents(int year) async {
    try {
      final response = await http.get(
        Uri.parse('${ApiConfig.christianCalender}?y=$year'),
        headers: ApiConfig.headers,
      ).timeout(ApiConfig.timeout);

      if (response.statusCode == 200) {
        final data = jsonDecode(response.body);
        if (data['success'] == true) {
          final Map<String, List<Map<String, dynamic>>> result = {};
          final yearData = data['data'] as Map<String, dynamic>;
          
          yearData.forEach((date, events) {
            if (events is List) {
              result[date] = List<Map<String, dynamic>>.from(
                events.map((e) {
                  final mapped = Map<String, dynamic>.from(e);
                  if (mapped.containsKey('cat')) {
                    mapped['category'] = mapped['cat'];
                  }
                  return mapped;
                }),
              );
            }
          });
          
          return result;
        }
      }
      return {};
    } catch (e) {
      print('Error fetching year events: $e');
      return {};
    }
  }

  /// Check if a specific date has events
  /// 
  /// [date] - Date in format YYYY-MM-DD
  static Future<List<Map<String, dynamic>>> getEventsForDate(String date) async {
    try {
      final parts = date.split('-');
      if (parts.length != 3) return [];
      
      final year = int.parse(parts[0]);
      final month = int.parse(parts[1]);
      final day = int.parse(parts[2]);
      
      final monthEvents = await getMonthEvents(year, month);
      return monthEvents[day] ?? [];
    } catch (e) {
      print('Error fetching events for date: $e');
      return [];
    }
  }

  /// Get event category icon
  static String getEventIcon(String category) {
    return category == 'christian' ? '✝' : '🎉';
  }

  /// Get event category color
  static int getEventColor(String category) {
    return category == 'christian' ? 0xFFE57373 : 0xFFFFB74D; // Red for Christian, Gold for secular
  }

  /// Test function to call API and print response
  static Future<void> testCalendarAPI() async {
    print('=== Testing Christian Calendar API ===');
    
    try {
      final baseUrl = 'http://admin.fosmessenger.com/api';
      
      // Test 1: Call upcoming events API
      print('\n1. Testing upcoming events API...');
      final upcomingUrl = '$baseUrl/christian-calender.php?upcoming=1&limit=10';
      print('URL: $upcomingUrl');
      
      final upcomingResponse = await http.get(
        Uri.parse(upcomingUrl),
        headers: {'Accept': 'application/json'},
      ).timeout(ApiConfig.timeout);
      
      print('Status Code: ${upcomingResponse.statusCode}');
      print('Response Body: ${upcomingResponse.body}');
      
      // Test 2: Call current month API
      print('\n2. Testing current month API...');
      final now = DateTime.now();
      final monthUrl = '$baseUrl/christian-calender.php?y=${now.year}&m=${now.month}';
      print('URL: $monthUrl');
      
      final monthResponse = await http.get(
        Uri.parse(monthUrl),
        headers: {'Accept': 'application/json'},
      ).timeout(ApiConfig.timeout);
      
      print('Status Code: ${monthResponse.statusCode}');
      print('Response Body: ${monthResponse.body}');
      
      // Test 3: Call year events API
      print('\n3. Testing year events API...');
      final yearUrl = '$baseUrl/christian-calender.php?y=${now.year}';
      print('URL: $yearUrl');
      
      final yearResponse = await http.get(
        Uri.parse(yearUrl),
        headers: {'Accept': 'application/json'},
      ).timeout(ApiConfig.timeout);
      
      print('Status Code: ${yearResponse.statusCode}');
      print('Response Body: ${yearResponse.body}');
      
      print('\n=== API Test Complete ===');
    } catch (e) {
      print('Error testing calendar API: $e');
    }
  }
}
