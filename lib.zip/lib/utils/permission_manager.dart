import 'package:permission_handler/permission_handler.dart';

class PermissionManager {
  static Future<bool> requestNotificationPermission() async {
    final status = await Permission.notification.request();
    return status.isGranted;
  }

  static Future<bool> requestCameraPermission() async {
    final status = await Permission.camera.request();
    return status.isGranted;
  }

  static Future<bool> requestLocationPermission() async {
    final status = await Permission.location.request();
    return status.isGranted;
  }

  static Future<void> requestAllPermissions() async {
    await requestNotificationPermission();
    await requestCameraPermission();
    await requestLocationPermission();
  }
}