/// API Endpoints Configuration
/// All API endpoints in one centralized file
class ApiEndpoints {
  // Authentication
  static const String auth = 'auth.php';
  
  // Core Features
  static const String fruit = 'fruits.php';
  static const String prayers = 'prayers.php';
  static const String blogs = 'blogs.php';
  static const String videos = 'videos.php';
  static const String gallery = 'gallery.php';
  static const String emojis = 'emojis.php';
  static const String groups = 'groups.php';
  static const String comments = 'comments.php';
  static const String notifications = 'notifications.php';
  static const String profile = 'profile.php';
  static const String users = 'users.php';
  
  // Additional Features
  static const String stories = 'stories.php';
  static const String search = 'search.php';
  static const String analytics = 'analytics.php';
  static const String advanced = 'advanced.php';
  static const String translate = 'translate.php';
  static const String terms = 'terms.php';
  static const String ecommerce = 'ecommerce.php';
  static const String prayerReminders = 'prayer_reminders.php';
  static const String contact = 'contact.php';
  static const String report = 'report.php';
  static const String blockUser = 'block_user.php';
  static const String denominations = 'denominations.php';
  static const String banners = 'banners.php';
  
  // Live Streaming
  static const String liveStreamingToken = 'live_streaming/token.php';
  static const String liveStreamingCreate = 'live_streaming/create_stream.php';
  static const String liveStreamingGet = 'live_streaming/get_stream.php';
  static const String liveStreamingStop = 'live_streaming/stop_stream.php';
  static const String liveStreamingGetAll = 'live_streaming/get_all_streams.php';
  static const String liveStreamingAgoraToken = 'live_streaming/agora_token.php';
  static const String liveStreamingAgoraStartLive = 'live_streaming/agora_start_live.php';
  static const String liveStreamingAddComment = 'live_streaming/add_live_comment.php';
  static const String liveStreamingGetComments = 'live_streaming/get_live_comments.php';
  
  // In-App Purchases
  static const String verifyPurchase = 'verify-iap.php';
  static const String getSubscriptionStatus = 'subscription_status.php';
  static const String getIapProducts = 'get_products.php';
  static const String checkPremiumStatus = 'check_premium.php';
  static const String christianCalendar = 'christian-calendar.php';
  
  // Helper method to get full endpoint URL
  static String getEndpointUrl(String baseUrl, String endpoint) {
    // Ensure base URL ends with slash and endpoint doesn't start with slash
    final cleanBaseUrl = baseUrl.endsWith('/') ? baseUrl : '$baseUrl/';
    final cleanEndpoint = endpoint.startsWith('/') ? endpoint.substring(1) : endpoint;
    return '$cleanBaseUrl$cleanEndpoint';
  }
}
