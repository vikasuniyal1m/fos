import 'package:flutter/material.dart';
import 'package:fruitsofspirit/config/image_config.dart';
import 'package:fruitsofspirit/widgets/cached_image.dart';
import 'package:fruitsofspirit/services/emojis_service.dart';
import 'package:fruitsofspirit/screens/home_screen.dart';
import 'package:fruitsofspirit/controllers/videos_controller.dart';
import 'package:get/get.dart';

/// Fruit Emoji Helper
/// Standardized utility to detect and render fruit emojis across the app
class FruitEmojiHelper {
  /// Detect if text is a fruit name, emoji character, or emoji image URL
  static bool isFruit(String text) {
    if (text.isEmpty) return false;
    final trimmed = text.trim();
    final lower = trimmed.toLowerCase();

    // Check if it's a direct URL to an emoji
    if (lower.startsWith('http') || lower.contains('.png') || lower.contains('.jpg') || lower.contains('/emojis/')) return true;
    
    // Check fruit names
    final fruitNames = ['love', 'joy', 'peace', 'patience', 'kindness', 'goodness', 
                       'faithfulness', 'gentleness', 'meekness', 'self-control', 'self control', 'discipline',
                       'patience_orange', 'joy_pineapple', 'peace_watermelon', 'kindness_orange', 'goodness_mango',
                       'faithfulness_cherry', 'gentleness_grapes', 'self_control_apple'];
    if (fruitNames.contains(lower)) return true;
    
    // Check emoji characters
    final emojiChars = ['😊', '☮️', '⏳', '🤗', '✨', '🙏', '🕊️', '🎯', '❤️', '⭐', '👏'];
    if (emojiChars.contains(trimmed)) return true;
    
    return false;
  }

  /// Get image URL for a fruit name or emoji character
  static String? getFruitImageUrl(String text, {double? size, int variant = 1}) {
    if (text.isEmpty) return null;
    final trimmed = text.trim();
    final lower = trimmed.toLowerCase();
    
    // If it's already a full URL, return it
    if (lower.startsWith('http')) return trimmed;

    // Try by name first
    String? url = ImageConfig.getFruitReactionImageUrlByName(lower, size: size, variant: variant);
    if (url != null) return url;
    
    // Try by emoji character
    url = ImageConfig.getFruitReactionImageUrl(trimmed, size: size, variant: variant);
    if (url != null) return url;
    
    // Fallback to legacy fruit images if name matches
    final fruitNames = ['love', 'joy', 'peace', 'patience', 'kindness', 'goodness', 
                       'faithfulness', 'gentleness', 'meekness', 'self-control', 'self control', 'discipline'];
    if (fruitNames.contains(lower)) {
      return ImageConfig.getFruitImageUrl(lower);
    }
    
    return null;
  }

  /// Build a fruit emoji widget
  static Widget buildFruitWidget(String text, {double size = 24}) {
    final url = getFruitImageUrl(text, size: size);
    
    if (url != null) {
      return CachedImage(
        imageUrl: url,
        width: size,
        height: size,
        fit: BoxFit.contain,
        errorWidget: _buildPlaceholder(size),
      );
    }
    
    // If it's a character but no URL, just show the character
    return Text(
      text,
      style: TextStyle(fontSize: size * 0.8),
    );
  }

  /// Process text to replace fruit names with emojis
  static Widget buildCommentText(BuildContext context, String text, {TextStyle? style}) {
    if (text.isEmpty) return const SizedBox.shrink();

    // First check for sticker codes like :sticker_212: and handle them
    final stickerRegex = RegExp(r':sticker_(\d+):');
    final stickerMatches = stickerRegex.allMatches(text);
    
    if (stickerMatches.isNotEmpty) {
      // Handle sticker codes by looking up emoji data
      return _buildStickerCommentText(context, text, style: style);
    }

    final fruitNames = ['love', 'joy', 'peace', 'patience', 'kindness', 'goodness', 
                       'faithfulness', 'gentleness', 'meekness', 'self-control', 'self control', 'discipline'];
    
    final emojiChars = ['😊', '☮️', '⏳', '🤗', '✨', '🙏', '🕊️', '🎯', '❤️', '⭐', '👏'];
    
    // Sort fruit names by length descending to match longer phrases first
    final sortedFruitNames = List<String>.from(fruitNames)..sort((a, b) => b.length.compareTo(a.length));
    
    // Create patterns
    final namePattern = sortedFruitNames.map((name) => RegExp.escape(name)).join('|');
    final emojiPattern = emojiChars.map((e) => RegExp.escape(e)).join('|');
    
    // Match fruit names with word boundaries OR emoji characters anywhere
    final regex = RegExp('\\b($namePattern)\\b|($emojiPattern)', caseSensitive: false);

    final List<InlineSpan> spans = [];
    int lastMatchEnd = 0;

    for (final match in regex.allMatches(text)) {
      // Add text before the match
      if (match.start > lastMatchEnd) {
        spans.add(TextSpan(
          text: text.substring(lastMatchEnd, match.start),
          style: style,
        ));
      }

      final matchedText = match.group(0)!;
      final cleanWord = matchedText.toLowerCase();
      final url = getFruitImageUrl(cleanWord);

      if (url != null) {
        spans.add(
          WidgetSpan(
            alignment: PlaceholderAlignment.middle,
            child: Padding(
              padding: const EdgeInsets.symmetric(horizontal: 2.0),
              child: CachedImage(
                imageUrl: url,
                width: (style?.fontSize ?? 14) * 1.4,
                height: (style?.fontSize ?? 14) * 1.4,
                fit: BoxFit.contain,
              ),
            ),
          ),
        );
      } else {
        spans.add(TextSpan(text: matchedText, style: style));
      }

      lastMatchEnd = match.end;
    }

    // Add remaining text
    if (lastMatchEnd < text.length) {
      spans.add(TextSpan(
        text: text.substring(lastMatchEnd),
        style: style,
      ));
    }

    if (spans.isEmpty) {
      return Text(text, style: style);
    }

    return RichText(
      text: TextSpan(
        children: spans,
        style: style,
      ),
    );
  }

  /// Build comment text with sticker codes - handles :sticker_212: format
  static Widget _buildStickerCommentText(BuildContext context, String text, {TextStyle? style}) {
    print('🔍 _buildStickerCommentText: Processing text: "$text"');
    
    // Extract sticker codes and replace them with emoji images
    final stickerRegex = RegExp(r':sticker_(\d+):');
    final List<InlineSpan> spans = [];
    int lastMatchEnd = 0;

    for (final match in stickerRegex.allMatches(text)) {
      // Add text before the sticker
      if (match.start > lastMatchEnd) {
        spans.add(TextSpan(
          text: text.substring(lastMatchEnd, match.start),
          style: style,
        ));
      }

      // Get sticker ID and try to find emoji data
      final stickerId = int.tryParse(match.group(1)!);
      print('🔍 _buildStickerCommentText: Found sticker ID: $stickerId');
      
      if (stickerId != null) {
        // Try to get emoji data from the cached emojis in VideosController
        String? imageUrl;
        try {
          final videosController = Get.find<VideosController>();
          final availableEmojis = videosController.availableEmojis;
          
          // Find emoji by ID
          final emojiData = availableEmojis.firstWhereOrNull(
            (emoji) => emoji['id'] == stickerId,
          );
          
          if (emojiData != null && emojiData['image_url'] != null) {
            imageUrl = emojiData['image_url'].toString();
            print('🔍 _buildStickerCommentText: Found emoji data for ID $stickerId: ${emojiData['name']}');
            print('🔍 _buildStickerCommentText: Using image URL: $imageUrl');
          } else {
            print('⚠️ _buildStickerCommentText: No emoji data found for ID $stickerId');
          }
        } catch (e) {
          print('⚠️ _buildStickerCommentText: Error accessing emoji data: $e');
        }
        
        // Fallback to a default emoji if we couldn't find the specific one
        if (imageUrl == null) {
          // Use a default emoji image that we know exists
          imageUrl = 'https://fruitofthespirit.templateforwebsites.com/uploads/emojis/Longsuffering.png';
          print('🔍 _buildStickerCommentText: Using fallback image URL: $imageUrl');
        }
        
        spans.add(
          WidgetSpan(
            alignment: PlaceholderAlignment.middle,
            child: Padding(
              padding: const EdgeInsets.symmetric(horizontal: 2.0),
              child: CachedImage(
                imageUrl: imageUrl,
                width: (style?.fontSize ?? 14) * 1.4,
                height: (style?.fontSize ?? 14) * 1.4,
                fit: BoxFit.contain,
                errorWidget: Container(
                  width: (style?.fontSize ?? 14) * 1.4,
                  height: (style?.fontSize ?? 14) * 1.4,
                  decoration: BoxDecoration(
                    color: Colors.grey[300],
                    borderRadius: BorderRadius.circular(4),
                  ),
                  child: Icon(
                    Icons.emoji_emotions,
                    size: (style?.fontSize ?? 14) * 0.8,
                    color: Colors.grey[600],
                  ),
                ),
              ),
            ),
          ),
        );
      }

      lastMatchEnd = match.end;
    }

    // Add remaining text
    if (lastMatchEnd < text.length) {
      spans.add(TextSpan(
        text: text.substring(lastMatchEnd),
        style: style,
      ));
    }

    return RichText(
      text: TextSpan(
        children: spans,
        style: style,
      ),
    );
  }

  static Widget _buildPlaceholder(double size) {
    return Icon(
      Icons.sentiment_satisfied,
      size: size,
      color: const Color(0xFFC79211),
    );
  }
}
