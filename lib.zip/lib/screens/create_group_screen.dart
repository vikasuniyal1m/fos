import 'dart:io';
import 'package:flutter/material.dart';
import 'package:fruitsofspirit/controllers/home_controller.dart';
import 'package:get/get.dart';
import 'package:image_picker/image_picker.dart';
import 'package:fruitsofspirit/controllers/groups_controller.dart';
import 'package:fruitsofspirit/utils/responsive_helper.dart';
import 'package:fruitsofspirit/widgets/cached_image.dart';
import 'package:fruitsofspirit/config/image_config.dart';

/// Create Group Screen
class CreateGroupScreen extends StatefulWidget {
  const CreateGroupScreen({Key? key}) : super(key: key);

  @override
  State<CreateGroupScreen> createState() => _CreateGroupScreenState();
}

class _CreateGroupScreenState extends State<CreateGroupScreen> {
  final GroupsController controller = Get.find<GroupsController>();
  final nameController = TextEditingController();
  final descriptionController = TextEditingController();
  File? selectedImage;
  String selectedCategory = 'Prayer';

  @override
  void dispose() {
    nameController.dispose();
    descriptionController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {

    return Scaffold(
      backgroundColor: Colors.white,
      appBar: PreferredSize(
        preferredSize: Size.fromHeight(
          ResponsiveHelper.safeHeight(
            context,
            mobile: 70,
            tablet: 80,
            desktop: 90,
          ),
        ),
        child: Container(
          decoration: BoxDecoration(
            color: Colors.white,
            boxShadow: [
              BoxShadow(
                color: Colors.black.withOpacity(0.05),
                blurRadius: ResponsiveHelper.isMobile(context) ? 4 : 8,
                offset: Offset(0, ResponsiveHelper.isMobile(context) ? 2 : 4),
              ),
            ],
            border: Border(
              bottom: BorderSide(
                color: Colors.grey.withOpacity(0.15),
                width: ResponsiveHelper.isMobile(context) ? 0.5 : 1,
              ),
            ),
          ),
          child: SafeArea(
            bottom: false,
            child: Padding(
              padding: ResponsiveHelper.padding(
                context,
                horizontal: ResponsiveHelper.isMobile(context)
                    ? ResponsiveHelper.spacing(context, 16)
                    : ResponsiveHelper.isTablet(context)
                        ? ResponsiveHelper.spacing(context, 24)
                        : ResponsiveHelper.spacing(context, 32),
                vertical: ResponsiveHelper.isMobile(context)
                    ? ResponsiveHelper.spacing(context, 12)
                    : ResponsiveHelper.isTablet(context)
                        ? ResponsiveHelper.spacing(context, 14)
                        : ResponsiveHelper.spacing(context, 16),
              ),
              child: Row(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                crossAxisAlignment: CrossAxisAlignment.center,
                children: [
                  // Left Side - Logo
                  Expanded(
                    flex: ResponsiveHelper.isDesktop(context) ? 4 : 3,
                    child: Align(
                      alignment: Alignment.centerLeft,
                      child: CachedImage(
                        imageUrl: ImageConfig.logo,
                        width: double.infinity,
                        height: ResponsiveHelper.isMobile(context)
                            ? 52.0
                            : ResponsiveHelper.isTablet(context)
                                ? 58.0
                                : 64.0,
                        fit: BoxFit.contain,
                        errorWidget: Container(
                          height: ResponsiveHelper.isMobile(context)
                              ? 52.0
                              : ResponsiveHelper.isTablet(context)
                                  ? 58.0
                                  : 64.0,
                          alignment: Alignment.centerLeft,
                          child: Text(
                            'Create Group',
                            style: TextStyle(
                              fontSize: ResponsiveHelper.fontSize(context, mobile: 20),
                              fontWeight: FontWeight.bold,
                              color: const Color(0xFF5F4628),
                            ),
                          ),
                        ),
                      ),
                    ),
                  ),
                  SizedBox(
                    width: ResponsiveHelper.isMobile(context)
                        ? 12.0
                        : ResponsiveHelper.isTablet(context)
                            ? 16.0
                            : 20.0,
                  ),
                  // Right Side - Back Button
                  Material(
                    color: Colors.transparent,
                    child: InkWell(
                      onTap: () => Get.back(),
                      borderRadius: BorderRadius.circular(30),
                      child: Container(
                        width: ResponsiveHelper.isMobile(context)
                            ? 40.0
                            : ResponsiveHelper.isTablet(context)
                                ? 44.0
                                : 48.0,
                        height: ResponsiveHelper.isMobile(context)
                            ? 40.0
                            : ResponsiveHelper.isTablet(context)
                                ? 44.0
                                : 48.0,
                        decoration: BoxDecoration(
                          gradient: const LinearGradient(
                            begin: Alignment.topLeft,
                            end: Alignment.bottomRight,
                            colors: [
                              Color(0xFF8B4513),
                              Color(0xFF6B3410),
                            ],
                          ),
                          shape: BoxShape.circle,
                          border: Border.all(
                            color: Colors.grey.withOpacity(0.2),
                            width: 1.5,
                          ),
                          boxShadow: [
                            BoxShadow(
                              color: const Color(0xFF8B4513).withOpacity(0.3),
                              blurRadius: 8,
                              offset: const Offset(0, 2),
                            ),
                          ],
                        ),
                        child: Icon(
                          Icons.arrow_back_rounded,
                          color: Colors.white,
                          size: ResponsiveHelper.isMobile(context)
                              ? 20.0
                              : ResponsiveHelper.isTablet(context)
                                  ? 22.0
                                  : 24.0,
                        ),
                      ),
                    ),
                  ),
                ],
              ),
            ),
          ),
        ),
      ),
      body: SingleChildScrollView(
        padding: EdgeInsets.all(ResponsiveHelper.spacing(context, 16)),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            // Group Image
            Text(
              'Group Image (Optional)',
              style: TextStyle(
                fontSize: ResponsiveHelper.fontSize(context, mobile: 15),
                fontWeight: FontWeight.bold,
                color: const Color(0xFF5F4628),
              ),
            ),
            SizedBox(height: ResponsiveHelper.spacing(context, 8)),
            Center(
              child: GestureDetector(
                onTap: () async {
                  final picker = ImagePicker();
                  final image = await picker.pickImage(source: ImageSource.gallery);
                  if (image != null) {
                    setState(() {
                      selectedImage = File(image.path);
                    });
                  }
                },
                child: Container(
                  width: ResponsiveHelper.isMobile(context)
                      ? MediaQuery.of(context).size.width * 0.5
                      : ResponsiveHelper.isTablet(context)
                          ? MediaQuery.of(context).size.width * 0.4
                          : MediaQuery.of(context).size.width * 0.35,
                  height: ResponsiveHelper.isMobile(context)
                      ? MediaQuery.of(context).size.width * 0.5
                      : ResponsiveHelper.isTablet(context)
                          ? MediaQuery.of(context).size.width * 0.4
                          : MediaQuery.of(context).size.width * 0.35,
                  decoration: BoxDecoration(
                    gradient: LinearGradient(
                      colors: [
                        Colors.grey[100]!,
                        Colors.grey[50]!,
                      ],
                      begin: Alignment.topLeft,
                      end: Alignment.bottomRight,
                    ),
                    borderRadius: BorderRadius.circular(12),
                    border: Border.all(
                      color: Colors.grey.withOpacity(0.2),
                      width: 1.5,
                    ),
                    boxShadow: [
                      BoxShadow(
                        color: Colors.black.withOpacity(0.05),
                        spreadRadius: 0,
                        blurRadius: 8,
                        offset: const Offset(0, 2),
                      ),
                    ],
                    image: selectedImage != null
                        ? DecorationImage(
                            image: FileImage(selectedImage!),
                            fit: BoxFit.cover,
                          )
                        : null,
                  ),
                  child: selectedImage == null
                      ? Column(
                          mainAxisAlignment: MainAxisAlignment.center,
                          children: [
                            Icon(
                              Icons.add_photo_alternate_rounded,
                              size: ResponsiveHelper.iconSize(context, mobile: 40, tablet: 45, desktop: 50),
                              color: const Color(0xFF9F9467),
                            ),
                            SizedBox(height: ResponsiveHelper.spacing(context, 8)),
                            Text(
                              'Tap to select image',
                              style: TextStyle(
                                fontSize: ResponsiveHelper.fontSize(context, mobile: 13),
                                color: Colors.grey[600],
                              ),
                              textAlign: TextAlign.center,
                            ),
                          ],
                        )
                      : null,
                ),
              ),
            ),
            SizedBox(height: ResponsiveHelper.spacing(context, 20)),
            
            // Group Name
            Text(
              'Group Name *',
              style: TextStyle(
                fontSize: ResponsiveHelper.fontSize(context, mobile: 15),
                fontWeight: FontWeight.bold,
                color: const Color(0xFF5F4628),
              ),
            ),
            SizedBox(height: ResponsiveHelper.spacing(context, 8)),
            TextField(
              controller: nameController,
              decoration: InputDecoration(
                hintText: 'Enter group name',
                hintStyle: TextStyle(
                  fontSize: ResponsiveHelper.fontSize(context, mobile: 14),
                  color: Colors.grey[500],
                ),
                border: OutlineInputBorder(
                  borderRadius: BorderRadius.circular(12),
                  borderSide: BorderSide(color: Colors.grey.withOpacity(0.2), width: 1),
                ),
                enabledBorder: OutlineInputBorder(
                  borderRadius: BorderRadius.circular(12),
                  borderSide: BorderSide(color: Colors.grey.withOpacity(0.2), width: 1),
                ),
                focusedBorder: OutlineInputBorder(
                  borderRadius: BorderRadius.circular(12),
                  borderSide: const BorderSide(color: Color(0xFF8B4513), width: 2),
                ),
                filled: true,
                fillColor: Colors.white,
                contentPadding: const EdgeInsets.symmetric(horizontal: 16, vertical: 14),
              ),
              style: TextStyle(
                fontSize: ResponsiveHelper.fontSize(context, mobile: 14),
                color: Colors.black87,
              ),
            ),
            SizedBox(height: ResponsiveHelper.spacing(context, 16)),
            
            // Category
            Text(
              'Category *',
              style: TextStyle(
                fontSize: ResponsiveHelper.fontSize(context, mobile: 15),
                fontWeight: FontWeight.bold,
                color: const Color(0xFF5F4628),
              ),
            ),
            SizedBox(height: ResponsiveHelper.spacing(context, 8)),
            DropdownButtonFormField<String>(
              value: selectedCategory,
              decoration: InputDecoration(
                border: OutlineInputBorder(
                  borderRadius: BorderRadius.circular(12),
                  borderSide: BorderSide(color: Colors.grey.withOpacity(0.2), width: 1),
                ),
                enabledBorder: OutlineInputBorder(
                  borderRadius: BorderRadius.circular(12),
                  borderSide: BorderSide(color: Colors.grey.withOpacity(0.2), width: 1),
                ),
                focusedBorder: OutlineInputBorder(
                  borderRadius: BorderRadius.circular(12),
                  borderSide: const BorderSide(color: Color(0xFF8B4513), width: 2),
                ),
                filled: true,
                fillColor: Colors.white,
                contentPadding: const EdgeInsets.symmetric(horizontal: 16, vertical: 14),
              ),
              items: ['Prayer', 'Bible Study', 'Fellowship', 'Worship', 'Other']
                  .map((category) => DropdownMenuItem(
                        value: category,
                        child: Text(
                          category,
                          style: TextStyle(
                            fontSize: ResponsiveHelper.fontSize(context, mobile: 14),
                            color: Colors.black87,
                          ),
                        ),
                      ))
                  .toList(),
              onChanged: (value) {
                setState(() {
                  selectedCategory = value!;
                });
              },
              style: TextStyle(
                fontSize: ResponsiveHelper.fontSize(context, mobile: 14),
                color: Colors.black87,
              ),
            ),
            SizedBox(height: ResponsiveHelper.spacing(context, 16)),
            
            // Description
            Text(
              'Description (Optional)',
              style: TextStyle(
                fontSize: ResponsiveHelper.fontSize(context, mobile: 15),
                fontWeight: FontWeight.bold,
                color: const Color(0xFF5F4628),
              ),
            ),
            SizedBox(height: ResponsiveHelper.spacing(context, 8)),
            TextField(
              controller: descriptionController,
              maxLines: 4,
              decoration: InputDecoration(
                hintText: 'Enter group description',
                hintStyle: TextStyle(
                  fontSize: ResponsiveHelper.fontSize(context, mobile: 14),
                  color: Colors.grey[500],
                ),
                border: OutlineInputBorder(
                  borderRadius: BorderRadius.circular(12),
                  borderSide: BorderSide(color: Colors.grey.withOpacity(0.2), width: 1),
                ),
                enabledBorder: OutlineInputBorder(
                  borderRadius: BorderRadius.circular(12),
                  borderSide: BorderSide(color: Colors.grey.withOpacity(0.2), width: 1),
                ),
                focusedBorder: OutlineInputBorder(
                  borderRadius: BorderRadius.circular(12),
                  borderSide: const BorderSide(color: Color(0xFF8B4513), width: 2),
                ),
                filled: true,
                fillColor: Colors.white,
                contentPadding: const EdgeInsets.symmetric(horizontal: 16, vertical: 14),
              ),
              style: TextStyle(
                fontSize: ResponsiveHelper.fontSize(context, mobile: 14),
                color: Colors.black87,
              ),
            ),
            SizedBox(height: ResponsiveHelper.spacing(context, 24)),
            
            // Submit Button
            SizedBox(
              width: double.infinity,
              height: ResponsiveHelper.buttonHeight(context, mobile: 52),
              child: ElevatedButton(
                onPressed: controller.isLoading.value
                    ? null
                    : () async {
                        if (nameController.text.trim().isEmpty) {
                          Get.snackbar(
                            'Error',
                            'Please enter group name',
                            backgroundColor: Colors.red,
                            colorText: Colors.white,
                          );
                          return;
                        }

                        final success = await controller.createGroup(
                          name: nameController.text.trim(),
                          description: descriptionController.text.trim().isEmpty
                              ? null
                              : descriptionController.text.trim(),
                          category: selectedCategory,
                          groupImage: selectedImage,
                        );

                        if (success) {
                          try {
                            if (Get.isRegistered<HomeController>()) {
                              try {
                                final homeController = Get.find<HomeController>();
                                homeController.loadGroups();
                              } catch (e) {
                                print('HomeController not found: $e');
                              }
                            }
                          } catch (e) {
                            print('HomeController not available: $e');
                          }
                          
                          Get.back();
                          Get.snackbar(
                            'Success',
                            controller.message.value,
                            backgroundColor: Colors.green,
                            colorText: Colors.white,
                          );
                        } else {
                          Get.snackbar(
                            'Error',
                            controller.message.value,
                            backgroundColor: Colors.red,
                            colorText: Colors.white,
                          );
                        }
                      },
                style: ElevatedButton.styleFrom(
                  backgroundColor: const Color(0xFF8B4513),
                  elevation: 0,
                  shape: RoundedRectangleBorder(
                    borderRadius: BorderRadius.circular(12),
                  ),
                ),
                child: controller.isLoading.value
                    ? const CircularProgressIndicator(color: Colors.white)
                    : Text(
                        'Create Group',
                        style: TextStyle(
                          fontSize: ResponsiveHelper.fontSize(context, mobile: 16),
                          fontWeight: FontWeight.bold,
                          color: Colors.white,
                        ),
                      ),
              ),
            ),
          ],
        ),
      ),
    );
  }
}

