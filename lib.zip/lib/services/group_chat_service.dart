import 'dart:io';
import '../config/api_config.dart';
import 'api_service.dart';

/// Group Chat Service
/// Handles real-time chat messages (WhatsApp style)
class GroupChatService {
  /// Get Chat Messages
  /// 
  /// Parameters:
  /// - groupId: Group ID
  /// - userId: Current user ID
  /// - limit: Number of messages (default: 50)
  /// - offset: Pagination offset (default: 0)
  /// - lastMessageId: Last message ID for pagination (optional)
  /// 
  /// Returns: List of chat messages
  static Future<List<Map<String, dynamic>>> getChatMessages({
    required int groupId,
    required int userId,
    int limit = 50,
    int offset = 0,
    int? lastMessageId,
  }) async {
    final queryParams = <String, String>{
      'group_id': groupId.toString(),
      'user_id': userId.toString(),
      'limit': limit.toString(),
      'offset': offset.toString(),
    };

    if (lastMessageId != null && lastMessageId > 0) {
      queryParams['last_message_id'] = lastMessageId.toString();
    }

    final response = await ApiService.get(
      '${ApiConfig.groups}?action=messages',
      queryParameters: queryParams,
    );

    if (response['success'] == true && response['data'] != null) {
      return List<Map<String, dynamic>>.from(response['data']);
    } else {
      throw ApiException(response['message'] ?? 'Failed to fetch chat messages');
    }
  }

  /// Send Chat Message
  /// 
  /// Parameters:
  /// - userId: User ID
  /// - groupId: Group ID
  /// - message: Message text
  /// - messageType: Type of message ('text', 'image', 'file')
  /// - file: Optional file to send
  /// 
  /// Returns: Sent message data
  static Future<Map<String, dynamic>> sendMessage({
    required int userId,
    required int groupId,
    required String message,
    String messageType = 'text',
    File? file,
  }) async {
    print('📤 GroupChatService.sendMessage called:');
    print('   userId: $userId');
    print('   groupId: $groupId');
    print('   message: ${message.substring(0, message.length > 50 ? 50 : message.length)}...');
    print('   messageType: $messageType');
    print('   file: ${file != null ? file.path : "none"}');
    
    // Build URL with action in query string
    // PHP reads: $_GET['action'] ?? $_POST['action']
    // For multipart POST, action MUST be in POST body (fields) - $_GET might not work for multipart
    final endpoint = '${ApiConfig.groups}?action=messages';
    
    // CRITICAL: Include action in POST body - PHP reads from $_POST['action'] for multipart requests
    // Multipart form-data populates $_POST, not $_GET
    final fields = <String, String>{
      'action': 'messages', // MUST be in POST body for multipart requests
      'user_id': userId.toString(),
      'group_id': groupId.toString(),
      'message': message,
      'message_type': messageType,
    };

    final files = <String, File>{};
    if (file != null) {
      files['file'] = file;
      print('   ✅ File added to request: ${file.path}');
    }

    print('📤 Sending POST request to: $endpoint');
    print('📤 Fields: $fields');
    print('📤 Action in fields: ${fields['action']}');
    print('📤 Files count: ${files.length}');

    try {
      final response = await ApiService.postMultipart(
        endpoint,
        fields: fields,
        files: files.isNotEmpty ? files : null,
      );

      print('📥 API Response received:');
      print('   success: ${response['success']}');
      print('   message: ${response['message']}');
      print('   data: ${response['data']}');

      if (response['success'] == true && response['data'] != null) {
        print('✅ Message sent successfully!');
        return response['data'] as Map<String, dynamic>;
      } else {
        final errorMsg = response['message'] ?? 'Failed to send message';
        print('❌ API returned error: $errorMsg');
        throw ApiException(errorMsg);
      }
    } catch (e) {
      print('❌ Exception in sendMessage: $e');
      print('❌ Exception type: ${e.runtimeType}');
      rethrow;
    }
  }
}

